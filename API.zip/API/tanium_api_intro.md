# Introduction to Tanium APIs

Tanium has different APIs available to use for building integrations. Tanium Gateway is the preferred option for API integrations with Tanium. However, availability of the various legacy REST APIs is maintained for backwards compatibility purposes. There are also some features that are not yet available through Gateway for which you will need to leverage the REST APIs.

Stay on top of New API Features and Updates and other changes that could impact developers by joining the API Notification Group.

## What is Tanium Gateway?

GraphQL Logo
Tanium Gateway is a GraphQL service for interacting with Tanium data. It is the preferred solution for API integrations. You can query for data about online and offline endpoints, deploy actions, run playbooks, and much more. Tanium Gateway is the only way to integrate programmatically with some of Tanium’s most popular modules including Reporting, Automate, and Discover.

Detailed information is available in the Gateway User Guide, including any Deprecation Announcements.

Gateway topology diagram
## What is the Tanium Platform REST API?

The Platform REST API covers the majority of core Tanium functionality such as asking live questions, deploying actions, and reading or updating configuration. It should be should be reserved for cases where the functionality is not yet available through Gateway.

## What are the Tanium Module REST APIs?

Some Tanium modules have a public REST API with documentation that is accessed via the help link at the top right of the main page of their respective workbench in the Tanium console. We are adding the documentation for those modules here on the developer portal as well, but not all of them have been added yet.
Like the Platform REST API, use of the module REST APIs should be reserved for cases where the functionality is not yet available through Gateway.

## FAQ

#### What if I don't see API documentation for a module I want to integrate with here or a capability is missing?

Please visit the Developer Community and let us know what your use case is and what capability you would like to see supported in the API. **Do not use** any API endpoints that are not publicly documented as they could change or be removed without notice. Only those API capabilities that are published in Tanium's API Documentation are supported for external use.

#### What version of the APIs are shown in these reference docs?

The documentation shown is for Tanium Cloud. If you are running Tanium on-premise, then your APIs might not have all the same capabilities.

#### Do you have an SDK available for my favorite language?

The goal of Tanium Gateway, and GraphQL in general, is to allow API developers to easily define and evolve APIs to meet changing requirements.
Integrators can precisely specify the data they need using the query language, allowing for a more flexible and efficient data retrieval process. This design philosophy generally leads to a simplified end user experience, negating the need for an SDK to overcome the complexity often found in other types of APIs, such as REST or SOAP.