## Queries
- action: Finds the identified action.

**Stability Level**: 3 - Stable
- actionGroup: Returns an action group that matches the specified input.

**Stability Level**: 3 - Stable
- actionGroups: **Stability Level**: 3 - Stable
- actions: Returns the matching actions.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- assetProductEndpoints: Retrieves endpoints based on Asset software inventory and usage.

Use of this field requires the Asset solution.

Use of this field requires the Tanium permission `asset api user read`.

**Stability Level**: 3 - Stable
- assetProducts: Retrieves product usage for assets and endpoints.

Use of this field requires the Asset solution.

Use of this field requires the Tanium permission `asset api user read`.

**Stability Level**: 3 - Stable
- assets: Assets from Tanium Data Service or Tanium Server.

**Stability Level**: 0 - Deprecated
- computerGroup: Returns a computer group that matches the specified input.

**Stability Level**: 3 - Stable
- computerGroups: Returns all computer groups matching the specified input.

**Stability Level**: 3 - Stable
- configurationItemEntities: Returns configuration item entities from the CMDB.

Use of this field requires the Atlas solution.

**Stability Level**: 0 - Deprecated
- configurationItemProperties: Returns all properties related to configuration items.

Use of this field requires the Atlas solution.

**Stability Level**: 0 - Deprecated
- configurationItemRelationships: Returns relationships for the identified configuration items from the CMDB.

Use of this field requires the Atlas solution.

**Stability Level**: 0 - Deprecated
- connectConnection: Returns the connection that matches the referenced ID.

Use of this field requires the Connect solution.

Use of this field requires the Tanium permission `Connect - Read`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- connectConnections: Returns the matching connections.

Use of this field requires the Connect solution.

Use of this field requires the Tanium permission `Connect - Read`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- connectRun: Returns the connection run that matches the referenced connection run ID.

Use of this field requires the Connect solution.

Use of this field requires the Tanium permission `Connect - Read`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- connectRuns: Returns all connection runs started from a given connection configuration.

Use of this field requires the Connect solution.

Use of this field requires the Tanium permission `Connect - Read`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- currentUserContext: Returns the current user and selected persona.

**Stability Level**: 1.1 - Experimental (Active Development)
- deploymentPlan: Get a single deployment plan by ID.
This is intended for Tanium internal use, and should not be used by customers.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Read Deployment Plan`.

**Stability Level**: 1.1 - Experimental (Active Development)
- deploymentPlans: Get deployment plans.
This is intended for Tanium internal use, and should not be used by customers.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Read Deployment Plan`.

**Stability Level**: 1.1 - Experimental (Active Development)
- directConnectConnectionStatus: Checks the status of a direct connection.

The input requires a direct endpoint connection opened using `directConnectOpen`.

Use of this field requires the Direct Connect solution.

**Stability Level**: 3 - Stable
- directConnectEndpoint: Obtains data from the specified endpoint using an open Direct Connect connection.

The input requires a direct endpoint connection opened using `directConnectOpen`.

Use of this field requires the Direct Connect solution.

**Stability Level**: 3 - Stable
- directConnection: **Stability Level**: 0 - Deprecated
- directEndpoint: Obtains data from the specified endpoint using a Direct Connect connection.

Use of this field requires the Direct Connect solution.

**Stability Level**: 2 - Legacy
Use `directConnectEndpoint` instead. The `directConnect` APIs provide better support for tracking connections that take longer to establish.

Deprecated in May 2023.
- discoverInterface: Returns the Discover interface that matches the referenced ID.

Use of this field requires the Tanium permission `Discover Asset - Read`.

Note: If location permissions are defined, the user will also require the `User Group - Read` permission and only the interfaces in locations allowed by the user's group membership will be returned.  Otherwise, if the user has the `Discover Location Permissions - Write` permission they will see all interfaces regardless of group membership.

**Stability Level**: 1.1 - Experimental (Active Development)
- discoverInterfaces: Returns the matching Discover interfaces.

Use of this field requires the Tanium permission `Discover Asset - Read`.

Note: If location permissions are defined, the user will also require the `User Group - Read` permission and only the interfaces in locations allowed by the user's group membership will be returned.  Otherwise, if the user has the `Discover Location Permissions - Write` permission they will see all interfaces regardless of group membership.

**Stability Level**: 1.1 - Experimental (Active Development)
- discoverLabel: Returns the Discover label that matches the referenced name.

Use of this field requires the Tanium permission `Discover Asset - Read`.

**Stability Level**: 1.1 - Experimental (Active Development)
- discoverLabels: Returns the matching Discover labels.

Use of this field requires the Tanium permission `Discover Asset - Read`.

**Stability Level**: 1.1 - Experimental (Active Development)
- emailServerSummaries: Returns summary information for matching email servers, required to retrieve and
use an email server to send emails. The response contains summary information only
for email servers that are enabled to send emails.

Use of this field requires the Email solution.

Use of this field requires the Tanium permission `Email Send`.

Note: Only return summaries for email servers in content sets to which the user has the `Email Send` permission.

**Stability Level**: 1.0 - Experimental (Early Development)
- emailServerSummary: Returns summary information for the email server matching the ID, required to retrieve
and use an email server to send emails. The response contains the matching email server
summary information only if the email server is enabled to send emails.

Use of this field requires the Email solution.

Use of this field requires the Tanium permission `Email Send`.

Note: Only returns a summary if the email server is in a content set to which the user has the `Email Send` permission.

**Stability Level**: 1.0 - Experimental (Early Development)
- endpointCounts: Returns the count of endpoints matching the input sensor column values.
Requests might return an array of field values for a given column. For example, if you define the Installed Application sensor in `EndpointCountsInput.sensors`,
the results include multiple applications per row count. For the Installed Application sensor `Name` column, the `values` field returns an array of multiple applications.

**Stability Level**: 1.0 - Experimental (Early Development)
- endpointIdChanges: Changed endpoint IDs from Tanium Data Service for the given namespace and timespan.

**Stability Level**: 3 - Stable
- endpointLastSeen: Returns the last seen time for an endpoint.
Note that despite accepting a list, only one EID can be specified.

**Stability Level**: 0 - Deprecated
- endpoints: Returns the matching endpoints from the specified source. The cursors in the returned
connections are usable for 5 minutes after the most recent request in the cursored results, with a maximum
lifetime of 1 hour.

**Stability Level**: 3 - Stable
- entities: **Stability Level**: 0 - Deprecated
- integrityMonitorMonitor: Get the Integrity Monitor monitor that matches the referenced ID.

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Monitors Read`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorMonitors: Get Integrity Monitor monitors. Results include monitors that are pending deletion, but not deleted monitors. The collection is sorted by monitor `priority` in rank order, where `1` is the highest priority and listed first.

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Monitors Read`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorStatus: Get the status of the Integrity Monitor service.

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Watchlists Read`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorWatchlist: Get the Integrity Monitor watchlist that matches the referenced ID.

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Watchlists Read`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorWatchlists: Get Integrity Monitor watchlists. Results include watchlists that are pending deletion, but not deleted watchlists. The collection is sorted by watchlist name in alphabetical order.

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Watchlists Read`.

**Stability Level**: 1.0 - Experimental (Early Development)
- lastActionDetails: Returns the details of the last action created by the specified saved action.

**Stability Level**: 0 - Deprecated
- lastActionResults: Returns the results of the last action created by the specified saved action.

**Stability Level**: 0 - Deprecated
- managementRightsGroups: Get the management rights groups associated with the current user and selected persona.
If the current user and selected persona has unrestricted management rights, the response returns an empty list.

**Stability Level**: 1.1 - Experimental (Active Development)
- myAPITokens: Returns the API tokens for the current user.

**Stability Level**: 3 - Stable
- now: The current server time. Useful to test your ability to query the server.

**Stability Level**: 3 - Stable
- packageSpecs: Returns the matching package specs. The cursors in the returned connections are usable for 5 minutes
after the most recent request in the cursored results, with a maximum lifetime of 1 hour.

**Stability Level**: 3 - Stable
- packages: Returns the matching packages.

**Stability Level**: 2 - Legacy
Use `packageSpecs` instead, which has improved pagination and parameter support.
- patchDefinitions: Returns the matching patch definitions.

Use of this field requires the Patch solution.

Use of this field requires the Tanium permission `Patch Show`.

**Stability Level**: 1.0 - Experimental (Early Development)
- patchDeployment: Returns the Patch deployment that matches the referenced ID.

Use of this field requires the Patch solution.

Use of this field requires the Tanium permission `Patch Deployment - Read`.

**Stability Level**: 1.0 - Experimental (Early Development)
- playbook: Get the playbook that matches the ID and revision. If `revision` is not defined, returns the most recent revision of the playbook that matches the ID.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Automate Playbook Read`.

**Stability Level**: 3 - Stable
- playbookRun: Get the playbook run that matches the ID.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Automate Playbook Read`.

**Stability Level**: 3 - Stable
- playbookRuns: Get the matching playbook runs.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Automate Playbook Read`.

**Stability Level**: 3 - Stable
- playbookSchedule: Get the playbook schedule that matches the ID.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Automate Playbook Read`.

**Stability Level**: 3 - Stable
- playbookSchedules: Get the matching playbook schedules.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Automate Playbook Read`.

**Stability Level**: 3 - Stable
- playbooks: Get the matching playbooks.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Automate Playbook Read`.

**Stability Level**: 3 - Stable
- provisionRetirementAction: Get the retirement action that matches the input ID.

For more information, see [Tanium Provision User Guide: Retiring and locking devices](https://help.tanium.com/bundle/ug_provision_cloud/page/provision/retiring_devices.html)

Use of this field requires the Provision solution.

Use of this field requires the Tanium permission `Provision Retirement Actions read`.

**Stability Level**: 1.0 - Experimental (Early Development)
- provisionRetirementActionDefinition: Get the retirement action definition that matches the input ID.

For more information, see [Tanium Provision User Guide: Retiring and locking devices](https://help.tanium.com/bundle/ug_provision_cloud/page/provision/retiring_devices.html)

Use of this field requires the Provision solution.

Use of this field requires the Tanium permission `Provision Retirement Action Definitions read`.

**Stability Level**: 1.0 - Experimental (Early Development)
- provisionRetirementActionDefinitions: Get all retirement action definitions.

For more information, see [Tanium Provision User Guide: Retiring and locking devices](https://help.tanium.com/bundle/ug_provision_cloud/page/provision/retiring_devices.html)

Use of this field requires the Provision solution.

Use of this field requires the Tanium permission `Provision Retirement Action Definitions read`.

**Stability Level**: 1.0 - Experimental (Early Development)
- provisionRetirementActions: Get the matching retirement actions.
By default, each results page contains 20 items, sorted by the `updatedAt`
value in ascending order.

For more information, see [Tanium Provision User Guide: Retiring and locking devices](https://help.tanium.com/bundle/ug_provision_cloud/page/provision/retiring_devices.html)

Use of this field requires the Provision solution.

Use of this field requires the Tanium permission `Provision Retirement Actions read`.

**Stability Level**: 1.0 - Experimental (Early Development)
- relationshipTypes: Returns all configuration item relationship types from the CMDB.

Use of this field requires the Atlas solution.

**Stability Level**: 0 - Deprecated
- relationships: Use of this field requires the Atlas solution.

**Stability Level**: 0 - Deprecated
- report: Returns the report that matches the referenced ID.

Use of this field requires the Reporting solution.

**Stability Level**: 3 - Stable
- reportExport: Exports the definition of the identified report.
The exported definition can be used with the API Gateway `reportImport` mutation to recreate the report in a different Tanium environment.

Use of this field requires the Reporting solution.

**Stability Level**: 3 - Stable
- reportResultData: Retrieves data for the specified report, including details of the report definition.
The cursors in the returned connections are usable for 5 minutes after the most recent request
in the cursored results, with a maximum lifetime of 15 minutes.

Use of this field requires the Reporting solution.

**Stability Level**: 3 - Stable
- reports: Returns the matching reports.

Use of this field requires the Reporting solution.

**Stability Level**: 3 - Stable
- ringDeployment: Get a single ring deployment by ID.
This is intended for Tanium internal use, and should not be used by customers.

Use of this field requires the Automate solution.

**Stability Level**: 1.1 - Experimental (Active Development)
- ringDeployments: Get ring deployments based on the passed in filter and sort options.
This is intended for Tanium internal use, and should not be used by customers.

Use of this field requires the Automate solution.

**Stability Level**: 1.1 - Experimental (Active Development)
- scheduledAction: Finds the identified scheduled action.

**Stability Level**: 3 - Stable
- scheduledActions: Returns the matching scheduled actions. The cursors in the returned connections are usable for 5
minutes after the most recent request in the cursored results, with a maximum lifetime of 1 hour.

**Stability Level**: 3 - Stable
- sensors: Returns the matching sensors. The cursors in the returned connections are usable for 5 minutes
after the most recent request in the cursored results, with a maximum lifetime of 1 hour.

**Stability Level**: 3 - Stable
- software: **Stability Level**: 0 - Deprecated
- softwareDeployment: Returns the details of software package deployments. If you specify a deployment ID, this returns
the details of that deployment. If you do not specify a deployment ID, this returns the details of all deployments.

Use of this field requires the Deploy solution.

**Stability Level**: 3 - Stable
- softwarePackages: Returns the software package catalog from Deploy.

Use of this field requires the Deploy solution.

**Stability Level**: 3 - Stable
## Mutations
- actionCreate: Creates an action.

**Stability Level**: 3 - Stable
- actionGroupCreate: Creates an action group from the given input.

**Stability Level**: 3 - Stable
- actionGroupDelete: Deletes an action group with the given input.

**Stability Level**: 3 - Stable
- actionPerform: Creates the actions or scheduled actions necessary to perform the request. This can run a specific
package or a registered operation.

**Stability Level**: 3 - Stable
- actionStop: Stops an action in progress.

**Stability Level**: 3 - Stable
- apiTokenGrant: Creates an API token for the current user.

If you specify a persona, the created token uses the persona's permissions.

Use a unique token for each process. For example, when integrating ServiceNow and Splunk, ensure both services have unique tokens.
In another example: when implementing multiple ServiceNow instances or when implementing multiple connections from one ServiceNow
instance to Tanium Server, ensure each has its own token. When a token expires or is rotated for any process, that token stops working for any other processes that use it.

**Stability Level**: 3 - Stable
- apiTokenRevoke: Deletes the API token with the specified ID.

**Stability Level**: 3 - Stable
- apiTokenRotate: Rotates the API token with the specified token string. The original API token is no longer valid after rotation.
The input `tokenString` must belong to the user submitting the request or the response returns an error.

The new API token maintains applicable properties of the original API token, including persona, trusted IP addresses and notes.
If you integrate your Tanium deployment with another platform such as ServiceNow or Splunk, use the Tanium API to configure the
integration to automatically rotate its tokens before their expiration.

Use of this field requires the Tanium permission `Token - Use`.

**Stability Level**: 3 - Stable
- assetProducts: Changes product usage gathering metrics

Use of this field requires the Asset solution.

Use of this field requires the Tanium permission `asset api user write`.

**Stability Level**: 3 - Stable
- assetUpdateEndpoints: Update endpoint records based on the given source. This uses the Asset entity and attribute model
to update entity values into the endpoints of the given source.

The keys for the given source must be provided as entity values. If the keys do not exist, an error
is returned. The keys are used to find an existing endpoint to update. If there is no match, an error
will be returned.

The Time To Live (TTL) timestamp for both Asset and TDS is not changed.

If the source supports reconciliation and the reconciliation keys are contained within the updated endpoint, the update
follows reconciliation logic.

Updating directly into the Tanium-managed source is allowed for custom entities.

For more information, see [Tanium Asset User Guide: Configuring Sources](https://help.tanium.com/bundle/ug_asset_cloud/page/asset/sources.html)

Use of this field requires the Asset solution.

Use of this field requires the Tanium permission `Asset Api User Write`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- assetUpdateEndpointsUsingEid: Update endpoint records based on the given source. This uses the Asset entity and attribute model
to update entity values into the endpoints of the given source.

The endpoint ID (EID) must be provided for the given source. If the EID is not allocated to the source namespace,
the response returns an error. The existing endpoint matching the EID is updated.

The Time To Live (TTL) timestamp for both Asset and TDS is not changed.

If the source supports reconciliation and the reconciliation keys are contained within the updated endpoint, the update
follows reconciliation logic.

Updating directly into the Tanium-managed source is allowed for custom entities.

For more information, see [Tanium Asset User Guide: Configuring Sources](https://help.tanium.com/bundle/ug_asset_cloud/page/asset/sources.html)

Use of this field requires the Asset solution.

Use of this field requires the Tanium permission `Asset Api User Write`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- assetUpsertEndpoints: Upsert endpoint records in the given Asset Import API source. This uses the Asset entity and attribute model
to upsert entity values into the endpoints of the given source.

The keys for the given source must be provided as entity values. If the keys do not exist, an error
is returned. The keys are used to find an existing endpoint to update. If there is no match, a new endpoint is created.

The Time To Live (TTL) timestamp is updated for both Asset and TDS.

If the source supports reconciliation and the reconciliation keys are contained within the updated endpoint, the update
follows reconciliation logic.

For more information, see [Tanium Asset User Guide: Configuring Sources](https://help.tanium.com/bundle/ug_asset_cloud/page/asset/sources.html)

Use of this field requires the Asset solution.

Use of this field requires the Tanium permission `Asset Api User Write`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- assetsImport: Creates or updates assets for the Asset solution.

Use of this field requires the Asset solution.

Use of this field requires the Tanium permission `asset api user write`.

**Stability Level**: 0 - Deprecated
- closeDirectConnection: Closes an open Direct Connect connection.

The input requires a direct endpoint connection opened using `openDirectConnection`.

Use of this field requires the Direct Connect solution.

**Stability Level**: 2 - Legacy
Use `directConnectClose` instead. The `directConnect` APIs provide better support for tracking connections that take longer to establish.

Deprecated in May 2023.
- computerGroupCreate: Creates a standard computer group from the given input.

**Stability Level**: 3 - Stable
- computerGroupDelete: Deletes a computer group with the given input.

**Stability Level**: 3 - Stable
- connectConnectionStart: Starts a connection run.

Use of this field requires the Connect solution.

Use of this field requires the Tanium permission `Connect - Run`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- connectConnectionStop: Stops an in-progress connection run.
This has no effect on connection runs that are not in progress.

Use of this field requires the Connect solution.

Use of this field requires the Tanium permission `Connect - Run`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- createAction: Creates a saved action that changes endpoint state.

**Stability Level**: 0 - Deprecated
- deleteAction: Deletes the saved actions matching the input argument.

**Stability Level**: 0 - Deprecated
- deleteConfigurationItemElement: Deletes the specified configuration item elements. Only customer-supplied elements can be deleted.

Use of this field requires the Atlas solution.

**Stability Level**: 0 - Deprecated
- deleteRelationship: Deletes the specified relationships.

Use of this field requires the Atlas solution.

**Stability Level**: 0 - Deprecated
- deploymentPlanPerformOperation: This is intended for Tanium internal use, and should not be used by customers.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Write Deployment Plan`.

**Stability Level**: 1.1 - Experimental (Active Development)
- deploymentPlanUpsert: This is intended for Tanium internal use, and should not be used by customers.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Write Deployment Plan`.

**Stability Level**: 1.1 - Experimental (Active Development)
- directConnectClose: Closes an open Direct Connect connection.

The input requires a direct endpoint connection opened using `directConnectOpen`.

Use of this field requires the Direct Connect solution.

Use of this field requires the Tanium permission `Direct Connect Session Write`.

**Stability Level**: 3 - Stable
- directConnectOpen: Initiates a Direct Connect connection with an endpoint, returning a connection ID which
you can use for Direct Connect queries.

A response will be returned within 25 seconds.  If the connection has not been successfully
established within that time frame, you can use the `directConnectConnectionStatus` query with the
returned connection ID to poll for readiness.

An open connection is closed after 5 minutes of inactivity.

Connections opened with `directConnectOpen` are compatible with stable Direct Connect APIs, including
`directConnectEndpoint`, `directConnectPing`, `directConnectProcessTerminate`, and `directConnectClose`.

Connections opened with `directConnectOpen` are not compatible with legacy Direct Connect APIs, including
`directEndpoint`, `pingDirectConnection`, `killProcess`, and `closeDirectConnection`.

Use of this field requires the Direct Connect solution.

Use of this field requires the Tanium permission `Direct Connect Session Write`.

**Stability Level**: 3 - Stable
- directConnectPing: Performs a ping to an endpoint using an open Direct Connect connection.

The input requires a direct endpoint connection opened using `directConnectOpen`.

Use of this field requires the Direct Connect solution.

Use of this field requires the Tanium permission `Direct Connect Session Write`.

**Stability Level**: 3 - Stable
- directConnectProcessTerminate: Terminates the specified process on an endpoint using an open Direct Connect connection.

The input requires a direct endpoint connection opened using `directConnectOpen`.

Use of this field requires the Direct Connect, Performance solutions.

Use of this field requires the Tanium permission `Performance Kill Process`.

**Stability Level**: 3 - Stable
- discoverInterfaceAddLabel: Adds standard labels to specific Discover interfaces.

Use of this field requires the Tanium permission `Discover Tag - Write`.

**Stability Level**: 1.1 - Experimental (Active Development)
- discoverInterfaceRemoveLabel: Removes standard labels from specific Discover interfaces.

Use of this field requires the Tanium permission `Discover Tag - Write`.

**Stability Level**: 1.1 - Experimental (Active Development)
- discoverLabelCreate: Creates a Discover label from the given input.

Use of this field requires one of the following Tanium permissions: `Discover Tag - Write`, `Discover Location Permissions - Write`.

Note: `Discover Location Permissions - Write` is required when there is at least one Location Permission defined in Discover. Otherwise, `Discover Tag - Write` is required.

**Stability Level**: 1.1 - Experimental (Active Development)
- discoverLabelDelete: Deletes a Discover label with the given input.

Use of this field requires one of the following Tanium permissions: `Discover Tag - Write`, `Discover Location Permissions - Write`.

Note: `Discover Location Permissions - Write` is required when there is at least one Location Permission defined in Discover. Otherwise, `Discover Tag - Write` is required.

**Stability Level**: 1.1 - Experimental (Active Development)
- emailSend: Submits a request to the Tanium Email service to send an email using a selected email server.

Use of this field requires the Email solution.

Use of this field requires the Tanium permission `Email Send`.

**Stability Level**: 1.0 - Experimental (Early Development)
- importConfigurationItemEntities: Imports the specified entities. If an `id` is specified, the existing entity matching that `id` is updated. If no `id` is specified, a new entity is created.

You can specify a maximum of 100 entities. The request fails if you exceed 100 entities.
The response returns entities in the same order as specified in the input.
Entities that fail to import have an `errorMessage`.

Use of this field requires the Atlas solution.

**Stability Level**: 0 - Deprecated
- installSoftware: Use of this field requires the Deploy solution.

**Stability Level**: 0 - Deprecated
- integrityMonitorMonitorCreate: Create an Integrity Monitor monitor.

For more information, see [Tanium Integrity Monitor User Guide: Create or edit a monitor](https://help.tanium.com/bundle/ug_integrity_monitor_cloud/page/integrity_monitor/monitors.html#create)

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Monitors Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorMonitorMarkForDeletion: Mark an Integrity Monitor monitor for deletion.

If the monitor has never been deployed, it is deleted immediately.
If the monitor is deployed, it is marked for deletion on the next deployment. The status is changed to `PendingDeletion`. During the next deployment, the monitor is deleted.

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Monitors Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorMonitorUpdate: Update an Integrity Monitor monitor.

For more information, see [Tanium Integrity Monitor User Guide: Create or edit a monitor](https://help.tanium.com/bundle/ug_integrity_monitor_cloud/page/integrity_monitor/monitors.html#create)

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Monitors Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorStartMonitorDeployment: Deploy all Integrity Monitor monitors.

Monitor deployment generally completes within a minute, but might take several minutes or more, depending on the total number of monitors. Once completed, the deployment does not guarantee that any targeted endpoints have received the most recent monitor. For example, the deployed monitor might still be awaiting approval in Endpoint Configuration, or might not yet be delivered to offline endpoints.

For the best results, create all planned monitors, and then deploy them at the same time. If you deploy monitors as a user with restricted management rights, the set of management rights is applied to all deployed monitors. All monitors are removed from any endpoints that are not a member of the updated computer management groups. Ensure the same set of computer management groups are assigned to all users who are allowed to deploy monitors.

Monitor deployment might take several minutes or more. Any monitors with a `deploymentStatus` of `PendingDeletion` are deleted during deployment. Otherwise, monitors have a `deploymentStatus` of `Deploying` during deployment.

Use `query.integrityMonitorStatus.isDeployingMonitors` to verify the current monitor deployment status. If this is equal to `false`, the deployment is complete.

If there are no monitor updates and no monitors to delete since the most recent deployment, this redeploys all monitors.

For more information, see [Tanium Integrity Monitor User Guide: Deploy monitors](https://help.tanium.com/bundle/ug_integrity_monitor_cloud/page/integrity_monitor/monitors.html#deploy)

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Deploy Monitors`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorStartWatchlistDeployment: Deploy all Integrity Monitor watchlists.

Deploying watchlists does not guarantee that any targeted endpoints have received the most recent watchlist. For example, the deployed watchlist might still be awaiting approval in Endpoint Configuration, or might not yet be delivered to offline endpoints.

For the best results, create all planned watchlists, and then deploy them at the same time. If you deploy watchlists as a user with restricted management rights, the set of management rights is applied to all deployed watchlists. All watchlists are removed from any endpoints that are not a member of the updated computer management groups. Ensure the same set of computer management groups are assigned to all users who are allowed to deploy watchlists.

Any watchlists with a `deploymentStatus` of `PendingDeletion` are deleted during deployment.

Watchlist deployment might take several minutes or more. Use `query.integrityMonitorStatus.isDeployingWatchlists` to verify the current watchlist deployment status. If this is equal to `false`, the deployment is complete. During deployment, all watchlists have a `deploymentStatus` of `Deploying`.

For more information, see [Tanium Integrity Monitor User Guide: Deploy watchlists](https://help.tanium.com/bundle/ug_integrity_monitor_cloud/page/integrity_monitor/watchlist.html#deploy)

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Deploy Watchlists`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorWatchlistCreate: Create an Integrity Monitor watchlist.

The response returns an error if an existing watchlist contains the same `name` and `pathStyle` values.

For more information, see [Tanium Integrity Monitor User Guide: Create or edit a watchlist](https://help.tanium.com/bundle/ug_integrity_monitor_cloud/page/integrity_monitor/watchlist.html#create_watchlist)

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Watchlists Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorWatchlistMarkForDeletion: Mark an Integrity Monitor watchlist for deletion on next deployment.

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Watchlists Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorWatchlistPathDelete: Delete an Integrity Monitor watchlist path.

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Watchlists Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorWatchlistUnixPathCreate: Create an Integrity Monitor watchlist path with a `pathStyle` of `Unix` in an existing watchlist.

For more information, see [Tanium Integrity Monitor User Guide: Add and edit paths](https://help.tanium.com/bundle/ug_integrity_monitor_cloud/page/integrity_monitor/watchlist.html#add_path)

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Watchlists Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorWatchlistUnixPathUpdate: Update an existing Integrity Monitor watchlist path with a `pathStyle` of `Unix`.

For more information, see [Tanium Integrity Monitor User Guide: Add and edit paths](https://help.tanium.com/bundle/ug_integrity_monitor_cloud/page/integrity_monitor/watchlist.html#add_path)

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Watchlists Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorWatchlistUpdate: Update an Integrity Monitor watchlist.

The response returns an error if the name is changed to match a watchlist with the same `name` and `pathStyle`.

For more information, see [Tanium Integrity Monitor User Guide: Create or edit a watchlist](https://help.tanium.com/bundle/ug_integrity_monitor_cloud/page/integrity_monitor/watchlist.html#create_watchlist)

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Watchlists Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorWatchlistWindowsFilePathCreate: Create an Integrity Monitor watchlist path with a `watchlistPathType` of `File` and a `pathStyle` of `Windows` in an existing watchlist.

For more information, see [Tanium Integrity Monitor User Guide: Add and edit paths](https://help.tanium.com/bundle/ug_integrity_monitor_cloud/page/integrity_monitor/watchlist.html#add_path)

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Watchlists Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorWatchlistWindowsFilePathUpdate: Update an existing Integrity Monitor watchlist path with a `watchlistPathType` of `File` and a `pathStyle` of `Windows`.

For more information, see [Tanium Integrity Monitor User Guide: Add and edit paths](https://help.tanium.com/bundle/ug_integrity_monitor_cloud/page/integrity_monitor/watchlist.html#add_path)

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Watchlists Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorWatchlistWindowsRegistryPathCreate: Create an Integrity Monitor watchlist path with a `watchlistPathType` of `Registry` and a `pathStyle` of `Windows` in an existing watchlist.

For more information, see [Tanium Integrity Monitor User Guide: Add and edit paths](https://help.tanium.com/bundle/ug_integrity_monitor_cloud/page/integrity_monitor/watchlist.html#add_path)

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Watchlists Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- integrityMonitorWatchlistWindowsRegistryPathUpdate: Update an existing Integrity Monitor watchlist path with a `watchlistPathType` of `Registry` and a `pathStyle` of `Windows`.

For more information, see [Tanium Integrity Monitor User Guide: Add and edit paths](https://help.tanium.com/bundle/ug_integrity_monitor_cloud/page/integrity_monitor/watchlist.html#add_path)

Use of this field requires the Integrity Monitor solution.

Use of this field requires the Tanium permission `Integrity Monitor Watchlists Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- killProcess: Terminates the specified process on an endpoint using a Direct Connect connection.

The input requires a direct endpoint connection opened using `openDirectConnection`.

Use of this field requires the Direct Connect solution.

**Stability Level**: 2 - Legacy
Use `directConnectProcessTerminate` instead. The `directConnect` APIs provide better support for tracking connections that take longer to establish.

Deprecated in May 2023.
- manageSoftware: Creates a new Deploy software package deployment to install, update, or remove a software
package.

Use of this field requires the Deploy solution.

**Stability Level**: 3 - Stable
- mergeConfigurationItemElements: Merges two configuration item elements.
The target element must be private if the duplicate element is private.
The two elements must inherit from the same class.
The target element must be in the category of "ManagedEndpoint" or "UnmanagedEndpoint".
The duplicate element must be in the category of "UnmanagedEndpoint" or "CustomerItem".
If the duplicate element category is "UnmanagedEndpoint", it must have a namespace of "unmanaged_user_specified".
Comments, details, and the relationships are copied.
Duplicate relationships or inverse relationships are deleted.
The duplicate element is deleted.

Use of this field requires the Atlas solution.

**Stability Level**: 0 - Deprecated
- openDirectConnection: Establishes a Direct Connect connection with an endpoint, returning a connection ID which
you can use for Direct Connect queries.

The connection is closed after 2 minutes of inactivity.

Connections opened with `openDirectConnection` are compatible with legacy Direct Connect APIs, including
`directEndpoint`, `pingDirectConnection`, `killProcess`, and `closeDirectConnection`.

Connections opened with `openDirectConnection` are not compatible with stable Direct Connect APIs, including
`directConnectEndpoint`, `directConnectPing`, `directConnectProcessTerminate`, and `directConnectClose`.

Use of this field requires the Direct Connect solution.

**Stability Level**: 2 - Legacy
Use `directConnectOpen` instead. The `directConnect` APIs provide better support for tracking connections that take longer to establish.

Deprecated in May 2023.
- patchCreateDeployment: Create a Patch deployment.

Use of this field requires the Patch solution.

Use of this field requires all of the following Tanium permissions: `Patch Deployment - Execute`, `Patch Deployment - Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- patchListUpsert: Upserts a patch list based on the `patchList` ID value. If a non-deleted patch list matches the `patchList` ID, update the existing patch list.
If no patch list matches the `patchList` ID, create a new patch list.

Deleted patch lists are soft-deleted and remain in the database, with a timestamp of deletion time.
If a deleted patch list matches the `patchList` ID, the mutation returns a `cannot be updated` system error.

If this request updates an existing patch list, a new version is created, and the `versionID` increments by `1`.

For the best results, define `rules` with conditions to add as many desired patch definitions as possible to the patch list.
Minimize the definition of individual `patchDefinitionIds` in the input.

Use of this field requires the Patch solution.

Use of this field requires all of the following Tanium permissions: `Patch Patchlist execute`, `Patch Patchlist write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- patchStopDeployment: Stops the in-progress Patch deployment that matches the reference ID, or prevents the future-scheduled Patch deployment that matches the reference ID from starting at the start time. This has no effect on finished deployments.

Use of this field requires the Patch solution.

Use of this field requires all of the following Tanium permissions: `Patch Deployment - Execute`, `Patch Deployment - Write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- ping: Returns `true`. Useful to test your ability to issue commands to the server.

**Stability Level**: 3 - Stable
- pingDirectConnection: Performs a ping to an endpoint using a Direct Connect connection.

The input requires a direct endpoint connection opened using `openDirectConnection`.

Use of this field requires the Direct Connect solution.

**Stability Level**: 2 - Legacy
Use `directConnectPing` instead. The `directConnect` APIs provide better support for tracking connections that take longer to establish.

Deprecated in May 2023.
- playbookContentSetUpdate: Updates the content set of a specified playbook by 'id'.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Automate Playbook Write`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- playbookPerformOperation: Performs an operation enumerated in `PlaybookOperation` on a playbook.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Automate Playbook Write`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- playbookPreview: Get the result of creating a playbook, but does not create a new playbook. Use this to preview and verify playbook configuration before using `mutation.playbookUpsert` to create a new playbook.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Automate Playbook Write`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- playbookRunPerformOperation: Performs an operation enumerated in `PlaybookRunOperation` on a playbook run.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Automate Playbook Execute`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- playbookSchedulePerformOperation: Performs an operation enumerated in `PlaybookScheduleOperation` on a playbook schedule.
Enabling a schedule requires the `Automate Playbook Execute` permission.
Disabling or deleting a schedule created by another user, or created by your user with a different active persona, requires the `Automate Playbook Write` permission.
Disabling or deleting a schedule you created with your currently active persona requires either the `Automate Playbook Execute` or `Automate Playbook Write` permission.
This operation might not be applied immediately. See the `applyingUpdates` field for more information.

Use of this field requires the Automate solution.

Use of this field requires one of the following Tanium permissions: `Automate Playbook Write`, `Automate Playbook Execute`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- playbookScheduleUpsert: Upserts a playbook schedule based on the playbook schedule `id`. If a playbook schedule matches the `id`, updates the existing
playbook schedule. If no playbook schedule matches the `id`, creates a new playbook schedule.
For update operations, this atomically updates the entire record.
This upsert operation might not be applied immediately. See the `applyingUpdates` field for more information.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Automate Playbook Execute`.

**Stability Level**: 3 - Stable
- playbookStart: Starts a playbook.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Automate Playbook Execute`.

**Stability Level**: 3 - Stable
- playbookUpsert: Upserts a playbook based on the playbook `id`. If a playbook matches the `id`, updates the existing playbook. If no playbook matches the `id`, creates a new playbook.
For update operations, this atomically updates the entire record.

Use of this field requires the Automate solution.

Use of this field requires the Tanium permission `Automate Playbook Write`.

**Stability Level**: 3 - Stable
- provisionCancelRetirementAction: Cancel the pending retirement action that matches the ID. The `ProvisionRetirementAction.status`
value must be equal to `Pending`.

For more information, see [Tanium Provision User Guide: Retiring and locking devices](https://help.tanium.com/bundle/ug_provision_cloud/page/provision/retiring_devices.html)

Use of this field requires the Provision solution.

Use of this field requires the Tanium permission `Provision Retirement Actions write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- provisionCreateRetirementAction: Creates a new retirement action.

For more information, see [Tanium Provision User Guide: Retiring and locking devices](https://help.tanium.com/bundle/ug_provision_cloud/page/provision/retiring_devices.html)

Use of this field requires the Provision solution.

Use of this field requires the Tanium permission `Provision Retirement Actions write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- provisionCreateRetirementActionDefinition: Create a retirement action definition. For information about the retirement actions that you can
define, see `ProvisionCreateRetirementActionDefinitionInput`.

For more information, see [Tanium Provision User Guide: Retiring and locking devices](https://help.tanium.com/bundle/ug_provision_cloud/page/provision/retiring_devices.html)

Use of this field requires the Provision solution.

Use of this field requires the Tanium permission `Provision Retirement Action Definitions write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- provisionDeleteRetirementActionDefinitions: Delete the retirement action definitions that match the input IDs.

For more information, see [Tanium Provision User Guide: Retiring and locking devices](https://help.tanium.com/bundle/ug_provision_cloud/page/provision/retiring_devices.html)

Use of this field requires the Provision solution.

Use of this field requires the Tanium permission `Provision Retirement Action Definitions write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- provisionResolveRetirementAction: Update a retirement action status from `In Progress` to `Complete`.

For more information, see [Tanium Provision User Guide: Retiring and locking devices](https://help.tanium.com/bundle/ug_provision_cloud/page/provision/retiring_devices.html)

Use of this field requires the Provision solution.

Use of this field requires the Tanium permission `Provision Retirement Actions write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- provisionUpdateRetirementAction: Update retirement action notes for `requestedBy`, `comment`, or `ticketNumber`.
This mutation does not support updating any other retirement action fields.

For more information, see [Tanium Provision User Guide: Retiring and locking devices](https://help.tanium.com/bundle/ug_provision_cloud/page/provision/retiring_devices.html)

Use of this field requires the Provision solution.

Use of this field requires the Tanium permission `Provision Retirement Actions write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- provisionUpdateRetirementActionDefinition: Update a retirement action definition that matches the ID.

For more information, see [Tanium Provision User Guide: Retiring and locking devices](https://help.tanium.com/bundle/ug_provision_cloud/page/provision/retiring_devices.html)

Use of this field requires the Provision solution.

Use of this field requires the Tanium permission `Provision Retirement Action Definitions write`.

**Stability Level**: 1.0 - Experimental (Early Development)
- removeSoftware: Use of this field requires the Deploy solution.

**Stability Level**: 0 - Deprecated
- reportDelete: Deletes a report.

Use of this field requires the Reporting solution.

Use of this field requires the Tanium permission `Report Write`.

**Stability Level**: 1.2 - Experimental (Release Candidate)
- reportImport: Imports a report definition that was previously exported using the API Gateway `reportExport` query.

Use of this field requires the Reporting solution.

**Stability Level**: 3 - Stable
- reportingDashboardDelete: Deletes a Reporting dashboard.

Use of this field requires the Reporting solution.

Use of this field requires the Tanium permission `Dashboard Write`.

**Stability Level**: 1.1 - Experimental (Active Development)
- ringDeploymentChangeWait: Change a wait progression criteria on a ring deployment.
This is intended for Tanium internal use, and should not be used by customers.

Use of this field requires the Automate solution.

**Stability Level**: 1.1 - Experimental (Active Development)
- ringDeploymentPerformOperation: Perform an operation on a ring deployment.
This is intended for Tanium internal use, and should not be used by customers.

Use of this field requires the Automate solution.

**Stability Level**: 1.1 - Experimental (Active Development)
- ringDeploymentSendSignal: Send a signal to a ring deployment.
This is intended for Tanium internal use, and should not be used by customers.

Use of this field requires the Automate solution.

**Stability Level**: 1.1 - Experimental (Active Development)
- ringDeploymentStart: Start a ring deployment.
This is intended for Tanium internal use, and should not be used by customers.

Use of this field requires the Automate solution.

**Stability Level**: 1.1 - Experimental (Active Development)
- scheduledActionApprove: Approves a pending scheduled action.

**Stability Level**: 3 - Stable
- scheduledActionCreate: Creates a scheduled action.

**Stability Level**: 3 - Stable
- scheduledActionDelete: Deletes a scheduled action.

**Stability Level**: 3 - Stable
- sensorHarvest: Manages the registration of a sensor for harvest by TDS.

Note that when registering a sensor for harvest, the system must verify that the sensor is valid
for harvest. This analysis may take several minutes. To accommodate this, the response may contain
a cursor instead of a success or an error. When a response contains a cursor, the caller must call
the mutation again with the cursor added to the input in order to poll for the terminal response.

It is not necessary to poll for the terminal response in order for a harvest to be successful, but
it is not guaranteed that a harvest is successful unless the caller obtains a terminal successful
response.

**Stability Level**: 3 - Stable
- syncAssets: Synchronizes assets from TDS.

Use of this field requires the Atlas solution.

**Stability Level**: 0 - Deprecated
- threatResponseAlertResolve: Resolves the identified Threat Response alert.

Use of this field requires the Tanium permission `Threat Response Alerts Write`.

**Stability Level**: 3 - Stable
- updateConfigurationItemProperties: Updates properties related to configuration items.

Use of this field requires the Atlas solution.

**Stability Level**: 0 - Deprecated
- upsertEntity: **Stability Level**: 0 - Deprecated
- upsertRelationship: Creates or updates relationships between configuration items within the CMDB.
Returns the created or updated relationships.

Use of this field requires the Atlas solution.

**Stability Level**: 0 - Deprecated
## Directives
- include: Directs the executor to include this field or fragment only when the `if` argument is true.
- skip: Directs the executor to skip this field or fragment when the `if` argument is true.
- deprecated: Marks an element of a GraphQL schema as no longer supported.
- specifiedBy: Exposes a URL that specifies the behavior of this scalar.
- oneOf: Indicates exactly one field must be supplied and this field must not be `null`.
## Unions
- AutomateTaskArgument: All Automate task arguments. A task is the work done by a playbook step. A
playbook step contains a single task. A task argument defines the arguments
given to a task, such as deploying an action or waiting for user confirmation.
- AutomateTaskArgumentEndpoint: A subset of task arguments that can be used in an endpoint-level execution
block. Steps in an endpoint-level execution block are processed individually for
each targeted endpoint, as opposed to non endpoint-level execution which waits for
an action to affect all endpoints before proceeding to the next step.
- AutomateTaskResult: All Automate task results. A task result defines output from a task
when it is in progress or has completed. Some examples include confirmation details
for tasks that require confirmation or progress details for tasks that report
their progress.
- PlaybookScheduleSpecification: The schedule specification that determines when to run the associated playbook.
- PlaybookStepTargeting: The endpoint targeting criteria that the step uses for evaluation.
- ProgressionConditionResultValueV2: A ring deployment progression criteria result value.
- RingDeploymentAction: All ring deployment actions.
## Scalars
- ID: The `ID` scalar type represents a unique identifier, often used to refetch an object or as key for a cache. The ID type appears in a JSON response as a String; however, it is not intended to be human-readable. When expected as an input type, any string (such as `"4"`) or integer (such as `4`) input value will be accepted as an ID.
- String: The `String` scalar type represents textual data, represented as UTF-8 character sequences. The String type is most often used by GraphQL to represent free-form human-readable text.
- Int: The `Int` scalar type represents non-fractional signed whole numeric values. Int can represent values between -(2^31) and 2^31 - 1.
- Boolean: The `Boolean` scalar type represents `true` or `false`.
- Any: An untyped value.
- Float: The `Float` scalar type represents signed double-precision fractional values as specified by [IEEE 754](https://en.wikipedia.org/wiki/IEEE_floating_point).
- CronExpression: A cron expression string used for scheduling.

Cron expressions are interpreted according to the GNU
[Crontab](https://www.gnu.org/software/mcron/manual/html_node/Crontab-file.html) format.

Six or seven segment cron expressions (years and seconds) are not supported. The `#` operator is not
supported.
- Cursor: A relay pagination cursor, which is an opaque string that specifies a record
within a connection.
- Date: A string date in RFC 3339 long-date format.
- DateTimeComponent: undefined
- JSONNumber: undefined
- Map: A map of JSON data.
- ParameterDefinitionType: undefined
- Time: An instant in time in RFC 3339 format.
## Interfaces
- Asset: A generic asset, such as an endpoint.
- AutomateTaskResultWithCompletedEndpointsTargeting: The result of a task that returns endpoint targeting for endpoints that completed the task.
- AutomateTaskResultWithConfirmation: The result of a task that requires a user confirmation.
- AutomateTaskResultWithProgress: The result of a task that reports its progress.
- CIEntity: An item managed in the CMDB.
- Connection: A page of records.
- Edge: A record within a page.
- EndpointTargeting: The evaluation used to target endpoints for Tanium interaction.
- RingDeploymentEvent: A ring deployment event.
## Enums
- ActionGroupVisibility: Defines the visibility of action groups.
- ActionOperationChangeClientSettingName: A Tanium Client setting name.
- ActionStatus: The action status values.
- AssetImportStatus: Status of a given asset's import.
- AssetProductState: The product tracking state.
- AssetProductUsageEnum: The product usage values.
- AssetUpdateResultType: The status of an asset update.
- AssetUpsertResultType: The status of an asset upsert.
- AutomateTaskProgressState: The playbook run step progress states.
- ComputerGroupType: The computer group type values.
- ConnectRunStatus: The status of the last connection run.
- ConnectedState: The set of connected states of wireless adapters.
- DayOfWeek: The day of the week for scheduling.
- DeploymentPlanOperation: Operations available to perform on a deployment plan.
- DeploymentPlanSortField: Available deployment plan fields to sort by.
- DirectConnectConnectionStatus: The set of statuses for a Direct Connect connection.
- DiscoverLabelType: The Discover label type.
- DiscoveryMethod: The method by which an interface was discovered.
- EdgeDirection: The set of directions of relationships between configuration item entities.
- EmailBodyType: Email body content type.
- EndpointPlatform: The set of endpoint platforms.
- EndpointScope: Defines the scope of entities queried. Equivalent to the difference between "from all machines" and "from all entities" when asking a question in Tanium Interact.
- EndpointServiceStartupMode: The set of service startup modes.
- EndpointServiceStatus: The status of a service on an endpoint.
- EntityCategory: The set of categories of configuration item entities.
- EntitySortField: The set of fields by which entities can be sorted.
- FieldFilterOp: The set of operations permitted on `FieldFilter` instances.
- FilterField: The list of endpoint fields on which the assets query can be filtered.
- FilterMatch: The set of compound operators available on assets query filters.
- FilterOps: The set of operations allowed by the assets query filters.
- IntegrityMonitorMonitorDeploymentStatus: The monitor deployment status.

After you create, update, or delete a monitor, that monitor must be deployed to the Endpoint Configuration service before endpoints can use the most recent monitor configuration. Deployment status reflects only if the latest monitor configuration is sent to Endpoint Configuration.
Use the `integrityMonitorStartMonitorDeployment` mutation to deploy monitors.
A `Deployed` status does not guarantee that targeted endpoints have the most recent monitor configuration. For example, the deployed monitor might be awaiting approval in Endpoint Configuration, or offline endpoints might not be updated.
- IntegrityMonitorWatchlistDeploymentStatus: The deployment status of a watchlist.

After creation or any updates to a watchlist, the watchlist must be deployed to the Endpoint Configuration service in order for endpoints to use those changes. Deployment status is only intended to show if the latest watchlist changes have been sent to Endpoint Configuration. A Deployed status does not guarantee that any targeted endpoints have received the most recent watchlist. For example, the deployed watchlist might still be awaiting approval in Endpoint Configuration, or might not yet be delivered to offline endpoints.
- IntegrityMonitorWatchlistPathStyle: The style of paths included in a watchlist. Watchlists using a Windows path style can include both file paths and registry paths.
- IntegrityMonitorWatchlistPathType: The type of watchlist path.
- Modifiers: undefined
- PatchContentDeploymentType: Content deployment type.
- PatchDefinitionSeverity: The severity status assigned to a patch definition pulled from either the CVE translator or package managers.
- PatchDefinitionSortField: Available patch definition fields to sort by.
- PatchDeploymentStatus: Patch deployment status.
- PatchDeploymentType: The operation a Patch deployment performs.
- PatchEndpointPlatform: Endpoint platforms supported by Patch.
- PatchListRuleConditionComparisonOperator: The set of operations permitted for patch list rules.
- PatchListRuleConditionFieldName: Field names supported by patch list rules.
- PatchScheduleType: Patch deployment scheduling options.
- PerfQueryType: The set of performance query types.
- PlaybookNotificationEventType: Events that can trigger a playbook notification.
- PlaybookNotificationMethod: Methods for sending playbook notifications.
- PlaybookOperation: Operations available to perform on a playbook.
- PlaybookPatchContentDeploymentType: Content deployment type.
- PlaybookPatchEndpointPlatform: Endpoint platforms supported by Patch.
- PlaybookRunEventType: An enumeration of playbook run event types.
- PlaybookRunOperation: Operations available to perform on a playbook run.
- PlaybookRunSortField: Available playbook run fields to sort by.
- PlaybookRunStatus: All playbook run states, used for both playbook run and playbook run steps.
- PlaybookScheduleEventType: An enumeration of playbook schedule event types.
- PlaybookScheduleOperation: Operations available to perform on a playbook schedule.
- PlaybookSoftwareDeploymentOperation: The software deployment operations.
- PlaybookSortField: Available playbook fields to sort by.
- ProgressionConditionResultState: Progression condition result states.
- ProvisionFilterField: The set of fields by which entities can be filtered.
- ProvisionRetirementActionDefinitionNotesRequired: How users are allowed to create or update this retirement action note.
- ProvisionRetirementActionEventLogStatus: Status of a retirement action step.
- ProvisionRetirementActionSortField: The set of fields by which retirement actions can be sorted.
- ProvisionRetirementActionStatus: Status of a retirement action.
- RelationshipSortField: The set of fields by which relationships may be sorted.
- RingDeploymentActionType: Types of deployment actions that you can issue to targeted endpoints.
- RingDeploymentOperation: All available ring deployment operations.
- RingDeploymentRingProgressState: The ring deployment progress states.
- RingDeploymentSortField: Available ring deployment fields to sort by.
- RingDeploymentStatus: Ring deployment statuses.
- RingStatus: Ring statuses for individual rings within a ring deployment.
- ScheduledActionStatus: The status of a scheduled action.
- SensorResultValueType: Describes the interpretation of the sensor result value as pertains to filtering and ordering. Note
the system does not enforce and cannot guarantee the type-safety of the underlying strings.
- SensorScriptType: The types of sensor scripts allowed by the platform.
- SensorValueFilterOp: The set of operations permitted on `SensorValueFilter` instances.
- SettingName: The controllable client settings.
- Signal: The set of signals that can be sent to processes.
- SoftwareDeploymentStatusLabel: The set of status labels for a software deployment.
- SoftwareOperation: The set of operations permitted for software package deployments.
- SortOrder: The directions in which entities can be sorted.
- StabilityLevel: The stability level of a field in the schema.
- TaniumPlatformRingType: The available ring types for a ring in a ring set.
## Objects
- APIToken: An authentication token that a user can use to make requests.
- APITokenGrantPayload: A response to a request to create an API token.
- APITokenQueryPayload: A response to a request to query API tokens.
- APITokenRevokePayload: A response to a request to revoke an API token.
- APITokenRotatePayload: A response to a request to rotate an API token.
- Action: An action.
- ActionConnection: A page of action edges.
- ActionCreatePayload: The result of creating an action.
- ActionEdge: An action within a page.
- ActionGroup: Defines which endpoints are the targets for actions.
- ActionGroupConnection: A page of action group edges.
- ActionGroupCreatePayload: A response to a request to create an action group.
- ActionGroupDeletePayload: A response to a request to delete an action group.
- ActionGroupEdge: An action group within a page.
- ActionInfo: An ID for a saved action.
- ActionPerformPayload: The result of performing an action.
- ActionPerformPlatform: A scheduled action and the operating systems on which it runs.
- ActionResults: The results of an action.
- ActionStopPayload: The result of stopping an action.
- ActionTargets: The endpoints on which an action runs. An endpoint must belong to both groups in order to run the
action.
- AssetImportPayload: Result for a single asset import.
- AssetPagination: A page of assets.
- AssetProduct: The Asset product.
- AssetProductConnection: A page of product edges.
- AssetProductEdge: A product within a page.
- AssetProductEndpoint: The Asset product endpoint.
- AssetProductEndpointConnection: A page of product endpoint edges.
- AssetProductEndpointEdge: A product endpoint within a page.
- AssetProductInstallation: Product installation metrics.
- AssetProductTracking: Product tracking metrics.
- AssetProductUsage: Product usage metrics.
- AssetProductVersion: Product version metrics.
- AssetProductsPayload: undefined
- AssetProductsResult: The Asset product mutation result.
- AssetSourceDefinition: The Asset source and namespace associated with this endpoint.

For more information, see [Tanium Asset User Guide: Configuring Sources](https://help.tanium.com/bundle/ug_asset_cloud/page/asset/sources.html)
- AssetUpdateResult: The result of updating an asset.
- AssetUpsertResult: The result of upserting an asset.
- AssetsImportPayload: Results for an asset import.
- AssetsUpdatePayload: The result of updating one or more assets.
- AssetsUpsertPayload: The result of upserting one or more assets.
- AutomateTaskArgumentConfirmation: The argument for a task that requires a user confirmation.
- AutomateTaskArgumentDeployAction: The argument for a task that deploys a Tanium action to the targeted endpoints.
- AutomateTaskArgumentDeploySoftwareDeployment: The argument for a task that creates a Deploy software deployment to the targeted endpoints.
- AutomateTaskArgumentEndpointConditionEvaluation: The argument for a task that evaluates a condition on an endpoint. This task can only run within
an endpoint-level execution block. If the condition is satisfied, the endpoint-level execution
continues. Otherwise, the endpoint-level execution ends. If this task is defined outside of an
endpoint-level execution block in a request, the response returns an error.
- AutomateTaskArgumentEndpointExecution: The argument for a task that runs a series of steps as an endpoint-level execution. In an
endpoint-level execution, after the first step ends on an endpoint, the next step immediately starts on that endpoint, and so on,
until all steps in the endpoint-level execution complete. These steps are not affected by the
status of the endpoint-level execution on other endpoints.
- AutomateTaskArgumentEndpointPackageExecution: The argument for a task that runs a package on an endpoint. This task can only run within
an endpoint-level execution block. If this task is defined outside of an endpoint-level
execution block in a request, the response returns an error.
- AutomateTaskArgumentEndpointRestart: The argument for a task that restarts an endpoint. This task can only run within
an endpoint-level execution block. If this task is defined outside of an endpoint-level
execution block in a request, the response returns an error.
- AutomateTaskArgumentInstruction: The argument for a task that displays an instruction to the user.
- AutomateTaskArgumentPatchInstallDeployment: The argument for a task that creates a Patch install deployment to the targeted endpoints.
- AutomateTaskArgumentRingBasedBlock: The argument for a task that progresses a block of steps through rings.
- AutomateTaskArgumentVerifyCondition: The argument for a task that evaluates the percentage of endpoints returned after targeting
endpoints. The task is successful if the percentage matches or exceeds the defined
`successPercentage` condition. The task fails if the percentage is below the defined
`successPercentage` condition. Later playbook steps cannot inherit targeting from steps that
reference an `AutomateTaskArgumentVerifyCondition` task argument.
- AutomateTaskArgumentWait: The argument for a task that waits the specified time `duration`.
- AutomateTaskLinkedResources: Linked resources that contain details on the entities. Only resources that are applicable to the task are populated.
- AutomateTaskProgress: The progress of an Automate task.
- AutomateTaskResultConfirmation: The result of a confirmation task.
- AutomateTaskResultDeployAction: The result of the deploy action task.
- AutomateTaskResultDeploySoftwareDeployment: The result of the deploy software deployment task.
- AutomateTaskResultEndpointConditionEvaluation: The result of the Endpoint Condition Evaluation task.
- AutomateTaskResultEndpointExecution: The result of the Endpoint Execution task.
- AutomateTaskResultEndpointPackageExecution: The result of the Endpoint Package Execution task.
- AutomateTaskResultEndpointRestart: The result of the Endpoint Restart task.
- AutomateTaskResultInstruction: The result of an instruction task.
- AutomateTaskResultPatchInstallDeployment: The result of the patch install deployment task.
- AutomateTaskResultRingBasedBlock: The result of the ring-based block task.
- AutomateTaskResultVerifyCondition: The result of the verify condition task.
- Class: A configuration item entity class.
- CloseDirectConnectionPayload: A response to a request to close a Direct Connect connection to an endpoint.
- ComputerGroup: Defines a set of endpoints that is managed as a group.
- ComputerGroupConnection: A page of computer group edges.
- ComputerGroupCreatePayload: A response to a request to create a standard computer group.
- ComputerGroupDeletePayload: A response to a request to delete a computer group.
- ComputerGroupEdge: A computer group within a page.
- ConfigurationItem: The CMDB reference IDs for an asset.
- ConfigurationItemEntityConnection: A page of configuration item entity edges.
- ConfigurationItemEntityEdge: A configuration item entity within a page.
- ConfigurationItemProperties: Properties of the configuration item CMDB.
- ConfigurationItemRelationshipConnection: A page of configuration item relationship edges.
- ConfigurationItemRelationshipEdge: A configuration item relationship within a page.
- ConnectConnection: A connection found in a Connect service.
- ConnectConnectionEdge: A connection within a page.
- ConnectConnectionStartPayload: The result of starting a connection.
- ConnectConnectionStopPayload: The result of stopping an in-progress connection run.
- ConnectGraphConnection: A page of connection edges.
- ConnectRun: A connection run found in a Connect service.
- ConnectRunConnection: A page of connection run edges.
- ConnectRunEdge: A connection run within a page.
- DefaultRangeEnd: undefined
- DeleteConfigurationItemElementResult: A response to a request to delete a configuration item element.
- DeploymentPlan: The configuration needed to deploy to specific endpoints.
- DeploymentPlanConnection: A page of deployment plan edges.
This is intended for Tanium internal use, and should not be used by customers.
- DeploymentPlanEdge: A deployment plan within a page.
This is intended for Tanium internal use, and should not be used by customers.
- DeploymentPlanPerformOperationPayload: The response to performing an operation on a deployment plan.
This is intended for Tanium internal use, and should not be used by customers.
- DeploymentPlanUpsertPayload: The response to upserting a deployment plan.
This is intended for Tanium internal use, and should not be used by customers.
- DirectConnect: Data from an endpoint, obtained using a Direct Connect connection.
- DirectConnectAlerts: Performance alerts from an endpoint.
- DirectConnectClosePayload: A response to a request to close a Direct Connect connection to an endpoint.
- DirectConnectConnectionStatusPayload: A response to a request to get the status for a Direct Connect connection.
- DirectConnectOpenPayload: A response to a request to initiate a Direct Connect connection to an endpoint.
- DirectConnectPerf: Performance data from an endpoint.
- DirectConnectPingPayload: A response to a request to ping an endpoint over a Direct Connect connection.
- DirectConnectProcessTerminatePayload: A response to a request to terminate a process.
- DirectConnectProcesses: Processes running on an endpoint.
- DiscoverCloudInstance: A Discover cloud instance.
- DiscoverCloudTag: A Discover cloud tag associated with an interface and assigned to an instance.
- DiscoverInterface: An interface found in a Discover network scan.
- DiscoverInterfaceAddLabelPayload: A response to a request to add one or more standard labels to specific Discover interfaces.
- DiscoverInterfaceConnection: A page of Discover interface edges.
- DiscoverInterfaceEdge: A Discover interface within a page.
- DiscoverInterfaceRemoveLabelPayload: A response to a request to remove one or more standard labels from specific Discover interfaces.
- DiscoverLabel: A Discover label, used to tag interfaces found during Discover network scans.
- DiscoverLabelConnection: A page of Discover label edges.
- DiscoverLabelCreatePayload: A response to a request to create a Discover label.
- DiscoverLabelDeletePayload: A response to a request to delete a Discover label.
- DiscoverLabelEdge: A Discover label within a page.
- DiscoverLabelInterfaceCounts: Aggregated interface counts for a label.
- DiscoverProfile: A Discover profile definition used to scan networks.
- DiscoverSatellite: An endpoint configured as a satellite to scan remote subnets.
- DiskSpace: The disk space details of an endpoint.
- Element: An asset managed in the CMDB.
- EmailSendPayload: The result of submitting a request to send an email.
- EmailServerSummary: A summary of the information required to retrieve and use an email server to send emails.
- EmailServerSummaryConnection: A page of email server summary edges.
- EmailServerSummaryEdge: An email server summary within a page.
- Endpoint: An endpoint managed by the Tanium Client.
- EndpointAlert: A performance alert triggered on an endpoint.
- EndpointAlertEvidence: Evidence collected as part of a performance alert on an endpoint.
- EndpointAlertEvidenceValues: Discrete data collected as part of the evidence comprising a performance alert on an endpoint.
- EndpointCollectionInfo: Information about the endpoint results that populate an `EndpointConnection`.
- EndpointCompliance: The state of an endpoint's compliance with security policies.
- EndpointComplianceComplianceFinding: A compliance issue found on an endpoint.
- EndpointComplianceCveFinding: A vulnerability finding on an endpoint.
- EndpointConnection: A page of endpoint edges.
- EndpointCountColumn: A sensor column and value associated with an endpoint count.
- EndpointCountRow: An endpoint count that matches sensor column values.
- EndpointCountsCollectionInfo: Information about the endpoint count results that populate an `EndpointCountsConnection`.
- EndpointCountsConnection: A page of endpoint count edges.
- EndpointCountsEdge: An endpoint count within a page.
- EndpointDeploySoftwarePackage: A Deploy software package that is deployed or deployable on an endpoint.
- EndpointDiscover: The details found by Discover.
- EndpointDisk: The disk space details of a volume.
- EndpointEdge: An endpoint within a page.
- EndpointEventCounts: The number of performance events on an endpoint.
- EndpointIdChange: Describes a change between endpoint IDs.
- EndpointIdChangesPayload: The endpoint IDs changes.
- EndpointInstalledApplication: A software application installed on an endpoint.
- EndpointMetric: A metric recorded on an endpoint.
- EndpointMetricInfo: The details of a metric recorded on an endpoint.
- EndpointOS: The operating system details of an endpoint.
- EndpointQuestion: An endpoint question.
- EndpointRisk: The Risk details of an endpoint.
- EndpointRiskAdministrativeAccessVector: The Administrative Access risk vector details for an endpoint.
- EndpointRiskComplianceVector: The System Compliance risk vector details for an endpoint.
- EndpointRiskExpiredCertificatesVector: The Expired Certificates risk vector details for an endpoint.
- EndpointRiskInsecureTLSVector: The Insecure SSL/TLS risk vector details for an endpoint.
- EndpointRiskPasswordIdentificationVector: The Password Identification risk vector details for an endpoint.
- EndpointRiskSystemVulnerabilityVector: The System Vulnerability risk vector details for an endpoint.
- EndpointRiskVectors: The risk vectors associated with an endpoint.
- EndpointSensorReading: The data collected from reading a single sensor column.

The `values` field always contains the raw string values read by the sensor. Other fields, such as
`floatValues`, might be queried to convert the values to a different type, depending on the sensor's
result type. If value type conversion fails, such as if the sensor reads `[no results]` for an
endpoint and the `floatValues` field is queried, the converted value is `null`. The original value
is available at the same index in the `values` field. If you convert a sensor value to a data type
that is not applicable to the sensor result type, such as a non-numeric sensor value to a
`floatValues` field, the response returns an error.
- EndpointSensorReadingColumn: A column collected in a sensor reading.
- EndpointSensorReadingRef: Identifies a sensor that was read.
- EndpointSensorReadingRefParam: The parameters used in a sensor reading.
- EndpointSensorReadings: The data collected from reading a set of sensors.
- EndpointSentinel: The Microsoft Sentinel details of an endpoint.
- EndpointSentinelSCCMClient: The Microsoft SCCM client details of an endpoint.
- EndpointSentinelWindowsDefender: The Microsoft Windows Defender details of an endpoint.
- EndpointService: The details of a service on an endpoint.
- EndpointSoftwarePackage: A software package that is installed or can be installed on an endpoint. It
represents one or more versions of a package, where packages are differentiated by name (vendor name
and product name).
- EndpointSoftwarePackageVersion: A specific version of a software package.
- EndpointTargetingCollection: A collection of computer groups and sensors used to target endpoints.
- EndpointTargetingComputerGroup: A computer group used to target endpoints.
- EndpointTargetingSensor: A sensor evaluation used to target endpoints.
- EndpointTargetingSensorParam: undefined
- EndpointUser: The details of an endpoint user.
- EndpointWindowsOS: The Windows operating system details of an endpoint.
- EntityPagination: undefined
- IDReference: A record with an ID and a name.
- IdRef: A reference to an entity with a unique identifier.
- ImportConfigurationItemEntitiesPayload: A response to a request to import configuration item entities.
- ImportConfigurationItemEntityPayload: A configuration item entity import.
- IntegrityMonitorComputerGroupConnection: A page of computer group edges.
- IntegrityMonitorComputerGroupEdge: A computer group within a page.
- IntegrityMonitorMonitor: An Integrity Monitor monitor that defines scan settings and event retention settings for targeted endpoints.

Use monitors to define scan settings for the endpoints in a targeted computer group. A monitor can be deployed to multiple computer groups.
Each endpoint that you target in a watchlist must also be targeted in a monitor for the watchlist to take effect when you deploy watchlists and monitors. Use the `integrityMonitorStartWatchlistDeployment` mutation to deploy watchlists. Use the `integrityMonitorStartMonitorDeployment` mutation to deploy monitors.
- IntegrityMonitorMonitorConnection: A page of monitor edges.
- IntegrityMonitorMonitorCreatePayload: A response to a request to create an Integrity Monitor monitor.
- IntegrityMonitorMonitorEdge: A monitor within a page.
- IntegrityMonitorMonitorMarkForDeletionPayload: A response to a request to mark an Integrity Monitor monitor for deletion.
- IntegrityMonitorMonitorUpdatePayload: A response to a request to update an Integrity Monitor monitor.
- IntegrityMonitorPathExclusionConnection: A page of watchlist path exclusion edges.
- IntegrityMonitorPathExclusionEdge: A watchlist path exclusion within a page.
- IntegrityMonitorPathInclusionConnection: A page of watchlist path inclusion edges.
- IntegrityMonitorPathInclusionEdge: A watchlist path inclusion within a page.
- IntegrityMonitorStartMonitorDeploymentPayload: A response to a request to deploy Integrity Monitor monitors.
- IntegrityMonitorStartWatchlistDeploymentPayload: A response to a request to deploy Integrity Monitor watchlists.
- IntegrityMonitorStatus: The status of the Integrity Monitor service.
- IntegrityMonitorWatchlist: An Integrity Monitor watchlist that defines a set of files, directories, and Windows registry paths to be monitored for changes.

Each endpoint that you target in a watchlist must also be targeted in a monitor for the watchlist to take effect when you deploy watchlists and monitors. Use the `integrityMonitorStartMonitorDeployment` mutation to deploy monitors. Use the `integrityMonitorStartWatchlistDeployment` mutation to deploy watchlists.
- IntegrityMonitorWatchlistConnection: A page of watchlist edges.
- IntegrityMonitorWatchlistCreatePayload: A response to a request to create an Integrity Monitor watchlist.
- IntegrityMonitorWatchlistEdge: A watchlist within a page.
- IntegrityMonitorWatchlistMarkForDeletionPayload: A response to a request to mark an Integrity Monitor watchlist for deletion.
- IntegrityMonitorWatchlistPath: A watchlist path specifies the files, directories, and Windows registry paths to monitor and the change types to watch on that path. Each path can also specify exclusions or inclusions to apply only to that path.

In a path value, you can use wildcard characters within a directory, file, or registry key name, but you cannot use wildcard characters to match path separators or specify multiple directory or subkey levels.

To refine the files, directories, and registry paths that are monitored for a watchlist, add path inclusions or path exclusions. Without inclusions or exclusions defined, the path matches all files and subdirectories in a file path or all subkeys in a registry path. If no inclusions are specified, a file path that specifies a directory includes subdirectories recursively, and a registry path that specifies a registry key includes subkeys recursively.

If you define path inclusions, the path matches only subdirectories, files, or registry subkeys that match the inclusions.
If you define path exclusions, the path does not match subdirectories, files, or registry subkeys that match the exclusions.

Exclusions take precedence over inclusions. If you define both inclusions and exclusions, the path matches all directories, files, or registry keys that match the inclusions, except those that match exclusions.
- IntegrityMonitorWatchlistPathConnection: A page of watchlist path edges.
- IntegrityMonitorWatchlistPathCreatePayload: A response to a request to create an Integrity Monitor watchlist path.
- IntegrityMonitorWatchlistPathDeletePayload: A response to a request to delete an Integrity Monitor watchlist path.
- IntegrityMonitorWatchlistPathEdge: A watchlist path within a page.
- IntegrityMonitorWatchlistPathUpdatePayload: A response to a request to update an existing Integrity Monitor watchlist path.
- IntegrityMonitorWatchlistUpdatePayload: A response to a request to update an Integrity Monitor watchlist.
- KillProcessPayload: A response to a request to terminate a process.
- Memory: The memory details of an endpoint.
- MergeConfigurationItemElementsPayload: A response to a request to merge two configuration item elements.
- Metadata: Arbitrary data that can be associated with many Tanium platform entities.
- MonotonicDuration: A time duration which measures from an arbitrary point in time and always moves forward.
It does not account for calendar or clock time conventions such as time zones, Daylight Savings Time, leap seconds, etc.
The total time duration is calculated by adding together the `seconds` and `nanoseconds` values.
- NamedOnlyRef: A reference to an entity with a name.
- NamedRef: A reference to a named entity.
- NetworkAdapter: The network adapter details of an endpoint.
- Networking: The networking details of an endpoint.
- NumericIntervalOption: undefined
- OpenDirectConnectionPayload: A response to a request to open a Direct Connect connection to an endpoint.
- Package: undefined
- PackagePagination: undefined
- PackageParam: The sensor-sourced parameter used in a package.
- PackageParameter: A parameter of a package.
- PackageRef: A package used in an action.
- PackageSpec: undefined
- PackageSpecConnection: A page of package spec edges.
- PackageSpecEdge: A package spec within a page.
- PackageSpecParam: A positional package parameter for a package spec.
- PackageSpecSensorSourcedParam: A sensor-sourced parameter for a package spec.
- PageInfo: Information about a connection page.
- PaginationInfo: Information about a paginated collection.
- PaginationInfoWithID: Information about a paginated collection, including an ID for the collection.
- ParameterDefinition: undefined
- ParameterDefinitionValidationExpression: undefined
- ParameterDefinitions: undefined
- PatchClientNotification: An end user notification displayed to Windows and macOS endpoint users before a restart or deployment.
- PatchClientNotificationTranslation: Translation of a client notification.
- PatchCreateDeploymentPayload: A response to a request to create a deployment.
- PatchDefinition: A Tanium patch definition.
- PatchDefinitionConnection: A page of patch definitions.
- PatchDefinitionEdge: A patch definition within a page.
- PatchDeployment: A request to create a Patch deployment.
- PatchList: The patch list.
- PatchListRef: A patch list reference.
- PatchListRule: A patch list rule.
- PatchListRuleCondition: A rule to target patches by.
- PatchListUpsertPayload: A response to a request to create or update a patch list.
- PatchNotifications: Patch deployment notifications for Windows and macOS endpoints.
- PatchPostponeOptions: Postponement options for Windows and macOS endpoint users to delay a restart or deployment.
- PatchQuestionCriteria: Patch deployment question criteria.
- PatchSchedule: A Patch deployment schedule.
- PatchStopDeploymentPayload: A response to a request to stop a deployment that is in progress or scheduled to start in the future.
- PatchTargets: The endpoints on which a deployment runs.
- Persona: A set of roles and computer groups that can be used to enforce a set of restrictions on what a user can and cannot do.
- PingDirectConnectionPayload: A response to a request to ping an endpoint over a Direct Connect connection.
- Playbook: A playbook.
- PlaybookConnection: A page of playbook edges.
- PlaybookContentSetUpdatePayload: The result of updating a playbook's content set.
- PlaybookEdge: A playbook within a page.
- PlaybookEmailNotificationSettings: Playbook email notification settings.
- PlaybookFilterRef: The reference to a playbook.
- PlaybookNotificationEvent: Additional information about a playbook notification.
- PlaybookNotificationSettings: Playbook notification settings.
- PlaybookPatchClientNotification: An end user notification displayed to Windows and macOS endpoint users before a restart.
- PlaybookPatchClientNotificationTranslation: Translation of a client notification.
- PlaybookPatchListRef: A patch list reference.
- PlaybookPatchPostponeOptions: Postponement options for Windows and macOS endpoint users to delay a restart.
- PlaybookPerformOperationPayload: The result of performing an operation on a playbook.
- PlaybookRun: A running playbook.
- PlaybookRunConnection: A page of playbook run edges.
- PlaybookRunEdge: A playbook run within a page.
- PlaybookRunEvent: A playbook run event.
- PlaybookRunPerformOperationPayload: The result of performing an operation on a playbook run.
- PlaybookRunStep: A playbook run step.
- PlaybookRunStepConfirmationResult: The confirmation result for a playbook run. This is provided when the playbook step type is `PlaybookStepInstruction` or `PlaybookStepConfirmation`.
- PlaybookSchedule: A schedule for running a playbook on a recurring interval.
- PlaybookScheduleConnection: A page of playbook schedule edges.
- PlaybookScheduleEdge: A playbook schedule within a page.
- PlaybookScheduleEvent: A playbook schedule event.
- PlaybookSchedulePerformOperationPayload: The result of performing an operation on a playbook schedule.
- PlaybookScheduleSpecificationOnce: The one-time schedule specification, including the start time.
- PlaybookScheduleSpecificationRecurring: The recurring schedule specification, including a cron expression string, start time, and end time.
- PlaybookScheduleSpecificationRelative: The relative schedule specification, including the week, day of the week, offset, hour, minute, start time, and end time.
- PlaybookScheduleUpsertPayload: The result of upserting a playbook schedule.
- PlaybookSoftwareBundleRef: A software bundle reference.
- PlaybookSoftwareDeploymentClientNotification: An end user notification displayed to Windows and macOS endpoint users before a restart.
- PlaybookSoftwareDeploymentClientNotificationTranslation: Translation of a client notification.
- PlaybookSoftwareDeploymentConfig: A Software Deployment configuration in Tanium Deploy.
- PlaybookSoftwareDeploymentPostponeOptions: Postponement options for Windows and macOS endpoint users to delay a restart.
- PlaybookSoftwarePackageRef: A software package reference.
- PlaybookStartPayload: A response to a request to start a playbook.
- PlaybookStep: A step in a playbook.
- PlaybookStepMissingPermission: Permissions required by the user submitting the request to access all step content.
- PlaybookStepOverride: An override for a single playbook step. This override replaces the endpoint targeting, task argument,
or both, for the associated playbook run step. If this override does not define endpoint targeting
or a task argument, the playbook run uses values defined in the playbook.
- PlaybookStepPatchInstallDeploymentConfig: A Patch install deployment configuration. The Patch install deployment is
created when this step is triggered in Automate. So the scheduling configuration
is omitted from this configuration.

This is similar to `PatchDeployment` with the following fields removed:
`type`, `id`, `targets`, `schedule`, `author`, `createdTime`, `updatedTime`,
`stoppedTime`, `status`, `downloadImmediately`.

The following fields have been added from `PatchSchedule`:
`distributeOver`, `overrideMaintenanceWindows`, `eussHideFromActivity`.
- PlaybookStepTargetingCompletedPreviousStep: The endpoint targeting criteria for endpoints that completed a previous step.
- PlaybookStepTargetingCustom: A custom set of endpoint targeting criteria.
- PlaybookStepTargetingPreviousStep: The endpoint targeting criteria used by a previous playbook run step.
- PlaybookStepTaskArgumentOverride: A task argument override for a playbook step.
- PlaybookUpsertPayload: The result of upserting a playbook.
- Principal: An authentication principal.
- Process: A process running on an endpoint.
- Processor: The processor details of an endpoint.
- ProgressionCondition: Defines a condition that must pass for a deployment to continue. One, and only
one, field will be defined.
This is intended for Tanium internal use, and should not be used by customers.
- ProgressionConditionMinimumExecutionCount: A minimum execution count progression condition.

A given number of targeted endpoints must execute a deployment action for this check to pass.
The number includes endpoints where the action executed but failed.
This is intended for Tanium internal use, and should not be used by customers.
- ProgressionConditionMinimumSuccessPercentage: A minimum success percentage progression condition.

A given percentage of targeted endpoints must successfully execute a deployment action for this
check to pass.
This is intended for Tanium internal use, and should not be used by customers.
- ProgressionConditionResult: The result of a ring deployment progression criteria.
- ProgressionConditionResultValue: A ring deployment progression criteria result. Only one field will be populated.
This is intended for Tanium internal use, and should not be used by customers.
- ProgressionConditionResultValueV2ExecutionCount: A ring deployment progression criteria result value for a minimum execution count progression criteria.
- ProgressionConditionResultValueV2PatchUnexpectedRebootRate: The result value of a ring deployment progression criteria for a patch maximum unexpected reboot rate progression criteria.
- ProgressionConditionResultValueV2SoftwareDeploymentAppCrashRate: The result value of a ring deployment progression criteria for a software deployment maximum app crash rate progression criteria.
- ProgressionConditionResultValueV2SoftwareDeploymentDeviatedCpuUsageRate: The result value of a ring deployment progression criteria for a software deployment maximum deviated CPU usage rate progression criteria.
- ProgressionConditionResultValueV2SoftwareDeploymentDeviatedMemoryUsageRate: The result value of a ring deployment progression criteria for a software deployment maximum deviated memory usage rate progression criteria.
- ProgressionConditionResultValueV2SoftwareDeploymentNormalCpuUsageRate: The result value of a ring deployment progression criteria for a software deployment minimum normal CPU usage rate progression criteria.
- ProgressionConditionResultValueV2SoftwareDeploymentNormalMemoryUsageRate: The result value of a ring deployment progression criteria for a software deployment minimum normal memory usage rate progression criteria.
- ProgressionConditionResultValueV2SuccessPercentage: The result value of a ring deployment progression criteria for a minimum success percentage
progression criteria.
- ProgressionConditionResultValueV2Wait: A ring deployment progression criteria result value for a wait progression criteria.
- ProgressionCriteria: Defines conditions that must all pass for a deployment to continue.
- ProgressionCriteriaSet: Defines the conditions that must be met before a ring-based deployment may advance from each ring to
the next.
- ProvisionDeleteRetirementDefinitionPayload: A response to a request to delete retirement action definitions.
- ProvisionRetirementAction: A retirement action.
- ProvisionRetirementActionConnection: A page of retirement action edges.
- ProvisionRetirementActionDefinition: A retirement action definition.
- ProvisionRetirementActionDefinitionConnection: A page of retirement action definition edges.
- ProvisionRetirementActionDefinitionEdge: A retirement action definition edge within a page.
- ProvisionRetirementActionDefinitionPayload: A response to a request to create a retirement action definition.
- ProvisionRetirementActionEdge: A retirement action edge within a page.
- ProvisionRetirementActionEventLog: A retirement action event log.
- ProvisionRetirementActionEventLogEdge: A retirement action event log edge within a page.
- ProvisionRetirementActionEventLogsConnection: A page of retirement action event log edges.
- ProvisionRetirementActionNotes: A retirement action note.
- ProvisionRetirementActionPayload: A response to a request to create or update a retirement action.
- ProvisionRetirementEndpointActionOptions: undefined
- ProvisionRetirementNoteDefinition: A retirement action note definition.
- ProvisionRetirementNotesDefinition: A retirement action notes definition.
- ProvisionRetirementTargetEndpointParameters: Information about the target endpoint.
- Relationship: A relationship between configuration item entities.
- RelationshipPagination: undefined
- RelationshipResult: A set of configuration item relationships.
- RelationshipType: The type of a configuration item relationship.
- RelationshipTypeResult: A set of configuration item relationship types.
- Report: A report.
- ReportConnection: A page of report edges.
- ReportDeletePayload: The result of deleting a report.
- ReportEdge: A report within a page.
- ReportExportPayload: A response to a request to export a report definition.
- ReportImportPayload: A response to a request to import a report definition.
- ReportResultDataCollectionInfo: Information about the report data results that populate a `ReportResultDataConnection`.
- ReportResultDataColumn: A report result data column.
- ReportResultDataConnection: A page of report result data.
- ReportResultDataEdge: A report result data row within a page.
- ReportResultDataRow: A report result data row.
- ReportView: The view details of a report.
This determines what data the report returns and how the data is sorted through the `reportResultData` query.
- ReportViewColumn: A column used in a report view.
- ReportViewColumnSort: Defines the sort order of a column within a report view.
- ReportViewSource: undefined
- ReportingDashboardDeletePayload: The result of deleting a Reporting dashboard.
- RingBasedBlockRing: The status, targeting, progression criteria, and results for a ring-based block ring.
- RingDeployment: A ring deployment.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentActionECFProgressConfigurationItem: A ring deployment action that progresses an ECF configuration item.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentActionIssuePlatformAction: A ring deployment action that issues a platform action.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentConnection: Connection for ring deployments.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentEdge: Ring deployment edge.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentEventChangeWaitRequested: A ring deployment event where the user requests changing a wait progression criteria.
- RingDeploymentEventPauseRequested: A ring deployment event where the user requests for the ring deployment to be paused.
- RingDeploymentEventPaused: A ring deployment event where the ring deployment is paused.
- RingDeploymentEventProgressedByUser: A ring deployment event where the user progressed the ring deployment after the deployment failed
the progression criteria.
- RingDeploymentEventResumeRequested: A ring deployment event where the user requests that the ring deployment resume after it is paused.
- RingDeploymentEventResumed: A ring deployment event where the ring deployment is resumed after it has paused.
- RingDeploymentEventRetried: A ring deployment event where the ring deployment is retried after it has failed.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentEventRetryRequested: A ring deployment event where the user requests that the ring deployment be retried after the
deployment failed to meet the progression criteria.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentEventSkippedWait: A ring deployment event where a wait progression criteria is skipped.
- RingDeploymentEventStopRequested: A ring deployment event where the user requests that the ring deployment stops.
- RingDeploymentPayload: The result of a ring deployment mutation.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentRing: The status, targeting, progression criteria, and results for a deployment ring.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentRingLinkedResources: Linked resources that contain details on the endpoints.
- RingDeploymentRingPlatformAction: The platform action issued for a ring.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentRingProgress: The ring deployment progress in a specific ring.
- RingDeploymentRingTargeting: The targeting for a ring, which cannot change after the ring deployment is started.
- RingDeploymentScheme: Defines progressively larger rings of endpoints to target during deployment and the criteria that
must be met before the deployment may advance from ring to ring.

Ring Deployments...

* Target one ring at a time, then evaluate progression criteria that must be met before advancing to
the next ring.
* Apply each ring's targeting in addition to any targeting associated with the content to deploy.
* Always target an implicit final ring that includes all computers that match the content targeting.
* Always apply only to endpoints for which the user who creates the deployment has management rights.

### Example - Static ring targets

* Content to deploy targets Group C
* Ring 1 targets Group A, excludes Group X
* Ring 2 targets Group B, excludes Group Y

#### Static rings deployment flow

1. Deploy to endpoints that are in Group C AND Group A AND NOT Group X.
2. Check Progression Criteria List 1. If successful, proceed.
3. Deploy to endpoints that are in Group C AND (Group A OR Group B) AND NOT Group Y.
4. Check Progression Criteria List 2. If successful, proceed.
5. Implicit final "All Computers Ring": Deploy to all endpoints that are in Group C.

### Example - Random ring targets

* Content to deploy targets Group C
* Ring 1 targets 25% of endpoints, excludes Group X
* Ring 2 targets 50% of endpoints, excludes Group Y

#### Deployment flow would be...

1. Deploy to 25% of endpoints that are in Group C AND NOT Group X.
2. Check Progression Criteria List 1. If successful, proceed to Step 3.
3. Deploy to 50% of endpoints that are in Group C AND NOT Group Y.
4. Check Progression Criteria List 1. If successful, proceed to Step 5.
5. Implicit final "All Computers Ring": Deploy to 100% of endpoints that are in Group C.
- ScheduledAction: A scheduled action.
- ScheduledActionApprovePayload: The result of approving a scheduled action.
- ScheduledActionConnection: A page of scheduled action edges.
- ScheduledActionCreatePayload: The result of creating a scheduled action.
- ScheduledActionDeletePayload: The result of deleting a scheduled action.
- ScheduledActionEdge: A scheduled action within a page.
- Sensor: A sensor is a named source of endpoint data. Normal sensors are managed by the Tanium Server and
executed as scripts on endpoints. Virtual sensors are managed by TDS and typically store data
computed and asserted by various systems.
- SensorColumn: A sensor column describes a named portion of a sensor reading.
- SensorConnection: A page of sensor edges.
- SensorEdge: A sensor within a page.
- SensorHarvestPayload: A response to a harvest registration request.
- SensorParameter: A sensor parameter describes an argument to a sensor.
- SensorParameterValue: A sensor parameter value.
- SensorParameterization: A sensor parameterization is a specific set of sensor parameter values.
- SensorScript: The script implementing a sensor for a given platform.
- SoftwareApplicabilityCounts: The number of endpoints in each applicability status.
- SoftwareDeploymentDetails: The details of a software deployment.
- SoftwareDeploymentErrorCount: A software deployment error that affects endpoints.
- SoftwareDeploymentStatus: The status and related details of a software deployment.
- SoftwarePackage: The details of a software package.
- SoftwarePackageConnection: A page of software packages.
- SoftwarePackageEdge: A software package within a page.
- SyncAssetResult: A response to a request to synchronize assets.
- SystemError: A system error represents a problem that occurred while trying to process a command.
- TaniumPlatformContentSet: Defines a group of Tanium content objects. Role-based access control permissions control which users can access the content set.
- TaniumPlatformRing: A named set of endpoints to target in the context of a ring set.
This is intended for Tanium internal use, and should not be used by customers.
- TaniumPlatformRingSet: A collection of rings. Each ring defines a set of endpoints to target. Static rings target specific
computer groups. Random rings target a percentage of all Tanium-managed endpoints. Endpoints are
selected for targeting at random. A ring set cannot contain static and random rings.
- TaniumPlatformUser: A user who can access the Tanium platform.
- TaniumPlatformUserContext: A Tanium platform user context, containing the Tanium platform user and selected persona.
- TaniumPlatformUserPersona: A user persona in the Tanium platform.
Note that the default persona is represented as a `null` reference to this type.
- ThreatResponseAlertResolvePayload: The result of resolving a Threat Response alert.
- UpdateConfigurationItemPropertiesResult: A response to a request to update properties of the configuration item in the CMDB.
- WirelessAdapter: The wireless adapter details of an endpoint.
## Inputs
- APITokenGrantInput: A request to create an API token for the current user.
- APITokenRevokeInput: A request to revoke an API token.
- APITokenRotateInput: A request to create an API token for the current user.
- ActionActionGroupInput: Identifies an existing action group.

Define one, and only one, of either `name` or `id`.
If you define `name` and `id`, only the `id` is used to identify the action group, and the `name` is ignored.
- ActionChangeClientSetting: A policy for changing client settings.
- ActionCollectAD: A policy for collecting Active Directory data.
- ActionCreateInput: A request to create an action.
- ActionGroupCreateInput: Creates an action group from the given input.
- ActionInput: A request to create a saved action.
- ActionOperationChangeClientSettingInput: A request to change a Tanium Client setting on an endpoint.
- ActionOperationCollectActiveDirectoryInfoInput: A request to collect Active Directory information on an endpoint.
- ActionOperationInput: A request to perform a registered operation. You can choose only one operation.
- ActionOperationRebootInput: A request to reboot an endpoint.
- ActionPerformInput: A request to create the actions or scheduled actions necessary to run a package or a registered
operation. Exactly one of `package` or `operation` must be given.

If an operation is specified, an action or scheduled action will be created for each set of endpoint
operating systems supported by the underlying packages. If the `targets` input specifies any
`platforms`, they must be included in the set of operating systems supported by the operation's
packages.

The `schedule` field controls the schedule on which the actions run, including if it runs only once
or recurs.

The top-level result of performing an action are always scheduled actions for consistency, even if
they only create a single action.
- ActionPerformScheduleInput: The schedule on which the action should run.
- ActionReboot: A policy for rebooting endpoints.
- ActionSchedule: The policy governing the scheduling of the action.
- ActionScheduleInput: The schedule on which the action should run.
- ActionService: A service running on an endpoint.
- ActionTarget: The group of endpoints targeted by an action.
- ActionTargetGroupInput: Identifies or describes a target group. Exactly one of `id`, `name`, or `filter` must be specified.
The first two fields (`id`, `name`) identify an existing group. The last field (`filter`) describes
a transient group, created for this action.

If you define `name` and `id`, only the `id` is used to identify the computer group, and the `name` is ignored.
- ActionTargetsInput: The endpoints on which an action runs. Each field describes a condition; the action runs on only the
endpoints that satisfy every condition.
- AssetAttributeInput: Asset Attribute value. This is equivalent to the Column of a sensor in TDS.
- AssetEndpointInput: Grouping of entities to upsert or update on a given endpoint.

The `entities` array contains values for the entities defined in `entityNames`.

The `entities` array can contain entities that also serve as a reconciliation key for this source.
If all the reconciliation keys are included, this entity can be reconciled.

For more information, see [Tanium Asset User Guide: Configuring attributes](https://help.tanium.com/bundle/ug_asset_cloud/page/asset/attributes.html)
- AssetEndpointWithEidInput: The grouping of entities to update an endpoint that matches the endpoint ID (EID).

The `entities` array contains values for the entities defined in `entityNames`.

The `entities` array can contain entities that also serve as a reconciliation key for this source.
If all the reconciliation keys are included, this entity can be reconciled.

For more information, see [Tanium Asset User Guide: Configuring attributes](https://help.tanium.com/bundle/ug_asset_cloud/page/asset/attributes.html)
- AssetEntityInput: Asset entity. This is equivalent to a sensor in TDS.
- AssetEntityRowInput: Asset Entity row values. This is equivalent to a row of a Sensor in TDS.
- AssetProductEndpointsFilter: Describes an asset product endpoint value filter. Records with field values matching the filter are included in the query results. Asset product endpoint filters may be single or compound. Any filter that is not valid causes the query to return an error.

For a single filter definition with one set of fields, if an endpoint record matches any filter condition, it satisfies the filter.

For a compound filter with multiple filter sets, an endpoint record must match every filter set to satisfy the filter, but can match any single filter condition within a filter set.
- AssetProductTrackingInput: Product tracking metrics input.
- AssetProductsFilter: Describes a filter for Asset product field values. Records with field values matching the filter are included in the query results.
Software installed on an endpoint must match every included filter condition to satisfy the filter.
- AssetProductsInput: Input for mutating product tracking gathering metrics.
- AssetUpdateEndpointsInput: List of endpoints to update into the source. Update supports updating endpoints based on the keys for the source.
Unknown keys do not create a new endpoint.
- AssetUpdateEndpointsUsingEidInput: The list of updates to make to the source, based on the source endpoint IDs (EID).
- AssetUpsertEndpointsInput: List of endpoints to upsert into the source. Upsert supports updating or creating new endpoints based on
the keys for the source.
- AssetsImportInput: Input fields for creating or updating assets.
- AutomateTaskArgumentConfirmationInput: Input for the Confirmation task argument.
- AutomateTaskArgumentDeployActionInput: Input for the Deploy Action task argument.
- AutomateTaskArgumentDeploySoftwareDeploymentInput: Input for the Deploy Software Deployment task argument.
- AutomateTaskArgumentEndpointConditionEvaluationInput: Input for the Endpoint Condition Evaluation task argument.
- AutomateTaskArgumentEndpointExecutionInput: Input for the Endpoint Execution task argument.
- AutomateTaskArgumentEndpointPackageExecutionInput: Input for the Endpoint Package Execution task argument.
- AutomateTaskArgumentEndpointRestartInput: Input for the Endpoint Restart task argument.
- AutomateTaskArgumentInput: Automate task arguments. Define one, and only one, of the fields.
- AutomateTaskArgumentInstructionInput: Input for the Instruction task argument.
- AutomateTaskArgumentPatchInstallDeploymentInput: Input for the Patch Install Deployment task argument.
- AutomateTaskArgumentRingBasedBlockInput: Input for the ring-based block task argument
- AutomateTaskArgumentVerifyConditionInput: Input for the Verify Condition task argument.
- AutomateTaskArgumentWaitInput: Input for the Wait task argument.
- CloseDirectConnectionInput: A request to close a Direct Connect connection to an endpoint.
- ComputerGroupCreateInput: A request to create a standard computer group.
- ComputerGroupFilter: An object containing the conditions for membership in a standard computer group.
- ComputerGroupsFilter: Describes a filter for computer groups.
A computer group must match every included filter condition to satisfy the filter.
- ConnectConnectionStartInput: The input of starting a connection run.
- ConnectConnectionStopInput: The input of stopping an in-progress connection run.
- DeleteActionInput: A set of saved actions to delete.
- DeleteConfigurationItemElementInput: A request to delete a configuration item element.
- DeleteRelationshipInput: A request to delete relationships between configuration item entities.
- DeploymentPlanFieldFilter: Describes a filter for deployment plan field values.
A deployment plan must match every included filter condition to satisfy the filter.
This is intended for Tanium internal use, and should not be used by customers.
- DeploymentPlanFieldSort: Sorting criteria for deployment plans.
The list is sorted by the specified field, in the specified order.
This is intended for Tanium internal use, and should not be used by customers.
- DeploymentPlanPerformOperationInput: A request to perform an operation on a deployment plan.
This is intended for Tanium internal use, and should not be used by customers.
- DeploymentPlanUpsertInput: A request to upsert a deployment plan.
This is intended for Tanium internal use, and should not be used by customers.
- DeploymentSchemeInput: Deployment scheme. Define one, and only one, of the fields.
This is intended for Tanium internal use, and should not be used by customers.
- DevAction: Experimental action policies.
- DirectConnectAlertScope: Defines a window of time for filtering performance alerts.
- DirectConnectCloseInput: A request to close a Direct Connect connection to an endpoint.
- DirectConnectConnectionStatusInput: A request to get the status for a Direct Connect connection.
- DirectConnectEndpointInput: A request to get data from an endpoint using an open Direct Connect connection.
- DirectConnectOpenInput: A request to initiate a Direct Connect connection to an endpoint.
- DirectConnectPingInput: A request to ping an endpoint over a Direct Connect connection (for example, to test connectivity).
- DirectConnectProcessTerminateInput: A request to terminate a process running on an endpoint.
- DiscoverInterfaceAddLabelInput: A request to add one or more standard labels to specific Discover interfaces.
- DiscoverInterfaceRemoveLabelInput: A request to remove one or more standard labels from specific Discover interfaces.
- DiscoverLabelCreateInput: A request to create a standard Discover label.
- DiscoverLabelFindInput: A request to find a Discover label.
- EmailSendInput: A request to send an email.
- EndpointCountsInput: A request to retrieve the count of endpoints matching the input sensor column values.
- EndpointCountsSource: The data source from which to retrieve endpoints for the `endpointCounts` query.
- EndpointFieldFilter: Describes a filter for endpoint field values. Records with field values matching the filter are
included in the query results. Field filters may be single or compound, and have different argument
requirements. Any filter that is not valid causes the query to return an error.

Simple filters have three distinct forms:

* `path`, `value`, and `op` properties describe a filter on the value of a field in the schema
* `sensor`, `value`, and `op` properties describe a filter on the value of an arbitrary sensor reading
* `memberOf` property describes a filter to a computer group

Compound filters have a single form:

* `filters`, and `any` properties

Filter limitations:
* Filtering by `Namespace` is currently unsupported and results in a validation error
- EndpointFieldFilterComputerGroup: Identifies the computer group to which an endpoint must belong to be included by a filter.

Define one, and only one, of either `name` or `id`.
If you define `name` and `id`, only the `id` is used to identify the computer group, and the `name` is ignored.
- EndpointFieldFilterSensor: Identifies the sensor whose readings are used as the basis for a filter.
- EndpointFieldFilterSensorParam: Parameterizes a sensor reading.
- EndpointFieldSort: Describes a sort order for endpoint field values. Endpoints will be sorted by the specified field,
in the specified order. Any sort that is not valid causes the query to return an error.

Exactly one of `path` or `sensor` must be provided.
- EndpointFieldSortSensor: Identifies the sensor whose readings are used as the basis for a sort.
- EndpointFieldSortSensorParam: Parameterizes a sensor reading.
- EndpointSensorRef: Identifies a sensor to read.
- EndpointSensorRefParam: Parameterizes a sensor reading.
- EndpointSource: The data source from which to retrieve endpoints. The default source is the Tanium
Data Service in the standard Tanium endpoint namespace.

You can only specify one data source.
- EndpointSourceTDS: Specifies the use of the Tanium Data Service as the source of endpoints.

Provide no more than one of the following:
- `allNamespaces` = true
- `namespaces` is non-null
- `scope` is set

If none are specified, the default is to use Tanium Client entity types equivalent to specifying `namespaces: [""]`.

Behavior Deprecation On July 2025:
If both `allNamespaces` and `namespaces` are specified:
- The query currently use `allNamespaces` and ignores `namespaces`.
- After the end of support date, these fields will become mutually exclusive. Including both will result in a validation error.
- EndpointSourceTS: Specifies the use of a Tanium Server question as the source of endpoints. This waits for question
results until any of the success criteria are met or the maximum wait time for a single request has
elapsed. The success criteria are not guaranteed to be met. Users might check the `collectionInfo`
field to observe the completeness of the results and might use the `refresh` argument to try to
retrieve more results.
- EntitiesQueryParams: The configuration item entities to include in the results.
- EntityInput: A request to import a configuration item entity.
- EntitySortRequest: The criteria by which to sort the entities.
- FieldFilter: Describes a filter for field values. Records with field values matching the filter are included in
the query results. Field filters may be single or compound, and have different argument
requirements. Any filter that is not valid causes the query to return an error.
- FilterSpec: A filter for the assets query.
- IDRevisionRefInput: A reference to an entity with an identifier and optional revision number.
- IdRefInput: A reference to an entity with an identifier.
- IntegrityMonitorMonitorCreateInput: A request to create an Integrity Monitor monitor.
- IntegrityMonitorMonitorUpdateInput: A request to update an Integrity Monitor monitor.
- IntegrityMonitorWatchlistCreateInput: A request to create an Integrity Monitor watchlist.
- IntegrityMonitorWatchlistUnixPathCreateInput: A request to create a Unix-style path in an existing Integrity Monitor watchlist.
- IntegrityMonitorWatchlistUnixPathUpdateInput: A request to update an existing Unix-style watchlist path.
- IntegrityMonitorWatchlistUpdateInput: A request to update an Integrity Monitor watchlist.
- IntegrityMonitorWatchlistWindowsFilePathCreateInput: A request to create a Windows-style file path in an existing Integrity Monitor watchlist.
- IntegrityMonitorWatchlistWindowsFilePathUpdateInput: A request to update an existing Windows-style file path.
- IntegrityMonitorWatchlistWindowsRegistryPathCreateInput: A request to create a Windows-style registry path in an existing Integrity Monitor watchlist.
- IntegrityMonitorWatchlistWindowsRegistryPathUpdateInput: A request to update an existing Windows-style registry path.
- KillProcessInput: A request to terminate a process running on an endpoint.
- LiveQueryOptions: Options for determining when a live query is complete.
- MergeConfigurationItemElementsInput: A request to merge two configuration item elements.
- MetadataInput: A request to associate metadata with a Tanium platform entity.
Metadata generated through this request has the `adminFlag` set to false, and is accessible
to all users that can read the entity.
- MonotonicDurationInput: Input for a time duration which measures from an arbitrary point in time and always moves forward.
It does not account for calendar or clock time conventions such as time zones, Daylight Savings Time, leap seconds, etc.
The total time duration is calculated by adding together the `seconds` and `nanoseconds` values.
- NamedOnlyRefInput: A reference to an entity with a name.
- NamedRefInput: A reference to a named entity. Only one identifier field may have a value in a valid reference.

Define one, and only one, of either `name` or `id`.
If you define `name` and `id`, only the `id` is used to identify the entity, and the `name` is ignored.
- OpenDirectConnectionInput: A request to open a Direct Connect connection to an endpoint.
- PackageParamInput: A sensor-sourced input parameter for a package.
- PackageRefInput: Identifies and parameterizes a package for use in an action.

Define one, and only one, of either `name` or `id`.
If you define `name` and `id`, only the `id` is used to identify the package, and the `name` is ignored.
- PatchClientNotificationInput: An end user notification displayed to Windows and macOS endpoint users before a restart or deployment.
- PatchClientNotificationTranslationInput: Translation of a client notification.
- PatchCreateDeploymentInput: A request to create a Patch deployment.
- PatchDefinitionFieldFilter: Describes a filter for patch definitions.
Patch definitions with field values matching the filter are included in the query results.
- PatchDefinitionFieldSort: Sorting criteria for patch definitions.
The list is sorted by the specified field, in the specified order.
- PatchListRefInput: A patch list reference input.
- PatchListRuleConditionFieldValueInput: The input for a rule condition field value. Define one, and only one, field:
If `fieldName` equals `RELEASE_DATE` and `comparisonOperator` equals `ON_OR_AFTER_ABSOLUTE_DATE`, or `ON_OR_BEFORE_ABSOLUTE_DATE` for date comparison, enter a `releaseDate` value.
If `fieldName` equals `RELEASE_DATE` and `comparisonOperator` equals `ON_OR_AFTER_RELATIVE_DAYS`, or `ON_OR_BEFORE_RELATIVE_DAYS` for an age in days comparison, enter a `releaseDateDaysAgo` value.
If `fieldName` equals `SEVERITY`, enter a `severity` value.
Otherwise, enter a `value` value.
- PatchListRuleConditionInput: A rule to target patches by input.
- PatchListRuleInput: A patch list rule input.
- PatchListUpsertInput: A request to create or update a patch list.
- PatchNotificationsInput: Patch deployment notifications for Windows and macOS endpoints.
- PatchPostponeOptionsInput: Postponement options for Windows and macOS endpoint users to delay a restart or deployment.
- PatchQuestionCriteriaInput: Patch deployment question criteria.
- PatchScheduleInput: A Patch deployment schedule.
- PatchTargetsInput: The endpoints on which a deployment runs. If both `computerGroups` and `questionCriteria` are defined, the deployment targets endpoints that match either the defined computer groups or the defined question criteria.
- PerfQuery: A request to perform a PromQL query.
- PingDirectConnectionInput: A request to ping an endpoint over a Direct Connect connection (for example, to test connectivity).
- PlaybookContentSetUpdateInput: A request to update a playbook's content set.
- PlaybookEmailNotificationSettingsInput: A request to configure playbook email notification settings.
- PlaybookFieldFilter: Describes a filter for playbooks field values.
A playbook must match every included filter condition to satisfy the filter.
- PlaybookFieldSort: Sorting criteria for playbooks.
The list is sorted by the specified field, in the specified order.
- PlaybookNotificationSettingsInput: A request to configure playbook notification settings.
- PlaybookPatchClientNotificationInput: An end user notification displayed to Windows and macOS endpoint users after a deployment and before a restart.
- PlaybookPatchClientNotificationTranslationInput: Translation of a client notification.
- PlaybookPatchListRefInput: A patch list reference input.
- PlaybookPatchPostponeOptionsInput: Postponement options for Windows and macOS endpoint users to delay a restart.
- PlaybookPerformOperationInput: A request to perform an operation enumerated in `PlaybookOperation` on a playbook.
- PlaybookRunFieldFilter: Describes a filter for playbook runs field values.
A playbook run must match every included filter condition to satisfy the filter.
- PlaybookRunFieldSort: Sorting criteria for playbook runs.
The list is sorted by the specified field, in the specified order.
- PlaybookRunOperationConfirmStepParams: Input parameters for the `CONFIRM_STEP` playbook run operation.
- PlaybookRunOperationParameters: Playbook run operation parameters. Only one of the fields should be defined.
- PlaybookRunPerformOperationInput: A request to perform an operation enumerated in `PlaybookRunOperation` on a playbook run.
- PlaybookScheduleFieldFilter: Describes a filter for playbook schedules field values.
A playbook schedule must match every included filter to satisfy the filter.
- PlaybookSchedulePerformOperationInput: A request to perform an operation enumerated in `PlaybookScheduleOperation` on a playbook schedule.
- PlaybookScheduleSpecificationInput: The schedule specification that determines when to run the associated playbook.
Exactly one of `recurring`, `once`, or `relative` must be specified.
- PlaybookScheduleSpecificationOnceInput: The one-time schedule specification, including the start time.
- PlaybookScheduleSpecificationRecurringInput: The recurring schedule specification, including a cron expression string, start time, and end time.
- PlaybookScheduleSpecificationRelativeInput: The relative schedule specification, including the week, day of the week, offset, hour, minute,start time, and end time.
- PlaybookScheduleUpsertInput: A request to upsert a playbook schedule.
- PlaybookSoftwareBundleRefInput: A software bundle reference input.
- PlaybookSoftwareDeploymentClientNotificationInput: An end user notification displayed to Windows and macOS endpoint users after a deployment and before a restart.
- PlaybookSoftwareDeploymentClientNotificationTranslationInput: Translation of a client notification.
- PlaybookSoftwareDeploymentConfigInput: Input to configure a Software Deployment in Tanium Deploy.
- PlaybookSoftwareDeploymentPostponeOptionsInput: Postponement options for Windows and macOS endpoint users to delay a restart.
- PlaybookSoftwarePackageRefInput: A software package reference input.
- PlaybookStartInput: A request to start a playbook.
- PlaybookStepInput: Input for a playbook step.
- PlaybookStepOverrideInput: A request to define a step override. The playbook run uses the task argument values, endpoint targeting,
or both when provided. If neither `endpointTargeting` or `taskArgument` is provided, or the defined task
argument does not match the task type of the associated step, the response returns an error.
- PlaybookStepPatchInstallDeploymentConfigInput: Input for the Patch Install Deployment configuration.
This is similar to `PatchCreateDeploymentInput` but the following fields are omitted:
`type`, `schedule`, and `targeting`.
- PlaybookStepTargetingInput: Input for the playbook step targeting.
Define only one of `previousStepTargeting`, `previousStepCompletedTargeting`, or `customTargeting`.
- PlaybookStepTaskArgumentOverrideInput: A request to define a task argument override. The playbook run uses the task argument override
values for the associated step instead of the step task values defined in the playbook. The defined
task argument must match the task type used in the referenced playbook step. If the defined task
argument does not match the task type, the response returns an error.
- PlaybookUpsertInput: A request to upsert a playbook.
- ProgressionConditionInput: Input for a progression condition. Define one, and
only one, of the fields.
This is intended for Tanium internal use, and should not be used by customers.
- ProgressionConditionInputMinimumExecutionCount: Input for a minimum execution count progression condition.

A given number of targeted endpoints must execute a deployment action for this check to pass.
The number includes endpoints where the action executed but failed.
This is intended for Tanium internal use, and should not be used by customers.
- ProgressionConditionInputMinimumSuccessPercentage: Input for a minimum success percentage progression condition.

A given percentage of targeted endpoints must successfully execute a deployment action for this
check to pass.
This is intended for Tanium internal use, and should not be used by customers.
- ProgressionCriteriaInput: Input for Progression Criteria.
This is intended for Tanium internal use, and should not be used by customers.
- ProgressionCriteriaSetInput: Input for a Progression Criteria Set.
This is intended for Tanium internal use, and should not be used by customers.
- ProvisionCreateRetirementActionDefinitionInput: A request to create a retirement action definition.
- ProvisionCreateRetirementActionInput: A request to create a retirement action, which retires a single endpoint.
The endpoint to be retired can be specified via `targetEndpointParameters` or `endpointID`.
- ProvisionDeleteRetirementActionDefinitionsInput: A request to delete retirement action definitions that match the IDs.
- ProvisionFieldFilter: Input fields for filtering retirement actions.
- ProvisionRetirementActionFieldSort: Sorting criteria for retirement actions. The list is sorted by the specified field, in the specified order.
- ProvisionRetirementActionNotesDefinitionInput: A request to create retirement action notes.
- ProvisionRetirementActionNotesInput: Input fields for provision retirement action notes.
- ProvisionRetirementEndpointActionOptionsInput: undefined
- ProvisionRetirementNoteDefinitionInput: A request to create or update retirement action notes definition.
- ProvisionRetirementTargetEndpointParametersInput: Parameters used to manually target an endpoint.
- ProvisionUpdateRetirementActionInput: A request to update retirement action notes (`comment`, `requestedBy`, and `ticketNumber`).
- ProvisionUpdateRetirementDefinitionInput: A request to update a retirement action definition.
- RelationshipPayload: A request to manage a relationship between configuration item entities.
- RelationshipQueryParams: The configuration item relationships to include in the results.
- RelationshipSortRequest: The criteria by which to sort the relationships.
- ReportFieldFilter: Describes a filter for report field values.
A report must match every included filter condition to satisfy the filter.
- ReportImportInput: A request to import a report definition.
- RingDeploymentActionInput: A ring deployment action. One, and only one field must be defined.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentActionIssuePlatformActionInput: A ring deployment action that issues a platform action.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentActionProgressECFConfigurationItemInput: A ring deployment action that progresses an ECF configuration item.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentChangeWaitInput: A ring deployment change wait input.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentFieldFilter: Describes a filter for ring deployment field values.
A ring deployment must match every included filter condition to satisfy the filter.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentFieldSort: Sorting criteria for ring deployments.
The list is sorted by the specified field, in the specified order.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentPerformOperationInput: A ring deployment perform operation input.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentSchemeInput: This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentSendSignalInput: A ring deployment send signal input.
This is intended for Tanium internal use, and should not be used by customers.
- RingDeploymentStartInput: Request input to start a ring deployment.
This is intended for Tanium internal use, and should not be used by customers.
- RingSetInput: Input for a Ring Set.
This is intended for Tanium internal use, and should not be used by customers.
- RingSetRingInput: Input for a Ring.
This is intended for Tanium internal use, and should not be used by customers.
- ScheduledActionCreateInput: A request to create a scheduled action.
- ScheduledActionScheduleInput: The schedule on which the action should run.
- SensorHarvestInput: A request to manage the harvest registration of a sensor in TDS.
- SensorParameters: undefined
- SensorValueFilter: Describes a filter for endpoint sensor values. Sensor values matching the filter are included in the query results.
Sensor value filters may be single or compound (nested one level deep).

Any filter that is not valid causes the query to return an error.
- SoftwareTarget: The endpoints on which to perform a software management operation.
- TaniumPlatformRingTargetInput: Identifies a ring targetable by a platform action.
This is intended for Tanium internal use, and should not be used by customers.
- ThreatResponseAlertRef: Identifies a Threat Response alert. The `guid` must be specified.
- UpdateConfigurationItemPropertiesInput: A request to update properties of the configuration item in the CMDB.