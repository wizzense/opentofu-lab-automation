# Tanium Core Platform REST API Reference

Version: Latest
License: APIs are governed by the customer license agreement. See the End User License Agreement.

## Servers

```
https://customername-api.cloud.tanium.com
```

## Security

### ApiKey

Tanium API Key token-XXXXXXXX

Type: apiKey
In: header
Name: session


## Actions

### Get actions

 - [GET /api/v2/actions](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1actions/get.md): Retrieve all actions (action objects) on the server.

### Create action

 - [POST /api/v2/actions](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1actions/post.md): Create an action (action object). An action specifies a package to deploy, the machines to target, and the deploy schedule.For general information about actions, see Tanium Core Platform User Guide: Actions overview.

### Get action by name

 - [GET /api/v2/actions/by-name/{name}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1actions~1by-name~1%7Bname%7D/get.md): Retrieve actions (action objects) that match the specified name. Action names do not need to be unique, therefore this path might return multiple actions.

### Get action by ID

 - [GET /api/v2/actions/{id}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1actions~1%7Bid%7D/get.md): Retrieve the action (action object) that matches the specified ID.

### Update action by ID

 - [PATCH /api/v2/actions/{id}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1actions~1%7Bid%7D/patch.md): Update the action (action object) that matches the specified ID.

### Get action groups

 - [GET /api/v2/action_groups](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1action_groups/get.md): Retrieve all action groups (action_group objects) on the server.

### Create action group

 - [POST /api/v2/action_groups](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1action_groups/post.md): Create an action group (action_group object). Use action groups to target actions so that they are issued to only appropriate computer groups.

### Get action group by name

 - [GET /api/v2/action_groups/by-name/{name}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1action_groups~1by-name~1%7Bname%7D/get.md): Retrieve the action group (action_group object) that matches the specified name.

### Delete action group

 - [DELETE /api/v2/action_groups/{id}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1action_groups~1%7Bid%7D/delete.md): Delete the action group (action_group object) that matches the specified ID. Deleting an action group sets the deleted_flag property to 1, but does not remove the object from the server.

### Get action group by ID

 - [GET /api/v2/action_groups/{id}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1action_groups~1%7Bid%7D/get.md): Retrieve the action group (action_group object) that matches the specified ID.

### Update action group by ID

 - [PATCH /api/v2/action_groups/{id}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1action_groups~1%7Bid%7D/patch.md): Update the action group (action_group object) that matches the specified ID. When you update an action group, the server creates a new action_group object using the properties from the original action group and the properties supplied in the input JSON. The server then sets the deleted_flag property on the original action_group object to 1.

### Create action stop

 - [POST /api/v2/action_stops](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1action_stops/post.md): Create an action stop (action_stop object) to stop a specified action (identified by ID).

### Get action stop by ID

 - [GET /api/v2/action_stops/{id}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1action_stops~1%7Bid%7D/get.md): Retrieve the action stop (action_stop object) that matches the specified ID.

### Get action results by ID

 - [GET /api/v2/result_data/action/{id}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1result_data~1action~1%7Bid%7D/get.md): Retrieve the results for the action (action object) that matches the specified ID.

### Get action result info by ID

 - [GET /api/v2/result_info/action/{id}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1result_info~1action~1%7Bid%7D/get.md): Retrieve the result information for the action that matches the specified ID.

### Get saved actions

 - [GET /api/v2/saved_actions](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1saved_actions/get.md): Retrieve all saved actions (saved_action objects) on the server.

### Create saved action

 - [POST /api/v2/saved_actions](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1saved_actions/post.md): Create a scheduled action (saved_action object) that can reissue an action multiple times. The saved action creates a new action object when it issues an action.

### Get saved action by name

 - [GET /api/v2/saved_actions/by-name/{name}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1saved_actions~1by-name~1%7Bname%7D/get.md): Retrieve the saved action (saved_action object) that matches the specified name. If you do not know the exact name of the saved action, you can use a filter with the GET /api/v2/saved_actions path to retrieve an array of saved actions with names that match a regular expression.

### Update saved action by name

 - [PATCH /api/v2/saved_actions/by-name/{name}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1saved_actions~1by-name~1%7Bname%7D/patch.md): Update the saved action (saved_action object) that matches the specified name.

### Delete saved action

 - [DELETE /api/v2/saved_actions/{id}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1saved_actions~1%7Bid%7D/delete.md): Delete the saved action (saved_action object) that matches the specified ID. The saved action is removed from the server and is no longer available.

### Get saved action by ID

 - [GET /api/v2/saved_actions/{id}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1saved_actions~1%7Bid%7D/get.md): Retrieve the saved action (saved_action object) that matches the specified ID.

### Update saved action by ID

 - [PATCH /api/v2/saved_actions/{id}](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1saved_actions~1%7Bid%7D/patch.md): Update the saved action (saved_action object) that matches the specified ID.

### Get saved action approvals

 - [GET /api/v2/saved_action_approvals](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1saved_action_approvals/get.md): Retrieve all saved action approvals (saved_action_approval objects) on the server.

### Approve saved action

 - [POST /api/v2/saved_action_approvals](https://developer.tanium.com/apis/platform/actions/paths/~1api~1v2~1saved_action_approvals/post.md): Approve a saved action. Saved action approvals are only required when the require_action_approval global setting is set to 1.

## Audit data

### Get audit logs

 - [GET /api/v2/audit_logs/{type}/{id}](https://developer.tanium.com/apis/platform/audit-data/paths/~1api~1v2~1audit_logs~1%7Btype%7D~1%7Bid%7D/get.md): Retrieve the audit log entries (audit_log objects) for a specified object. The id path parameter is optional. When the id parameter is included, the path returns the most recent audit entry for the specified ID (object_id).When the id parameter is not included, the path returns the most recent entry for each unique object_id.Use the audit_history_size option to control the number of entries returned (see the Header parameters table for details).You can also include optional start_time and end_time options to limit the audit entries. Note the start_time and end_time parameters are ignored when a cache_id is used.Tip: Include options as only header parameters or only query string parameters in a single request. If you include options as both header parameters and query string parameters, the server might ignore the query string parameters.Note: Audit data is deleted according to the max_audit_data_expire_days global setting.Note: The max_soap_audit_entries_per_cache global setting limits the number of audit entries to put into the server cache. The default value is 1,000,000.Audit typesPath syntax1api_token/api/v2/audit_logs/api_tokensauthentication2/api/v2/audit_logs/authenticationcontent_set/api/v2/audit_logs/content_setscontent_set_privilege/api/v2/audit_logs/content_set_privilegescontent_set_role/api/v2/audit_logs/content_set_rolescontent_set_role_membership/api/v2/audit_logs/content_set_role_membershipscontent_set_role_privilege/api/v2/audit_logs/content_set_role_privilegescontent_set_user_group_role_membership/api/v2/audit_logs/content_set_user_group_role_membershipsdashboard/api/v2/audit_logs/dashboardsdashboard_group/api/v2/audit_logs/dashboard_groupsdownloader_auth_cert/api/v2/audit_logs/downloader_auth_certsdownloader_auth_user/api/v2/audit_logs/downloader_auth_usersdownloader_trusted_cert/api/v2/audit_logs/downloader_trusted_certsgroup3/api/v2/audit_logs/groupsintentional_subnet/api/v2/audit_logs/intentional_subnetsisolated_subnet/api/v2/audit_logs/isolated_subnetslocal_setting/api/v2/audit_logs/local_settingspackage_spec/api/v2/audit_logs/packagespersona/api/v2/audit_logs/personaspki_key_configuration/api/v2/audit_logs/pki_key_configurationspki_root_key/api/v2/audit_logs/pki_root_keysplugin_schedule/api/v2/audit_logs/plugin_schedulessaved_action/api/v2/audit_logs/saved_actionssaved_question/api/v2/audit_logs/saved_questionssensor/api/v2/audit_logs/sensorsseparated_subnet/api/v2/audit_logs/separated_subnetsserver_registration_request/api/v2/audit_logs/pki_server_registration_requestsserver_trust/api/v2/audit_logs/server_trustssystem_setting/api/v2/audit_logs/system_settingsuser/api/v2/audit_logs/usersuser_group/api/v2/audit_logs/user_groupswhite_listed_url/api/v2/audit_logs/white_listed_urlszone_server/api/v2/audit_logs/zone_server_assignments1 Most paths support the singular form of the audit type. For example, for personas, you can use /api/v2/audit_logs/persona or /api/v2/audit_logs/personas.2 The authentication audit does not have a corresponding object. The path returns entries for failed and successful sign-on attempts.3 Includes audit logs for filter_group and management_rights_group objects.Tip: Use the GET /api/v2/audit_types path to get an updated list of objects that you can audit on the server.

### Get audit types

 - [GET /api/v2/audit_types](https://developer.tanium.com/apis/platform/audit-data/paths/~1api~1v2~1audit_types/get.md): Retrieve the list of audit types on the server.

## Authentication

### Delete API token

 - [DELETE /api/v2/api_tokens/{id}](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1api_tokens~1%7Bid%7D/delete.md): Delete the API token (api_token object) that matches the specified ID.

### Get API token by ID

 - [GET /api/v2/api_tokens/{id}](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1api_tokens~1%7Bid%7D/get.md): Retrieve the API token (api_token object) that matches the specified ID. The object returned by this path does not include the token_string property.

### Get API tokens

 - [GET /api/v2/api_tokens](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1api_tokens/get.md): Retrieve all active API tokens (api_token objects) on the server. The objects returned by this path do not include the token_string properties.

### Rotate API token

 - [PATCH /api/v2/api_tokens](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1api_tokens/patch.md): Rotate the token for the API token (api_token object) that matches a specified token string and ID. This path deletes the API token and creates a new API token that you can use for authentication.Note: The new API token maintains applicable properties of the original API token, including user, expire_in_days, and notes.

### Create API token

 - [POST /api/v2/api_tokens](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1api_tokens/post.md): Create an API token (api_token object) for a user and persona that you can use for authentication across multiple sessions.IMPORTANT: By default, the Tanium Server blocks API tokens from all addresses except registered Tanium Module Servers. To add additional allowed IP addresses for any API token, add the external IP addresses of the endpoints to the api_token_trusted_ip_address_list global setting. To add allowed IP addresses for an individual API token, specify the IP addresses in the api_token.trusted_ip_addresse property.For proxies, set the authenticate_api_token_with_x_forwarded_for_ip global setting to 1 to force the Tanium Server to check for the IP provided by the X-Forwarded-For header (if one exists) for compatibility with reverse proxies situated between the client and the Tanium Server.As with all API requests, you must have a valid session string or an existing token string to create a token. You cannot use an existing token string to generate a valid session string.To use tokens, users must be assigned the Administrator reserved role or have the Token - Use permission, and must be signed in as the persona associated with the token. When you create an API token, you can define as_persona property in the body with a persona ID to associate the API token with a persona. If you do not define this when creating the API token, the persona ID of the active session populates this property.By default, an API token is valid for seven days. To change the expiration timeframe, edit the api_token_expiration_in_days global setting (minimum value is 1), or include a value with the expire_in_days property when you create the token.To use API tokens on a Tanium Appliance with the Tanium All-in-One role, you must change the IP address of the Tanium Module Server from 127.0.0.1 to the actual IP address of the machine. To do so, change the ModuleServer local setting in Tanium Console. For more information, see Tanium Console User Guide: Managing Tanium Server Platform settings.If the server restarts, the tokens remain valid.To use API tokens in a Tanium Cloud environment to query the API Gateway, use the following address: https://customerName>-api.cloud.tanium.com/plugin/products/gateway/graphql. For more information, see Tanium API Gateway User Guide: Authentication.Tips:To allow any token to be used from any IP address in a lab environment, set the api_token_trusted_ip_address_list global setting to 0.0.0.0/0. For optimal security, do not use this value in production environments.To allow a specific token to be used from any IP address in a lab environment, set the trusted_ip_addresses property to 0.0.0.0/0. For optimal security, do not use this value in production environments.Failed authentication attempts are signed in the &lt;Tanium Server&gt;/Logs/auth0.txt file.

### Get Downloads Authentication remote source authentication certificates

 - [GET /api/v2/downloader_auth_certs](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1downloader_auth_certs/get.md): Retrieve all downloader_auth_cert objects on the server. The private keys are encrypted on the Tanium Server and not included in responses from the server.

### Create Downloads Authentication remote source authentication certificate and paired private key

 - [POST /api/v2/downloader_auth_certs](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1downloader_auth_certs/post.md): Create a Downloads Authentication remote source authentication certificate and paired private key. The client certificate and paired key are used for authentication to a remote server. Your certificate must be in PEM format. You must include the entire content of the certificate, including -----BEGIN CERTIFICATE----- and -----END CERTIFICATE-----. Your private key must be in PEM format. You must include the entire content of the private key, including -----BEGIN PRIVATE KEY----- and -----END PRIVATE KEY-----.

### Get Downloads Authentication remote source authentication certificates by ID

 - [GET /api/v2/downloader_auth_certs/{id}](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1downloader_auth_certs~1%7Bid%7D/get.md): Retrieve the downloader_auth_cert object that matches the specified ID. The private key is encrypted on the Tanium Server and not included in responses from the server.

### Update Downloads Authentication remote source authentication certificate by ID

 - [PATCH /api/v2/downloader_auth_certs/{id}](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1downloader_auth_certs~1%7Bid%7D/patch.md): Update the downloader_auth_cert object that matches the specified ID.

### Get Downloads Authentication remote source authentication credentials

 - [GET /api/v2/downloader_auth_users/](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1downloader_auth_users~1/get.md): Retrieve all downloader_auth_user objects on the server.

### Create Downloads Authentication remote source authentication credentials

 - [POST /api/v2/downloader_auth_users/](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1downloader_auth_users~1/post.md): Create a set of Downloads Authentication remote source authentication credentials, used to sign into a remote server.

### Delete Downloads Authentication remote source authentication certificate

 - [DELETE /api/v2/downloader_auth_users/{id}](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1downloader_auth_users~1%7Bid%7D/delete.md): Delete the downloader_auth_cert that matches the specified ID.

### Get Downloads Authentication remote source authentication credentials by ID

 - [GET /api/v2/downloader_auth_users/{id}](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1downloader_auth_users~1%7Bid%7D/get.md): Retrieve the downloader_auth_user object that matches the specified ID.

### Update Downloads Authentication remote source authentication credentials by ID

 - [PATCH /api/v2/downloader_auth_users/{id}](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1downloader_auth_users~1%7Bid%7D/patch.md): Update the downloader_auth_user object that matches the specified ID.

### Get Downloads Authentication trusted certificates

 - [GET /api/v2/downloader_trusted_certs](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1downloader_trusted_certs/get.md): Retrieve all downloader_trusted_cert objects on the server.

### Create Downloads Authentication trusted certificate

 - [POST /api/v2/downloader_trusted_certs](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1downloader_trusted_certs/post.md): Create a Downloads Authentication trusted certificate, used to verify the identity of remote servers when establishing a connection. Your certificate must be in PEM format. You must include the entire content of the certificate, including -----BEGIN CERTIFICATE----- and -----END CERTIFICATE-----.

### Delete Downloads Authentication trusted certificate

 - [DELETE /api/v2/downloader_trusted_certs/{id}](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1downloader_trusted_certs~1%7Bid%7D/delete.md): Delete the downloader_trusted_cert object that matches the specified ID.

### Get Downloads Authentication trusted certificate by ID

 - [GET /api/v2/downloader_trusted_certs/{id}](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1downloader_trusted_certs~1%7Bid%7D/get.md): Retrieve the downloader_trusted_cert object that matches the specified ID.

### Update Downloads Authentication trusted certificate by ID

 - [PATCH /api/v2/downloader_trusted_certs/{id}](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1downloader_trusted_certs~1%7Bid%7D/patch.md): Update the downloader_trusted_cert object that matches the specified ID.

### Delete Tanium Server SSL certificate signing request

 - [DELETE /api/v2/https_certificate_signing_request](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1https_certificate_signing_request/delete.md): Delete a generated Tanium Server SSL certificate signing request (https_certificate_signing_request object) from the Tanium Server. If you want a CA sign a server certificate, you must generate another CSR to submit to the CA.

### Get Tanium Server SSL certificate signing request

 - [GET /api/v2/https_certificate_signing_request](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1https_certificate_signing_request/get.md): Retrieve a generated Tanium Server SSL certificate signing request (https_certificate_signing_request object). Copy the value of the pem property in the response and save it in a .csr file. Submit the CSR to a certificate authority (CA); upload the certificate signed by the CA using the POST /api/v2/https_certificates path. The certificate and paired key are used to authenticate communications with the Tanium Server, Tanium Module Server, and Tanium module services.

### Generate Tanium Server SSL certificate signing request

 - [POST /api/v2/https_certificate_signing_request](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1https_certificate_signing_request/post.md): Generate a Tanium Server SSL certificate signing request (https_certificate_signing_request object). Copy the value of the pem property in the response and save it in a .csr file. Submit the CSR to a certificate authority (CA); upload the certificate signed by the CA using the POST /api/v2/https_certificates path. The certificate and paired key are used to authenticate communications with the Tanium Server, Tanium Module Server, and Tanium module services.

### Get Tanium Server SSL certificates

 - [GET /api/v2/https_certificates](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1https_certificates/get.md): Retrieve all https_certificate objects on the server. The private keys are encrypted on the Tanium Server and not included in responses from the server.

### Upload Tanium Server SSL certificate

 - [POST /api/v2/https_certificates](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1https_certificates/post.md): Upload a CA-signed Tanium Server SSL certificate. The certificate and paired key are used to authenticate communications with the Tanium Server, Tanium Module Server, and Tanium module services. Your certificate must be in PEM format. You must include the content of the certificate, excluding -----BEGIN CERTIFICATE----- and -----END CERTIFICATE-----.

### Get SCIM servers

 - [GET /api/v2/scim_servers](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1scim_servers/get.md): Retrieve all scim_server objects configured on the server.

### Create SCIM server

 - [POST /api/v2/scim_servers](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1scim_servers/post.md): Create a System for Cross-Domain Identity Management (SCIM) scim_server object. Your SCIM server uses this object and the associated api_token object to communicate with the Tanium Server. When you create a scim_server object using this path, a new api_token and user are also created and associated with this object. The user.name property is populated as scim_server.name SCIM User and the api_token.notes property is populated as scim_server.name.Note: Copy the api_token.token_string value from the response body. You cannot retrieve it using the GET /api/v2/scim_servers/{id} path to retrieve the scim_server object.

### Delete SCIM server by ID

 - [DELETE /api/v2/scim_servers/{id}](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1scim_servers~1%7Bid%7D/delete.md): Delete the scim_server object that matches the specified ID. The scim_server object is removed from the server and is no longer available.

### Get SCIM server by ID

 - [GET /api/v2/scim_servers/{id}](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1scim_servers~1%7Bid%7D/get.md): Retrieve the scim_server object that matches the specified ID.

### Update SCIM server by ID

 - [PATCH /api/v2/scim_servers/{id}](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1scim_servers~1%7Bid%7D/patch.md): Update the scim_server object that matches the specified ID.

### Sign in as persona

 - [POST /api/v2/session/as_persona/{id}](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1session~1as_persona~1%7Bid%7D/post.md): Create a new session for the specified persona. To use this path, you must already be signed in with a valid session string, and your user must be assigned to the persona. You can send a request to GET /api/v2/users/{id} or GET /api/v2/personas/{id} to verify the user is assigned to the persona. If the user is not assigned to the persona, use the PATCH /api/v2/personas/{id} path to add the user to the persona. Sessions are independent of each other. After this path creates a new session for the specified persona, the original session remains active. If the original session is not needed, you should POST /api/v2/session/logout of the original session.You can call this path from any valid session authenticated with a session string, including another persona for the same user. You cannot call this path from any session authenticated with an API token string.The successful output of this path is always a session string. You can use the POST /api/v2/api_tokens to create an API token for the new session.

### Get current user and session

 - [GET /api/v2/session/current](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1session~1current/get.md): Retrieve details for the current user and session, including current persona.

### Sign in

 - [POST /api/v2/session/login](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1session~1login/post.md): Sign in to the Tanium Server. On success, the server responds with a session string that is valid for five minutes. Additional requests to the server require the session string. Each request to the server resets the timeout of the session string back to five minutes. Use the POST /api/v2/session/validate path to check if the session string is still valid.

### Sign out

 - [POST /api/v2/session/logout](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1session~1logout/post.md): Sign out of the Tanium Server. Use this path to end a session.

### Get management rights for current session

 - [GET /api/v2/session/management_rights](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1session~1management_rights/get.md): Retrieve the management rights for the current session. A successful response returns a list of management rights groups (management_rights_group objects) to which the current user and persona have access.

### Validate

 - [POST /api/v2/session/validate](https://developer.tanium.com/apis/platform/authentication/paths/~1api~1v2~1session~1validate/post.md): Check the session status to the Tanium Server. Note: In Tanium Core Platform 7.4.3 and later, you can also use this path to validate an API token. In the input JSON, assign the API token string to the session key (see example).Note: Depending on your security settings, you might need to pass authentication information in the header.

## Computer groups

### Create computer group using cached row reference IDs

 - [POST /api/v2/build_target_group](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1build_target_group/post.md): Create a computer group (computer_group object) using cache IDs and row reference IDs from results data.For example, when you GET /api/v2/result_data/question/{id} or GET /api/v2/result_data/saved_question/{id}, and pass a tanium-options header including a cache_expiration value, the results contain a cache_id value, and each row has a ref_id reference value. You can pass the cache_id and one or more ref_id reference values to create a computer group including only the endpoints corresponding to the referenced rows.

### Create manual group

 - [POST /api/v2/computer_groups](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1computer_groups/post.md): Create a manual computer group (computer_group object). For more information about groups, see Tanium Console User Guide: Managing computer groups.To create a manual group that is also a management rights group, see the POST /api/v2/management_rights_groups path.

### Get manual groups

 - [GET /api/v2/computer_groups](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1computer_groups/get.md): Retrieve all manual computer groups (computer_group objects) on the server. Groups with the deleted_flag property set to true are not included in the response.

### Get manual group by name

 - [GET /api/v2/computer_groups/by-name/{name}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1computer_groups~1by-name~1%7Bname%7D/get.md): Retrieve the manual computer group (computer_group object) that matches the specified name.

### Update manual group by name

 - [PATCH /api/v2/computer_groups/by-name/{name}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1computer_groups~1by-name~1%7Bname%7D/patch.md): Update the manual computer group (computer_group object) that matches the specified name.

### Delete manual group

 - [DELETE /api/v2/computer_groups/{id}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1computer_groups~1%7Bid%7D/delete.md): Delete the manual computer group (computer_group object) that matches the specified ID. Deleting a manual computer group sets the deleted_flag property to true, but does not remove the object from the server.

### Get manual group by ID

 - [GET /api/v2/computer_groups/{id}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1computer_groups~1%7Bid%7D/get.md): Retrieve the manual computer group (computer_group object) that matches the specified ID.

### Update manual group by ID

 - [PATCH /api/v2/computer_groups/{id}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1computer_groups~1%7Bid%7D/patch.md): Update the manual computer group (computer_group object) that matches the specified ID.

### Get filter groups

 - [GET /api/v2/filter_groups](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1filter_groups/get.md): Retrieve all filter groups (filter_group objects) on the server. Groups with the deleted_flag property set to true are not included in the response.

### Create filter group

 - [POST /api/v2/filter_groups](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1filter_groups/post.md): Create a filter group (filter_group object).For best results, use POST /api/v2/management_rights_groups to create management rights groups, POST /api/v2/filter_groups to create filter groups, or POST /api/v2/groups to create other group types.

### Get filter group by name

 - [GET /api/v2/filter_groups/by-name/{name}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1filter_groups~1by-name~1%7Bname%7D/get.md): Retrieve the filter group (filter_group object) that matches the specified name.

### Update filter group by name

 - [PATCH /api/v2/filter_groups/by-name/{name}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1filter_groups~1by-name~1%7Bname%7D/patch.md): Update the filter group (filter_group object) that matches the specified name.

### Delete filter group

 - [DELETE /api/v2/filter_groups/{id}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1filter_groups~1%7Bid%7D/delete.md): Delete the filter group (filter_group object) that matches the specified ID. Deleting a filter group sets the deleted_flag property to true, but does not remove the object from the server.

### Get filter group by ID

 - [GET /api/v2/filter_groups/{id}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1filter_groups~1%7Bid%7D/get.md): Retrieve the filter group (filter_group object) that matches the specified ID.

### Update filter group by ID

 - [PATCH /api/v2/filter_groups/{id}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1filter_groups~1%7Bid%7D/patch.md): Update the filter group (filter_group object) that matches the specified ID. The name and content_set properties are editable. Any other properties that you include in the input JSON are ignored. If you need to edit any other properties, you can delete the filter group and create a new filter group with the same name.

### Get groups

 - [GET /api/v2/groups](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1groups/get.md): Retrieve all groups on the server. Use this path to retrieve group, management_rights_group, and filter_group objects. Groups with the deleted_flag property set to true are not included in the response.

### Create group

 - [POST /api/v2/groups](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1groups/post.md): Create a filter-based computer group (group object). This path accepts canonical text in the text property. If you do not know the exact text of the question to base the group on, use the POST /api/v2/parse_question path to retrieve a list of question objects with possible canonical questions. For more information about groups, see Tanium Console User Guide: Managing computer groups.Important: For best results, use POST /api/v2/management_rights_groups to create management rights groups, POST /api/v2/filter_groups to create filter groups, or POST /api/v2/groups to create other group types.

### Get group by name

 - [GET /api/v2/groups/by-name/{name}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1groups~1by-name~1%7Bname%7D/get.md): Retrieve the group (group object) that matches the specified name.

### Update group by name

 - [PATCH /api/v2/groups/by-name/{name}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1groups~1by-name~1%7Bname%7D/patch.md): Update the group (group object) that matches the specified name. Use this path to update group, management_rights_group, and filter_group objects.

### Delete group

 - [DELETE /api/v2/groups/{id}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1groups~1%7Bid%7D/delete.md): Delete the group (group_object) that matches the specified ID. Deleting a group sets the deleted_flag property to true, but does not remove the object from the server.

### Get group by ID

 - [GET /api/v2/groups/{id}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1groups~1%7Bid%7D/get.md): Retrieve the group (group object) that matches the specified ID.

### Update group by ID

 - [PATCH /api/v2/groups/{id}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1groups~1%7Bid%7D/patch.md): Update the group (group object) that matches the specified ID. Use this path to update group, management_rights_group, and filter_group objects. For group objects, the name and content_set properties are editable. For management_rights_group and filter_group objects, the name, content_set, and filter_flag properties are editable. Any other properties that you include in the input JSON are ignored. If you need to edit any other properties, you can delete the group and create a new group of the same type with the same name.

### Get management rights groups

 - [GET /api/v2/management_rights_groups](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1management_rights_groups/get.md): Retrieve all management rights groups (management_rights_group objects) on the server. Management rights groups with the deleted_flag property set to true are not included in the response.

### Create management rights group

 - [POST /api/v2/management_rights_groups](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1management_rights_groups/post.md): Create a management rights group (management_rights_group object).Important: For best results, use POST /api/v2/management_rights_groups to create management rights groups, POST /api/v2/filter_groups to create filter groups, or POST /api/v2/groups to create other group types.

### Get management rights group by name

 - [GET /api/v2/management_rights_groups/by-name/{name}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1management_rights_groups~1by-name~1%7Bname%7D/get.md): Retrieve the management rights group (management_rights_group object) that matches the specified name.

### Delete management rights group

 - [DELETE /api/v2/management_rights_groups/{id}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1management_rights_groups~1%7Bid%7D/delete.md): Delete the management rights group (management_rights_group object) that matches the specified ID. Deleting a management rights group sets the deleted_flag property to true, but does not remove the object from the server.

### Get management rights group by ID

 - [GET /api/v2/management_rights_groups/{id}](https://developer.tanium.com/apis/platform/computer-groups/paths/~1api~1v2~1management_rights_groups~1%7Bid%7D/get.md): Retrieve the management rights group (management_rights_group object) that matches the specified ID.

## Content sets

### Get content set by name

 - [GET /api/v2/content_sets/by-name/{name}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_sets~1by-name~1%7Bname%7D/get.md): Retrieve the content set (content_set object) that matches the specified name.

### Update content set by name

 - [PATCH /api/v2/content_sets/by-name/{name}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_sets~1by-name~1%7Bname%7D/patch.md): Update the content set (content_set object) that matches the specified name.

### Get content sets

 - [GET /api/v2/content_sets](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_sets/get.md): Retrieve all active content sets (content_set objects) on the server.

### Create content set

 - [POST /api/v2/content_sets](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_sets/post.md): Create a content set (content_set object). A content set is a group of sensors, saved questions, dashboards, categories, and packages to which a permission applies. A content set is required for every sensor, package, saved question, dashboard, and dashboard group.

### Delete content set

 - [DELETE /api/v2/content_sets/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_sets~1%7Bid%7D/delete.md): Delete the content set (content_set object) that matches the specified ID. Deleting a content set sets the deleted_flag property to 1, but does not remove the object from the server.

### Get content set by ID

 - [GET /api/v2/content_sets/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_sets~1%7Bid%7D/get.md): Retrieve the content set (content_set object) that matches the specified ID.

### Update content set by ID

 - [PATCH /api/v2/content_sets/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_sets~1%7Bid%7D/patch.md): Update the content set (content_set object) that matches the specified ID.

### Get content set privileges

 - [GET /api/v2/content_set_privileges](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_privileges/get.md): Retrieve all content set privileges (content_set_privilege objects) on the server.

### Create content set privilege

 - [POST /api/v2/content_set_privileges](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_privileges/post.md): Create a content set privilege (content_set_privilege object). Privileges are used by roles to assign or deny permissions to users and user groups.

### Get content set privilege by name

 - [GET /api/v2/content_set_privileges/by-name/{name}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_privileges~1by-name~1%7Bname%7D/get.md): Retrieve the content set privilege (content_set_privilege object) that matches the specified name.

### Delete content set privilege

 - [DELETE /api/v2/content_set_privileges/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_privileges~1%7Bid%7D/delete.md): Delete the content set privilege (content_set_privilege object) that matches the specified ID. Deleting a content set privilege sets the deleted_flag property to 1, but does not remove the object from the server.

### Get content set privilege by ID

 - [GET /api/v2/content_set_privileges/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_privileges~1%7Bid%7D/get.md): Retrieve the content set privilege (content_set_privilege object) that matches the specified ID.

### Update content set privilege by ID

 - [PATCH /api/v2/content_set_privileges/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_privileges~1%7Bid%7D/patch.md): Update the content set privilege (content_set_privilege object) that matches the specified ID.

### Get content set roles

 - [GET /api/v2/content_set_roles](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_roles/get.md): Retrieve all content set roles (content_set_role objects) on the server.

### Create content set role

 - [POST /api/v2/content_set_roles](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_roles/post.md): Create a role (content_set_role object) to assign or deny permissions for users and user groups.

### Get content set role by name

 - [GET /api/v2/content_set_roles/by-name/{name}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_roles~1by-name~1%7Bname%7D/get.md): Retrieve the content set role (content_set_role object) that matches the specified name.

### Update content set role by name

 - [PATCH /api/v2/content_set_roles/by-name/{name}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_roles~1by-name~1%7Bname%7D/patch.md): Update the content set role (content_set_role object) that matches the specified name.

### Get content set role users and user groups

 - [GET /api/v2/content_set_roles/memberships](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_roles~1memberships/get.md): Retrieve the users and user groups associated with all content set roles (content_set_role objects).

### Delete content set role

 - [DELETE /api/v2/content_set_roles/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_roles~1%7Bid%7D/delete.md): Delete the content set role (content_set_role object) that matches the specified ID. Deleting a content set role sets the deleted_flag property to 1, but does not remove the object from the server.

### Get content set role by ID

 - [GET /api/v2/content_set_roles/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_roles~1%7Bid%7D/get.md): Retrieve the content set role (content_set_role object) that matches the specified ID.

### Update content set role by ID

 - [PATCH /api/v2/content_set_roles/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_roles~1%7Bid%7D/patch.md): Update the content set role (content_set_role object) that matches the specified ID.

### Get content set role users and user groups by ID

 - [GET /api/v2/content_set_roles/{id}/memberships](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_roles~1%7Bid%7D~1memberships/get.md): Retrieve the users and user groups associated with the specified content set role ID.

### Get content set role memberships

 - [GET /api/v2/content_set_role_memberships](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_role_memberships/get.md): Retrieve all content set role memberships (content_set_role_membership objects) on the server.

### Create content set role membership

 - [POST /api/v2/content_set_role_memberships](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_role_memberships/post.md): Assign a role to a user.

### Delete content set role membership

 - [DELETE /api/v2/content_set_role_memberships/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_role_memberships~1%7Bid%7D/delete.md): Delete the content set role membership (content_set_role_membership object) that matches the specified ID. Deleting a content set role membership sets the deleted_flag property to 1, but does not remove the object from the server.

### Get content set role membership by ID

 - [GET /api/v2/content_set_role_memberships/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_role_memberships~1%7Bid%7D/get.md): Retrieve the content set role membership (content_set_role_membership object) that matches the specified ID.

### Update content set role membership by ID

 - [PATCH /api/v2/content_set_role_memberships/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_role_memberships~1%7Bid%7D/patch.md): Update the content set role membership (content_set_role_membership object) that matches the specified ID. Warning: Updating an existing content set role membership affects user access to the Tanium server. Make sure you do not remove access for the administrator account.

### Create content set role privilege

 - [POST /api/v2/content_set_role_privileges](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_role_privileges/post.md): Create a content set role privilege (content_set_role_privilege object) to grant a content_set_privilege to a content_set and a content_set_role.

### Get content set role privileges

 - [GET /api/v2/content_set_role_privileges](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_role_privileges/get.md): Retrieve all content set role privileges (content_set_role_privilege objects) on the server.

### Delete content set role privilege

 - [DELETE /api/v2/content_set_role_privileges/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_role_privileges~1%7Bid%7D/delete.md): Delete the content set role privilege (content_set_role_privilege object) that matches the specified ID. Deleting a content set role privilege sets the deleted_flag property to 1, but does not remove the object from the server.

### Get content set role privilege by ID

 - [GET /api/v2/content_set_role_privileges/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_role_privileges~1%7Bid%7D/get.md): Retrieve the content set role privilege (content_set_role_privilege object) that matches the specified ID.

### Update content set role privilege by ID

 - [PATCH /api/v2/content_set_role_privileges/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_role_privileges~1%7Bid%7D/patch.md): Update the content set role privilege (content_set_role_privilege object) that matches the specified ID.

### Get content set user group role memberships

 - [GET /api/v2/content_set_user_group_role_memberships](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_user_group_role_memberships/get.md): Retrieve all content set user group role memberships (content_set_user_group_role_membership objects) on the server.

### Create content set user group role membership

 - [POST /api/v2/content_set_user_group_role_memberships](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_user_group_role_memberships/post.md): Assign a role to a user group.

### Delete content set user group role membership

 - [DELETE /api/v2/content_set_user_group_role_memberships/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_user_group_role_memberships~1%7Bid%7D/delete.md): Delete the content set user group role membership (content_set_user_group_role_membership object) that matches the specified ID. Deleting a content set user group role membership sets the deleted_flag property to 1, but does not remove the object from the server.

### Get content set user group role membership by ID

 - [GET /api/v2/content_set_user_group_role_memberships/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_user_group_role_memberships~1%7Bid%7D/get.md): Retrieve the content set user group role membership (content_set_user_group_role_membership object) that matches the specified ID.

### Update content set user group role membership by ID

 - [PATCH /api/v2/content_set_user_group_role_memberships/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1content_set_user_group_role_memberships~1%7Bid%7D/patch.md): Update the content set user group role membership (content_set_user_group_role_membership object) that matches the specified ID.

### Get effective content set privileges

 - [GET /api/v2/effective_content_set_privileges](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1effective_content_set_privileges/get.md): Retrieve all effective content set privileges (effective_content_set_privilege objects) for the current user.

### Get effective content set privileges by ID

 - [GET /api/v2/effective_content_set_privileges/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1effective_content_set_privileges~1%7Bid%7D/get.md): Retrieve all effective content set privileges (effective_content_set_privilege objects) for a specified user.

### Move content to different content set

 - [POST /api/v2/move](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1move/post.md): Assign content to a different content set. You can specify multiple types of objects, and a different content set for each object. Note that if the path returns an error for an object, the other objects specified in the input JSON might still be successful.

### Get effective content set roles (effective_role objects) by persona ID

 - [GET /api/v2/persona/{id}/effective-roles](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1persona~1%7Bid%7D~1effective-roles/get.md): Retrieve all content set roles assigned to a persona. The response contains effective roles, each containing the ID and name of a content set role.

### Get personas

 - [GET /api/v2/personas](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1personas/get.md): Retrieve all personas (persona objects) on the server. Personas with the deleted_flag property set to true are not included in the response.

### Create persona

 - [POST /api/v2/personas](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1personas/post.md): Create a persona (persona object) and assign it to users and user groups. A persona is a set of roles and computer groups that a user selects for a Tanium session.

### Delete persona

 - [DELETE /api/v2/personas/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1personas~1%7Bid%7D/delete.md): Delete the persona (persona object) that matches the specified ID. Deleting a persona sets the deleted_flag property to 1, but does not remove the object from the server. You cannot delete a persona if it owns a saved action, saved question, or plugin schedule.

### Get persona by ID

 - [GET /api/v2/personas/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1personas~1%7Bid%7D/get.md): Retrieve the persona (persona object) that matches the specified ID.

### Update persona by ID

 - [PATCH /api/v2/personas/{id}](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1personas~1%7Bid%7D/patch.md): Update the persona (persona object) that matches the specified ID.

### Preview effective privileges

 - [POST /api/v2/preview_content_set_role](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1preview_content_set_role/post.md): Preview the effective content set privileges for one or more content_set_role and content_set_role_privilege objects. You can preview the content set privileges for existing roles and privileges, or provide the objects for new content_set_role objects. This path does not create any objects; use the POST /api/v2/content_set_roles path to create a content_set_role.

### Preview effective and rejected privileges

 - [POST /api/v2/preview_content_set_role_detailed](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1preview_content_set_role_detailed/post.md): Preview the effective and rejected content set privileges for one or more existing content_set_role and content_set_role_privilege objects. A content set privilege is rejected if one or more roles or privileges passed in the request body allows the privilege, and one or more roles or privileges passed in the request body denies the privilege. You can preview the content set privileges for existing roles and privileges, or provide the new content_set_role objects. This path does not create any objects; use the POST /api/v2/content_set_roles path to create a content_set_role.

### Get effective content set roles for current session

 - [GET /api/v2/session/current/effective-roles](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1session~1current~1effective-roles/get.md): Retrieve all content set roles assigned to the current session and inherited from user groups to which the current session user belongs. The response contains effective_role objects, each containing the ID and name of a content set role.

### Get effective content set roles by user ID

 - [GET /api/v2/user/{id}/effective-roles](https://developer.tanium.com/apis/platform/content-sets/paths/~1api~1v2~1user~1%7Bid%7D~1effective-roles/get.md): Retrieve all content set roles assigned to a user and inherited from user groups to which the user belongs. The response contains effective roles, each containing the ID and name of a content set role.

## Dashboards

### Get dashboards

 - [GET /api/v2/dashboards](https://developer.tanium.com/apis/platform/dashboards/paths/~1api~1v2~1dashboards/get.md): Retrieve all dashboards (dashboard objects) on the server.

### Create dashboard

 - [POST /api/v2/dashboards](https://developer.tanium.com/apis/platform/dashboards/paths/~1api~1v2~1dashboards/post.md): Create a dashboard (dashboard object). A dashboard is an organized group of saved questions.

### Delete dashboard

 - [DELETE /api/v2/dashboards/{id}](https://developer.tanium.com/apis/platform/dashboards/paths/~1api~1v2~1dashboards~1%7Bid%7D/delete.md): Delete the dashboard (dashboard object) that matches the specified ID. The dashboard is removed from the server and is no longer available.

### Get dashboard by ID

 - [GET /api/v2/dashboards/{id}](https://developer.tanium.com/apis/platform/dashboards/paths/~1api~1v2~1dashboards~1%7Bid%7D/get.md): Retrieve the dashboard (dashboard object) that matches the specified ID.

### Update dashboard by ID

 - [PATCH /api/v2/dashboards/{id}](https://developer.tanium.com/apis/platform/dashboards/paths/~1api~1v2~1dashboards~1%7Bid%7D/patch.md): Update the dashboard (dashboard object) that matches the specified ID.

### Get dashboard groups

 - [GET /api/v2/dashboard_groups](https://developer.tanium.com/apis/platform/dashboards/paths/~1api~1v2~1dashboard_groups/get.md): Retrieve all dashboard groups (dashboard_group objects) on the server.

### Create dashboard group

 - [POST /api/v2/dashboard_groups](https://developer.tanium.com/apis/platform/dashboards/paths/~1api~1v2~1dashboard_groups/post.md): Create a dashboard group (dashboard_group object).

### Delete dashboard group

 - [DELETE /api/v2/dashboard_groups/{id}](https://developer.tanium.com/apis/platform/dashboards/paths/~1api~1v2~1dashboard_groups~1%7Bid%7D/delete.md): Delete the dashboard group (dashboard_group object) that matches the specified ID. The dashboard group is removed from the server and is no longer available.

### Get dashboard group by ID

 - [GET /api/v2/dashboard_groups/{id}](https://developer.tanium.com/apis/platform/dashboards/paths/~1api~1v2~1dashboard_groups~1%7Bid%7D/get.md): Retrieve the dashboard group (dashboard_group object) that matches the specified ID.

### Update dashboard group by ID

 - [PATCH /api/v2/dashboard_groups/{id}](https://developer.tanium.com/apis/platform/dashboards/paths/~1api~1v2~1dashboard_groups~1%7Bid%7D/patch.md): Update the dashboard group (dashboard_group object) that matches the specified ID.

## Import/Export

### Export object history

 - [GET /api/v2/export](https://developer.tanium.com/apis/platform/importexport/paths/~1api~1v2~1export/get.md): Export object history by the name of the history type. Administrators and users with the Export Content permission are able to export content. Objects export to a JSON or CSV format that you can save to a file. Valid objects to export include:action_historyquestion_historyIn the URI, pass the optional input query parameter as URL encoded JSON if you also define mode=csv as a query parameter.The input.columns parameter is optional, to select specific columns and display names to output in the response. If this is not defined, the default columns and English display names are included in the response.The input.ids parameter is optional, to include certain objects in the response that match the ID. If this is not defined, all objects are included in the response.For example, to pass the following: { "columns": [ { "key": "id", "name": "question_id" }, { "key": "user/name", "name": "User Name" } ], "ids": [ 123, 234, 345 ] }Define the query string as: ?mode=csv&input=%7B%20%22columns%22%3A%20%5B%20%7B%20%22key%22%3A%20%22id%22%2C %20%22name%22%3A%20%22question_id%22%20%7D%2C%20%7B%20%22key%22%3A%20%22user%2F name%22%2C%20%22name%22%3A%20%22User%20Name%22%20%7D%20%5D%2C%20%22ids%22%3A%20 %5B%20123%2C%20234%2C%20345%20%5D%20%7D.

### Export objects

 - [POST /api/v2/export](https://developer.tanium.com/apis/platform/importexport/paths/~1api~1v2~1export/post.md): Export objects by the name of the objects. Administrators and users with the Export Content permission are able to export content. Any related objects are included in the export. Objects export to a JSON format that you can save to a file. Valid objects to export include:content_setcontent_set_privilegecontent_set_rolecontent_set_role_privilegedashboarddashboard_groupgroupldap_sync_connectorpackage_specsaved_actionsaved_questionsensorwhite_listed_urlNotes: Use the group object to export filter_group and management_rights_group objects.If you export a saved_question object, the keep_seconds value is defined as the value associated with your user account and active persona, regardless of the value on the saved question before export.You can export saved_action objects by ID or name. See example for the syntax to export by ID.

### Import

 - [POST /api/v2/import](https://developer.tanium.com/apis/platform/importexport/paths/~1api~1v2~1import/post.md): Import objects from a JSON file. Users who are assigned a role with Import Signed Content permission can import signed content files. Users who have the Administrator reserved role can export and import all content types. Any user can import an object if the user has write permissions to the object. For example, if you have the Sensor write permission, you can import sensors. For more information, see Tanium Console User Guide: Authenticating content files.Best Practice: In Tanium deployments with a lab license, Tanium Console notifies you if the file you selected to import is unsigned and lets you choose whether to proceed. However, the best practice is to not import unsigned files in any deployment.You can include options to handle any import conflicts. If you do not pass any options, the server accepts the import only if there are no conflicts. If there are conflicts, the response includes an import_conflict_details report of the objects in the file and properties that differ for any conflicts. You need to resolve any conflicts and resubmit with the import_conflict_options option or the global default_import_conflict_option option.Valid objects to import include:content_setcontent_set_privilegecontent_set_rolecontent_set_role_privilegedashboarddashboard_groupgroupldap_sync_connectorpackage_specpluginsaved_actionsaved_questionsensorsolutionwhite_listed_urlNotes:If multiple saved_action objects with the same name are included in a single import, the server creates a separate saved_action object for each saved action. Any saved actions with duplicate names already on the server are deleted.If you import saved questions, define the disabled_flag property as 1 for the saved questions to prevent the Tanium Server from automatically reissuing the saved questions. Define the disabled_flag property as 0 or exclude it from the saved question to allow the Tanium Server to automatically reissue the saved question.If you import saved questions, the keep_seconds value is defined as the value associated with your user account and active persona, regardless of the value in the import file when imported.If you post a deprecated XML solution file to /api/v2/import, the server upgrades the file and imports the file. If you want to import a deprecated file without upgrading the file to the current version, use the POST /api/v2/import/upgrade path to post the file; the server response is a JSON export file.

### Get import status by ID

 - [GET /api/v2/import/{id}](https://developer.tanium.com/apis/platform/importexport/paths/~1api~1v2~1import~1%7Bid%7D/get.md): Retrieve the status of an asynchronous import job.

## Keys

### Delete zone server

 - [DELETE /api/v2/hubs/{hub_id}/zone_servers/{zone_id}](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1hubs~1%7Bhub_id%7D~1zone_servers~1%7Bzone_id%7D/delete.md): Delete a zone server (zone_server object) that connects to the zone server hub with the specified server registration ID. This path sets the deleted_flag property to true, but does not remove the object from the server. Although the object still exists in the database, the object is no longer accessible through the API. To use this path, you must have an Administrator role, or you must have the "Manage Zone Servers" privilege.

### Get zone servers by hub ID

 - [GET /api/v2/hubs/{id}/zone_servers](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1hubs~1%7Bid%7D~1zone_servers/get.md): Retrieve the zone servers (zone_server objects) that connect to the zone server hub with the specified server registration ID. To use this path, you must have an Administrator role.

### Create zone server

 - [POST /api/v2/hubs/{id}/zone_servers](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1hubs~1%7Bid%7D~1zone_servers/post.md): Create a zone server (zone_server object) to connect to the zone server hub with the specified server registration ID. To use this path, you must have an Administrator role.

### Get root public key

 - [GET /api/v2/keys/314](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1keys~1314/get.md): Retrieve the Tanium Server root public key (tanium.pub). Tanium Clients 7.2 or earlier use only the root public key to authenticate. Use this path to download the public key file from the Tanium Server that you can then deploy to the Tanium Clients, Zone Server, and Zone Server Hub.

### Get PKI initialization bundle

 - [GET /api/v2/keys/315](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1keys~1315/get.md): Retrieve the Tanium initialization bundle (tanium-init.dat). The Zone Server, Zone Server Hub, and Tanium Clients must authenticate to the Tanium Server to enable communication with it. Version 7.4 of the servers and clients use keys that are inside the initialization bundle (tanium-init.dat) to authenticate. Use this path to download the initialization bundle from the Tanium Server that you can then deploy to the Tanium Clients, Zone Server, and Zone Server Hub. For best results, use the server_list parameter with a list of servers to include in the bundle. If you call this path without the server_list parameter, the response does not include server names, and you will need to configure the server name list.

### Create PKI initialization bundle

 - [POST /api/v2/keys/315](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1keys~1315/post.md): This requires Tanium Core Platform 7.5.2 or later and Tanium Client version 7.4.7 or later.Create the Tanium initialization bundle (tanium-init.dat) with custom settings as needed. The Zone Server, Zone Server Hub, and Tanium Clients must authenticate to the Tanium Server to enable communication with it. Version 7.4 or later of the servers and clients use keys that are inside tanium-init.dat to authenticate. Use this path to create and download the initialization bundle from the Tanium Server that you can then deploy to the Tanium Clients, Zone Server, and Zone Server Hub.The following table describes the JSON format.PropertiesPropertyTypeRequiredDescriptionnamestringRequiredThe client setting name. For more information about client settings, see Tanium Client Management User Guide: Tanium Client settings and CLI.overridebooleanOptionalSet to true to overwrite an existing setting. Set to false to leave an existing setting and not overwrite it. If undefined, this defaults to false.valueboolean, number, or stringRequiredThe setting value.

### Get PKI key configurations

 - [GET /api/v2/pki_key_configurations](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1pki_key_configurations/get.md): Retrieve all PKI key configurations (pki_key_configuration objects) on the server.

### Create test key configuration

 - [POST /api/v2/pki_key_configurations/validate](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1pki_key_configurations~1validate/post.md): Create a test key configuration for an HSM token.

### Update PKI key configuration (pki_key_configuration object) by ID

 - [PATCH /api/v2/pki_key_configurations/{id}](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1pki_key_configurations~1%7Bid%7D/patch.md): Update the PKI key configuration that matches the specified ID. Only the following properties are editable:use_hsm_flaghsm_allow_uninitialized_tokenhsm_custom_user_typehsm_token_namehsm_pin

### Get PKI root keys

 - [GET /api/v2/pki_root_keys](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1pki_root_keys/get.md): Retrieve all PKI root keys (pki_root_key objects) on the server.

### Generate PKI root key

 - [POST /api/v2/pki_root_keys](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1pki_root_keys/post.md): Generate a PKI root key (pki_root_key object) on the Tanium server. A PKI root key governs the security of non-Tanium communication among the endpoints in an enterprise. Keys are not shared between servers in an active-active cluster configuration.

### Revoke PKI root key

 - [DELETE /api/v2/pki_root_keys/by-fingerprint/{fingerprint}](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1pki_root_keys~1by-fingerprint~1%7Bfingerprint%7D/delete.md): Revoke the PKI root key (pki_root_key object) that matches the specified fingerprint. The PKI root key is removed from the server and is no longer available.

### Get PKI root key by fingerprint

 - [GET /api/v2/pki_root_keys/by-fingerprint/{fingerprint}](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1pki_root_keys~1by-fingerprint~1%7Bfingerprint%7D/get.md): Retrieve the PKI root key (pki_root_key object) that matches the specified fingerprint. By default, the algorithm used is "SHA512"; use the algorithm parameter on the query string to override the default.

### Get server registration requests

 - [GET /api/v2/server_registration_requests](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1server_registration_requests/get.md): Retrieve all server registration requests (server_registration_request objects) on the server. Server registration requests are automatically created when servers try to register with the server. To use this path, you must have an Administrator reserved role.

### Update server registration request by ID

 - [PATCH /api/v2/server_registration_requests/{id}](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1server_registration_requests~1%7Bid%7D/patch.md): Update the server registration request (server_registration_request object) that matches the specified ID. Use this path to approve, reject, and revoke server registration requests. Only the following properties are editable:approved_flagrejected_flagrevoked_flagTo use this path, you must have an Administrator reserved role.

### Delete server trust

 - [DELETE /api/v2/server_trusts](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1server_trusts/delete.md): Remove a specified server trust (server_trust object). This path allows the current server to stop trusting the target server, and any specified keys are revoked.

### Get server trusts

 - [GET /api/v2/server_trusts](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1server_trusts/get.md): Retrieve the trust relationships (server_trust objects) between the current server and other Tanium servers in an active-active cluster. Relationships can indicate 2-way trusts, 1-way trusts, no trusts, or revoked trusts.

### Create server trust

 - [POST /api/v2/server_trusts](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1server_trusts/post.md): Create a trust relationship (server_trust object) between the current server and another Tanium server.

### Get server trust by GUID

 - [GET /api/v2/server_trusts/{guid}](https://developer.tanium.com/apis/platform/keys/paths/~1api~1v2~1server_trusts~1%7Bguid%7D/get.md): Retrieve the trust relationship (server_trust object) between the current server and another server with the specified GUID.

## LDAP

### Get LDAP sync connectors

 - [GET /api/v2/ldap_sync_connectors](https://developer.tanium.com/apis/platform/ldap/paths/~1api~1v2~1ldap_sync_connectors/get.md): Retrieve all LDAP synchronization connectors (ldap_sync_connector objects) on the server.

### Create LDAP sync connector

 - [POST /api/v2/ldap_sync_connectors](https://developer.tanium.com/apis/platform/ldap/paths/~1api~1v2~1ldap_sync_connectors/post.md): Create an LDAP synchronization connector (ldap_sync_connector object). The connector might take up to five minutes to synchronize with the LDAP server. To immediately synchronize, use the POST /api/v2/start_ldap_sync path.

### Get LDAP sync connector by name

 - [GET /api/v2/ldap_sync_connectors/by-name/{name}](https://developer.tanium.com/apis/platform/ldap/paths/~1api~1v2~1ldap_sync_connectors~1by-name~1%7Bname%7D/get.md): Retrieve the LDAP synchronization connector (ldap_sync_connector object) that matches the specified name.

### Update LDAP sync connector by name

 - [PATCH /api/v2/ldap_sync_connectors/by-name/{name}](https://developer.tanium.com/apis/platform/ldap/paths/~1api~1v2~1ldap_sync_connectors~1by-name~1%7Bname%7D/patch.md): Update the LDAP synchronization connector (ldap_sync_connector object) that matches the specified name.

### Delete LDAP sync connector

 - [DELETE /api/v2/ldap_sync_connectors/{id}](https://developer.tanium.com/apis/platform/ldap/paths/~1api~1v2~1ldap_sync_connectors~1%7Bid%7D/delete.md): Delete the LDAP synchronization connector (ldap_sync_connector object) that matches the specified ID. The LDAP synchronization connector is removed from the server and is no longer available.

### Get LDAP sync connector by ID

 - [GET /api/v2/ldap_sync_connectors/{id}](https://developer.tanium.com/apis/platform/ldap/paths/~1api~1v2~1ldap_sync_connectors~1%7Bid%7D/get.md): Retrieve the LDAP synchronization connector (ldap_sync_connector object) that matches the specified ID.

### Update LDAP sync connector by ID

 - [PATCH /api/v2/ldap_sync_connectors/{id}](https://developer.tanium.com/apis/platform/ldap/paths/~1api~1v2~1ldap_sync_connectors~1%7Bid%7D/patch.md): Update the LDAP synchronization connector (ldap_sync_connector object) that matches the specified ID.

### Start LDAP synchronization

 - [POST /api/v2/start_ldap_sync](https://developer.tanium.com/apis/platform/ldap/paths/~1api~1v2~1start_ldap_sync/post.md): Immediately synchronize with all enabled LDAP servers.

## Metrics

### Get Tanium Server metrics

 - [GET /metrics](https://developer.tanium.com/apis/platform/metrics/paths/~1metrics/get.md): Retrieve metrics descriptions from the Tanium Server.

## Packages

### Get packages

 - [GET /api/v2/packages](https://developer.tanium.com/apis/platform/packages/paths/~1api~1v2~1packages/get.md): Retrieve all packages (package_spec objects) on the server.

### Create package

 - [POST /api/v2/packages](https://developer.tanium.com/apis/platform/packages/paths/~1api~1v2~1packages/post.md): Create a package (package_spec object). A package contains a list of files to distribute and a command to run.

### Get package by name

 - [GET /api/v2/packages/by-name/{name}](https://developer.tanium.com/apis/platform/packages/paths/~1api~1v2~1packages~1by-name~1%7Bname%7D/get.md): Retrieve the package (package_spec object) that matches the specified name.

### Update package by name

 - [PATCH /api/v2/packages/by-name/{name}](https://developer.tanium.com/apis/platform/packages/paths/~1api~1v2~1packages~1by-name~1%7Bname%7D/patch.md): Update the package (package_spec object) that matches the specified name.

### Delete package

 - [DELETE /api/v2/packages/{id}](https://developer.tanium.com/apis/platform/packages/paths/~1api~1v2~1packages~1%7Bid%7D/delete.md): Delete the package (package_spec object) that matches the specified ID. The package is removed from the server and is no longer available.

### Get package by ID

 - [GET /api/v2/packages/{id}](https://developer.tanium.com/apis/platform/packages/paths/~1api~1v2~1packages~1%7Bid%7D/get.md): Retrieve the package (package_spec obejct) that matches the specified ID.

### Update package by ID

 - [PATCH /api/v2/packages/{id}](https://developer.tanium.com/apis/platform/packages/paths/~1api~1v2~1packages~1%7Bid%7D/patch.md): Update the package (package_spec object) that matches the specified ID.

### Get package files

 - [GET /api/v2/package_files](https://developer.tanium.com/apis/platform/packages/paths/~1api~1v2~1package_files/get.md): Retrieve all package files (package_file objects) on the server.

### Update package file by ID

 - [PATCH /api/v2/package_files/{id}](https://developer.tanium.com/apis/platform/packages/paths/~1api~1v2~1package_files~1%7Bid%7D/patch.md): Update the package file (package_file object) that matches the specified ID. Use this path to set trigger_download to 1 to force the server to re-download the package file into the cache. This path only accepts the trigger_download property; other properties are ignored or might result in errors.

### Upload package files

 - [POST /api/v2/upload_file_stream](https://developer.tanium.com/apis/platform/packages/paths/~1api~1v2~1upload_file_stream/post.md): Upload a package file using file streaming. The response returns an uploaded file hash value. To include this file with a package, set package_spec.files.hash to this returned hash value. This path supports either the application/octet-stream or multipart/form-data content types, passed in an HTTP header.If you define the application/octet-stream content type, specify a file to upload.If you define the multipart/form-data content type, specify a file to upload in the form data.

## Plugins

### Get plugin schedules

 - [GET /api/v2/plugin_schedules](https://developer.tanium.com/apis/platform/plugins/paths/~1api~1v2~1plugin_schedules/get.md): Retrieve all plugin schedules (plugin_schedule objects) on the server.

### Create plugin schedule

 - [POST /api/v2/plugin_schedules](https://developer.tanium.com/apis/platform/plugins/paths/~1api~1v2~1plugin_schedules/post.md): Create a plugin schedule (plugin_schedule object). A plugin schedule runs the specified plugin as the user that created the schedule.

### Get plugin schedule by name

 - [GET /api/v2/plugin_schedules/by-name/{name}](https://developer.tanium.com/apis/platform/plugins/paths/~1api~1v2~1plugin_schedules~1by-name~1%7Bname%7D/get.md): Retrieve the plugin schedule (plugin_schedule object) that matches the specified name.

### Update plugin schedule by name

 - [PATCH /api/v2/plugin_schedules/by-name/{name}](https://developer.tanium.com/apis/platform/plugins/paths/~1api~1v2~1plugin_schedules~1by-name~1%7Bname%7D/patch.md): Update the plugin schedule (plugin_schedule object) that matches the specified name.

### Delete plugin schedule

 - [DELETE /api/v2/plugin_schedules/{id}](https://developer.tanium.com/apis/platform/plugins/paths/~1api~1v2~1plugin_schedules~1%7Bid%7D/delete.md): Delete the plugin schedule (plugin_schedule object) that matches the specified ID. Deleting a plugin schedule sets the deleted_flag property to true, but does not remove the object from the server. All users with the Administrator role can delete any plugin schedules, and any user can delete their own plugin schedules; no specific permission is required.

### Get plugin schedule by ID

 - [GET /api/v2/plugin_schedules/{id}](https://developer.tanium.com/apis/platform/plugins/paths/~1api~1v2~1plugin_schedules~1%7Bid%7D/get.md): Retrieve the plugin schedule (plugin_schedule object) that matches the specified ID.

### Update plugin schedule by ID

 - [PATCH /api/v2/plugin_schedules/{id}](https://developer.tanium.com/apis/platform/plugins/paths/~1api~1v2~1plugin_schedules~1%7Bid%7D/patch.md): Update the plugin schedule (plugin_schedule object) that matches the specified ID.

### Get plugins

 - [GET /api/v2/plugins](https://developer.tanium.com/apis/platform/plugins/paths/~1api~1v2~1plugins/get.md): Retrieve all plugins (plugin objects) on the server.

### Run plugin

 - [POST /api/v2/run_plugin](https://developer.tanium.com/apis/platform/plugins/paths/~1api~1v2~1run_plugin/post.md): Run a specified plugin (plugin object). Running a plugin through this request is synchronous and takes several minutes to complete.

## Questions

### Build group text

 - [POST /api/v2/build_group_text](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1build_group_text/post.md): Build group text clause from a group object.

### Build question text

 - [POST /api/v2/build_question_text](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1build_question_text/post.md): Build canonical question text.

### Get merged result data for multiple questions

 - [GET /api/v2/merged_result_data/{object}/{id}/{object}/{id}](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1merged_result_data~1%7Bobject%7D~1%7Bid%7D~1%7Bobject%7D~1%7Bid%7D/get.md): Retrieve merged result data for multiple questions and saved questions using the ID of the specified questions and saved questions. There is no limit to the number of questions for which you can merge results.

### Parse question

 - [POST /api/v2/parse_question](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1parse_question/post.md): Parse a question (question object). Use this path to send question text to the Tanium Server. The server responds with one or more questions that you can then use to ask a question with the POST /api/v2/questions path.Tip: If you already have the exact syntax (canonical text) of the question, use the POST /api/v2/questions path to ask the question.

### Get questions

 - [GET /api/v2/questions](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1questions/get.md): Retrieve all questions (question objects) on the server.

### Create question

 - [POST /api/v2/questions](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1questions/post.md): Create a question (question object) on the Tanium Server. The question is immediately asked.

### Get question by ID

 - [GET /api/v2/questions/{id}](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1questions~1%7Bid%7D/get.md): Retrieve the question (question object) that matches the specified ID.

### Get question results by ID

 - [GET /api/v2/result_data/question/{id}](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1result_data~1question~1%7Bid%7D/get.md): Retrieve the question results for the specified question ID.

### Get saved question results by ID

 - [GET /api/v2/result_data/saved_question/{id}](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1result_data~1saved_question~1%7Bid%7D/get.md): Retrieve the saved question (saved_question object) results for the specified saved question ID.

### Get question result info by ID

 - [GET /api/v2/result_info/question/{id}](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1result_info~1question~1%7Bid%7D/get.md): Retrieve result information for a question that matches the specified question ID.

### Get saved question result info by ID

 - [GET /api/v2/result_info/saved_question/{id}](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1result_info~1saved_question~1%7Bid%7D/get.md): Retrieve result information for a saved question that matches the specified saved question ID.

### Get saved questions

 - [GET /api/v2/saved_questions](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1saved_questions/get.md): Retrieve all saved questions (saved_question objects) on the server.

### Create saved question

 - [POST /api/v2/saved_questions](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1saved_questions/post.md): Create a saved question (saved_question object) from an existing question. Use a saved question to issue the same question to the clients multiple times.

### Get saved question by name

 - [GET /api/v2/saved_questions/by-name/{name}](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1saved_questions~1by-name~1%7Bname%7D/get.md): Retrieve the saved question (saved_question object) that matches the specified name.

### Update saved question by name

 - [PATCH /api/v2/saved_questions/by-name/{name}](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1saved_questions~1by-name~1%7Bname%7D/patch.md): Update the saved question (saved_question object) that matches the specified name.

### Delete saved question

 - [DELETE /api/v2/saved_questions/{id}](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1saved_questions~1%7Bid%7D/delete.md): Delete the saved question (saved_question object) that matches the specified ID. Deleting a saved question sets the deleted_flag property to true, but does not remove the object from the server.

### Get saved question by ID

 - [GET /api/v2/saved_questions/{id}](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1saved_questions~1%7Bid%7D/get.md): Retrieve the saved question (saved_question object) that matches the specified ID.

### Update saved question by ID

 - [PATCH /api/v2/saved_questions/{id}](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1saved_questions~1%7Bid%7D/patch.md): Update the saved question (saved_question object) that matches the specified ID.

### Get saved question questions by ID

 - [GET /api/v2/saved_questions/{id}/questions](https://developer.tanium.com/apis/platform/questions/paths/~1api~1v2~1saved_questions~1%7Bid%7D~1questions/get.md): Retrieve the questions issued by a saved question that matches the specified saved question ID.

## Sensors

### Get sensors

 - [GET /api/v2/sensors](https://developer.tanium.com/apis/platform/sensors/paths/~1api~1v2~1sensors/get.md): Retrieve all sensors (sensor objects) on the server.

### Create sensor

 - [POST /api/v2/sensors](https://developer.tanium.com/apis/platform/sensors/paths/~1api~1v2~1sensors/post.md): Create a sensor (sensor object).

### Delete sensor

 - [DELETE /api/v2/sensors/{id}](https://developer.tanium.com/apis/platform/sensors/paths/~1api~1v2~1sensors~1%7Bid%7D/delete.md): Delete the sensor (sensor object) that matches the specified ID. Deleting a sensor sets the deleted_flag property to true, but does not remove the object from the server.

### Get sensor by ID

 - [GET /api/v2/sensors/{id}](https://developer.tanium.com/apis/platform/sensors/paths/~1api~1v2~1sensors~1%7Bid%7D/get.md): Retrieve the sensor (sensor object) that matches the specified ID.

### Update sensor by ID

 - [PATCH /api/v2/sensors/{id}](https://developer.tanium.com/apis/platform/sensors/paths/~1api~1v2~1sensors~1%7Bid%7D/patch.md): Update the sensor (sensor object) that matches the specified ID. You cannot update sensors with the category property set to Reserved, except for the max_string_age_minutes and max_strings properties.

### Get sensor by name

 - [GET /api/v2/sensors/by-name/{name}](https://developer.tanium.com/apis/platform/sensors/paths/~1api~1v2~1sensors~1by-name~1%7Bname%7D/get.md): Retrieve the sensor (sensor object) that matches the specified name.

### Update sensor by name

 - [PATCH /api/v2/sensors/by-name/{name}](https://developer.tanium.com/apis/platform/sensors/paths/~1api~1v2~1sensors~1by-name~1%7Bname%7D/patch.md): Update the sensor (sensor object) that matches the specified name. You cannot update sensors with the category property set to Reserved, except for the max_string_age_minutes and max_strings properties.

### Get sensor by hash

 - [GET /api/v2/sensors/by-hash/{hash}](https://developer.tanium.com/apis/platform/sensors/paths/~1api~1v2~1sensors~1by-hash~1%7Bhash%7D/get.md): Retrieve the sensor (sensor object) that matches the specified hash.

### Get sensor statistics

 - [GET /api/v2/sensor_stats](https://developer.tanium.com/apis/platform/sensors/paths/~1api~1v2~1sensor_stats/get.md): Retrieve all sensor statistics (sensor_stat objects) on the server.

### Get sensor statistics by name

 - [GET /api/v2/sensor_stats/by-name/{name}](https://developer.tanium.com/apis/platform/sensors/paths/~1api~1v2~1sensor_stats~1by-name~1%7Bname%7D/get.md): Retrieve the sensor statistics (sensor_stat object) that matches the specified name.

### Get sensor statistics by ID

 - [GET /api/v2/sensor_stats/{id}](https://developer.tanium.com/apis/platform/sensors/paths/~1api~1v2~1sensor_stats~1%7Bid%7D/get.md): Retrieve the sensor statistics (sensor_stat object) that match the specified ID.

## Solutions

### Get solutions

 - [GET /api/v2/solutions](https://developer.tanium.com/apis/platform/solutions/paths/~1api~1v2~1solutions/get.md): Retrieve all solutions (solution objects) on the server. To use this path, you must have a Content Administrator reserved role, or you must have the Import Signed Content permission.

### Verify file signatures

 - [POST /api/v2/verify_signatures](https://developer.tanium.com/apis/platform/solutions/paths/~1api~1v2~1verify_signatures/post.md): Verify that a solution manifest, console-specific files, module-specific files, or platform-specific plugins are provided by Tanium, and valid for deployment to the Tanium Server. The Tanium Server verifies the Base64-encoded file signature and returns true or false. If you pass a file signature for verification and the Tanium Server does not verify the file, do NOT deploy it to the Tanium Server. Contact Tanium for assistance.

## Systems

### Get client count

 - [GET /api/v2/client_count](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1client_count/get.md): Retrieve a count of the clients in the network.

### Get intentional subnets

 - [GET /api/v2/intentional_subnets](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1intentional_subnets/get.md): Retrieve all intentional subnets (intentional_subnet objects) on the Tanium Server. This requires Tanium Core Platform 7.5.3 or later and Tanium Client version 7.4.7 or later.

### Create intentional subnet

 - [POST /api/v2/intentional_subnets](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1intentional_subnets/post.md): Create an intentional subnet (intentional_subnet object) on the Tanium Server. This requires Tanium Core Platform 7.5.3 or later and Tanium Client version 7.4.7 or later.

### Delete intentional subnet

 - [DELETE /api/v2/intentional_subnets/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1intentional_subnets~1%7Bid%7D/delete.md): This path requires Tanium Core Platform 7.5.3 or later and Tanium Client version 7.4.7 or later. Delete the intentional subnet (intentional_subnet object) that matches the specified ID. Deleting an intentional subnet sets the deleted_flag property to true, but does not remove the object from the server.

### Get intentional subnet by ID

 - [GET /api/v2/intentional_subnets/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1intentional_subnets~1%7Bid%7D/get.md): Retrieve the intentional subnet (intentional_subnet object) that matches the specified ID. This requires Tanium Core Platform 7.5.3 or later and Tanium Client version 7.4.7 or later.

### Update intentional subnet by ID

 - [PATCH /api/v2/intentional_subnets/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1intentional_subnets~1%7Bid%7D/patch.md): Update the intentional subnet (intentional_subnet object) that matches the specified ID. This requires Tanium Core Platform 7.5.3 or later and Tanium Client version 7.4.7 or later.

### Get isolated subnets

 - [GET /api/v2/isolated_subnets](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1isolated_subnets/get.md): Retrieve all isolated subnets (isolated_subnet objects) on the server.

### Create isolated subnet

 - [POST /api/v2/isolated_subnets](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1isolated_subnets/post.md): Create an isolated subnet (isolated_subnet object) on the Tanium Server.

### Delete isolated subnet

 - [DELETE /api/v2/isolated_subnets/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1isolated_subnets~1%7Bid%7D/delete.md): Delete the isolated subnet (isolated_subnet object) that matches the specified ID.

### Get isolated subnet by ID

 - [GET /api/v2/isolated_subnets/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1isolated_subnets~1%7Bid%7D/get.md): Retrieve the isolated subnet (isolated_subnet object) that matches the specified ID.

### Update isolated subnet by ID

 - [PATCH /api/v2/isolated_subnets/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1isolated_subnets~1%7Bid%7D/patch.md): Update the isolated subnet (isolated_subnet object) that matches the specified ID.

### Get local settings

 - [GET /api/v2/local_settings](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1local_settings/get.md): Retrieve all local settings (local_settting objects) on the server.

### Create local setting

 - [POST /api/v2/local_settings](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1local_settings/post.md): Create a local setting (local_settting object). A local setting is a Tanium Server setting that controls communication between the server and other Tanium Core Platform components or external servers, and also control features such as logging.

### Delete local setting

 - [DELETE /api/v2/local_settings/by-name/{name}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1local_settings~1by-name~1%7Bname%7D/delete.md): Delete the local setting (local_settting object) that matches the specified name. The local setting is removed from the server and is no longer available.

### Get local setting by name

 - [GET /api/v2/local_settings/by-name/{name}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1local_settings~1by-name~1%7Bname%7D/get.md): Retrieve the local setting (local_settting object) that matches the specified name.

### Get separated subnets

 - [GET /api/v2/separated_subnets](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1separated_subnets/get.md): Retrieve all separated subnets (separated_subnet objects) on the server.

### Create separated subnet

 - [POST /api/v2/separated_subnets](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1separated_subnets/post.md): Create a separated subnet (separated_subnet object) on the Tanium Server.

### Delete separated subnet

 - [DELETE /api/v2/separated_subnets/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1separated_subnets~1%7Bid%7D/delete.md): Delete the separated subnet (separated_subnet object) that matches the specified ID.

### Get separated subnet by ID

 - [GET /api/v2/separated_subnets/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1separated_subnets~1%7Bid%7D/get.md): Retrieve the separated subnet (separated_subnet object) that matches the specified ID.

### Update separated subnet by ID

 - [PATCH /api/v2/separated_subnets/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1separated_subnets~1%7Bid%7D/patch.md): Update the separated subnet (separated_subnet object) that matches the specified ID.

### Get server health

 - [GET /api/v2/server_health](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1server_health/get.md): Retrieve health information for the server

### Get server host

 - [GET /api/v2/server_host](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1server_host/get.md): Retrieve host information (server_host object) for the Tanium Servers in the environment. This path does not return information for Tanium Module Servers or Tanium Zone Servers.

### Get server info

 - [GET /api/v2/server_info](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1server_info/get.md): Retrieve diagnostic information for the server.

### Get server throttles

 - [GET /api/v2/server_throttles](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1server_throttles/get.md): Retrieve all server throttles (server_throttle objects) on the server.

### Create server throttle

 - [POST /api/v2/server_throttles](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1server_throttles/post.md): Create a server throttle (server_throttle object). A server throttle controls the rate at which data is sent across all client connections. For example, use a server throttle to enforce policies such as "The server should never use more than 1 Mbps sending sensors to clients". Only one server throttle can be active on a server. The server uses the server throttle with the lowest ID property and no value in the ip_address property.

### Delete server throttle

 - [DELETE /api/v2/server_throttles/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1server_throttles~1%7Bid%7D/delete.md): Delete the server throttle (server_throttle object) that matches the specified ID. Deleting a server throttle sets the deleted_flag property to 1, but does not remove the object from the server.

### Get server throttle by ID

 - [GET /api/v2/server_throttles/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1server_throttles~1%7Bid%7D/get.md): Retrieve the server throttle (server_throttle object) that matches the specified ID.

### Update server throttle by ID

 - [PATCH /api/v2/server_throttles/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1server_throttles~1%7Bid%7D/patch.md): Update the server throttle (server_throttle object) that matches the specified ID.

### Get server throttle statuses

 - [GET /api/v2/server_throttle_statuses](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1server_throttle_statuses/get.md): Retrieve status of all server throttle statuses (server_throttle_status objects) on the server.

### Get site throttles

 - [GET /api/v2/site_throttles](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1site_throttles/get.md): Retrieve all site throttles (site_throttle objects) on the server.

### Create site throttle

 - [POST /api/v2/site_throttles](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1site_throttles/post.md): Create a site throttle (site_throttle object). A site throttle controls the rate at which data is sent to a list of subnets. For example, use a site throttle to enforce "The server should never send more than 5 Mbps to 192.168.0.0/16". Only the throttle for the site with the smallest IP address range applies to an endpoint that has an address within the ranges of multiple sites. If an endpoint matches multiple site throttles with the same size IP address range, then only the most recently created throttle applies.

### Delete site throttle

 - [DELETE /api/v2/site_throttles/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1site_throttles~1%7Bid%7D/delete.md): Delete the site throttle (site_throttle object) that matches the specified ID. Deleting a site throttle sets the deleted_flag property to 1, but does not remove the object from the server.

### Get site throttle by ID

 - [GET /api/v2/site_throttles/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1site_throttles~1%7Bid%7D/get.md): Retrieve the site throttle (site_throttle object) that matches the specified ID.

### Update site throttle by ID

 - [PATCH /api/v2/site_throttles/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1site_throttles~1%7Bid%7D/patch.md): Update the site throttle (site_throttle object) that matches the specified ID.

### Get site throttle statuses

 - [GET /api/v2/site_throttle_statuses](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1site_throttle_statuses/get.md): Retrieve status of all site throttles (site_throttle_status objects) on the server.

### Get system settings

 - [GET /api/v2/system_settings](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1system_settings/get.md): Retrieve all system settings (system_setting objects) on the server.

### Create system setting

 - [POST /api/v2/system_settings](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1system_settings/post.md): Create a system setting (system_setting object). A system setting, also called a global setting, can affect Tanium Client, Tanium Server, and Tanium Console behavior.

### Delete system setting

 - [DELETE /api/v2/system_settings/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1system_settings~1%7Bid%7D/delete.md): Delete the system setting (system_setting object) that matches the specified ID. The system setting is removed from the server and is no longer available.

### Get system setting by ID

 - [GET /api/v2/system_settings/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1system_settings~1%7Bid%7D/get.md): Retrieve the system setting (system_setting object) that matches the specified ID.

### Update system setting by ID

 - [PATCH /api/v2/system_settings/{id}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1system_settings~1%7Bid%7D/patch.md): Update the system setting (system_setting object) that matches the specified ID.

### Get system setting by name

 - [GET /api/v2/system_settings/by-name/{name}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1system_settings~1by-name~1%7Bname%7D/get.md): Retrieve the system setting (system_setting object) that matches the specified name. If you do not know the exact name of the system setting, you can use a filter with the GET /api/v2/system_settings path to retrieve an array of system settings with names that match a regular expression.

### Update system setting by name

 - [PATCH /api/v2/system_settings/by-name/{name}](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1system_settings~1by-name~1%7Bname%7D/patch.md): Update the system setting (system_setting object) that matches the specified name.

### Get system status

 - [GET /api/v2/system_status](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1system_status/get.md): Retrieve the system status (system_status_list object) of the server.

### Get unregistered clients

 - [GET /api/v2/unregistered_clients](https://developer.tanium.com/apis/platform/systems/paths/~1api~1v2~1unregistered_clients/get.md): Retrieve the client status (client_status object) for clients that could not register with the Tanium Server.

## Upload files

### Get license file

 - [GET /api/v2/license](https://developer.tanium.com/apis/platform/upload-files/paths/~1api~1v2~1license/get.md): Retrieve information for the tanium.license file from the server.

### Upload license file

 - [POST /api/v2/license](https://developer.tanium.com/apis/platform/upload-files/paths/~1api~1v2~1license/post.md): Upload a tanium.license file. The license must be Base64-encoded with a signature.

### Upload file

 - [POST /api/v2/upload_file](https://developer.tanium.com/apis/platform/upload-files/paths/~1api~1v2~1upload_file/post.md): Upload a local package file (upload_file object).

### Get upload file status by ID

 - [GET /api/v2/upload_file/{id}](https://developer.tanium.com/apis/platform/upload-files/paths/~1api~1v2~1upload_file~1%7Bid%7D/get.md): Retrieve upload file status (upload_file_status object) by the ID of the upload file.

## Users

### Get active user count

 - [GET /api/v2/active_user_count](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1active_user_count/get.md): Retrieve a count of all active user accounts over the past 30 days.

### Transfer ownership

 - [POST /api/v2/transfer](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1transfer/post.md): Transfer the ownership of one or more objects to a different user.

### Get users

 - [GET /api/v2/users](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1users/get.md): Retrieve all active users (user objects) on the server.

### Create user

 - [POST /api/v2/users](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1users/post.md): Create a user (user object). Note that Tanium Server uses external authentication, and does not store or manage its own set of user credentials.

### Get user by name

 - [GET /api/v2/users/by-name/{name}](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1users~1by-name~1%7Bname%7D/get.md): Retrieve the user (user object) that matches the specified name.

### Update user by name

 - [PATCH /api/v2/users/by-name/{name}](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1users~1by-name~1%7Bname%7D/patch.md): Update the user (user object) that matches the specified name. Note that you cannot use this path to update the name property for a user. To update the name, use the PATCH /api/v2/users/{id} path.

### Delete user

 - [DELETE /api/v2/users/{id}](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1users~1%7Bid%7D/delete.md): Delete the user (user object) that matches the specified ID. Deleting a user sets the deleted_flag property to true, but does not remove the object from the server. You can undelete a user using PATCH /api/v2/users/{id} or PATCH /api/v2/users/by-name/{name} by changing the deleted_flag property to false.

### Get user by ID

 - [GET /api/v2/users/{id}](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1users~1%7Bid%7D/get.md): Retrieve the user (user object) that matches the specified ID.

### Update user by ID

 - [PATCH /api/v2/users/{id}](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1users~1%7Bid%7D/patch.md): Update the user (user object) that matches the specified ID. Note: You can use this path to change the name of another user, but not your own user name.

### Get user metadata by user ID

 - [GET /api/v2/users/{id}/metadata](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1users~1%7Bid%7D~1metadata/get.md): Retrieve the metadata items (metadata_item objects) for the user that matches the specified ID.

### Create user metadata for user ID

 - [POST /api/v2/users/{id}/metadata](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1users~1%7Bid%7D~1metadata/post.md): Create a metadata item (metadata_item object) for the user that matches the specified ID.

### Delete user metadata by name

 - [DELETE /api/v2/users/{id}/metadata/by-name/{name}](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1users~1%7Bid%7D~1metadata~1by-name~1%7Bname%7D/delete.md): Delete a metadata item (metadata_item object) for the user that matches the specified ID.

### Get user metadata by name

 - [GET /api/v2/users/{id}/metadata/by-name/{name}](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1users~1%7Bid%7D~1metadata~1by-name~1%7Bname%7D/get.md): Retrieve the metadata items (metadata_item objects) that match the specified metadata name.

### Update user metadata by name

 - [PATCH /api/v2/users/{id}/metadata/by-name/{name}](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1users~1%7Bid%7D~1metadata~1by-name~1%7Bname%7D/patch.md): Update a metadata item (metadata_item object) for the user that matches the specified ID.

### Get user groups

 - [GET /api/v2/user_groups](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1user_groups/get.md): Retrieve all user groups (user_group objects) on the server.

### Create user group

 - [POST /api/v2/user_groups](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1user_groups/post.md): Create a user group (user_group object).

### Get user group by name

 - [GET /api/v2/user_groups/by-name/{name}](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1user_groups~1by-name~1%7Bname%7D/get.md): Retrieve the user group (user_group object) that matches the specified name.

### Delete user group

 - [DELETE /api/v2/user_groups/{id}](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1user_groups~1%7Bid%7D/delete.md): Delete the user group (user_group object) that matches the specified ID. Deleting a user group sets the deleted_flag property to 1, but does not remove the user group from the server.

### Get user group by ID

 - [GET /api/v2/user_groups/{id}](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1user_groups~1%7Bid%7D/get.md): Retrieve the user group (user_group object) that matches the specified ID.

### Update user group by ID

 - [PATCH /api/v2/user_groups/{id}](https://developer.tanium.com/apis/platform/users/paths/~1api~1v2~1user_groups~1%7Bid%7D/patch.md): Update the user group (user_group object) that matches the specified ID.

## Whitelisted URLs

### Get allowed URLs

 - [GET /api/v2/white_listed_urls](https://developer.tanium.com/apis/platform/whitelisted-urls/paths/~1api~1v2~1white_listed_urls/get.md): Retrieve all allowed URLs (white_listed_url objects) on the server.

### Create whitelisted URL

 - [POST /api/v2/white_listed_urls](https://developer.tanium.com/apis/platform/whitelisted-urls/paths/~1api~1v2~1white_listed_urls/post.md): Create an allowed URL (white_listed_url object).

### Delete whitelisted URL

 - [DELETE /api/v2/white_listed_urls/{id}](https://developer.tanium.com/apis/platform/whitelisted-urls/paths/~1api~1v2~1white_listed_urls~1%7Bid%7D/delete.md): Delete the allowed URL (white_listed_url object) that matches the specified ID. Deleting an allowed URL sets the deleted_flag property to 1, but does not remove the object from the server.

### Get whitelisted URL by ID

 - [GET /api/v2/white_listed_urls/{id}](https://developer.tanium.com/apis/platform/whitelisted-urls/paths/~1api~1v2~1white_listed_urls~1%7Bid%7D/get.md): Retrieve the allowed URL (white_listed_url object) that matches the specified ID.

### Update whitelisted URL by ID

 - [PATCH /api/v2/white_listed_urls/{id}](https://developer.tanium.com/apis/platform/whitelisted-urls/paths/~1api~1v2~1white_listed_urls~1%7Bid%7D/patch.md): Update the allowed URL (white_listed_url object) that matches the specified ID.

