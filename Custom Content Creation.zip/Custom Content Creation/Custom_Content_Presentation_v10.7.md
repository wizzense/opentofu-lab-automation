# Tanium Custom Content

## TANIUM

---

# Custom Content

Apply your existing scripting knowledge to more in-depth techniques within the Tanium environment

## Key Concepts
- (Re)Introduction to Tanium architecture
- Sensor deep dive
- Internal execution API
- Strings & answers
- Packages
- Functions/tools/code examples
- Content security
- Closing Q&A

---

# Training resources

## Tanium Learning Center

Access training session information, teleconferencing details, and course materials, including student and lab guides
learn.tanium.com OR learn-partners.tanium.com

## Skillable

Complete hands-on practice in a lab featuring virtual clients and the Tanium Console
tanium.learnondemand.net

External Use\Confidential - NDA Required

Tanium offers these training resources to enhance your learning experience.
The Tanium Learning Center houses all available web-based and virtual training opportunities.
Skillable provides a hands-on practical lab environment for completing the assigned tasks and activities throughout this training.

---

# Objectives

After this course, you should be able to perform functions such as:

- Explain how content runs in Tanium on endpoints
- Explain Tanium's safeguards for content
- Explain how sensors can impact endpoints
- Use Tanium-specific best practices for sensors and packages
- Test content created for Tanium
- Review built-in Tanium content

For best practice, mention quick examples eg echo n/a on other OSes in sensors, point out early Tanium code does not follow best practices which needed to be compatible with old client versions ( 6.0 and below) which support $x p-x p / 2003$. This is also covered in "use 7.2 or higher" slide -- 6.0 does not mandate encryption, can send data clear text.

---

# Topics

| (Re)Introduction to Tanium architecture | Sensor deep dive <br> - Introduction <br> - Logs, databases, and stats <br> - Languages <br> - Errors, "rogue" sensors, debugging <br> - Crunching data |
| :--: | :--: |
| Answers to questions and strings <br> - Answers and strings <br> - Architecture <br> - Error messages <br> - String management/reduction <br> - Question evaluation |  |
|  |  |
| Packages | Content security |
| - Introduction | - Introduction |
| - Spawning child processes | - Parameter injection |
| - External and internal execution | - Privilege escalation |
| - Logs and checks | - Supply chain attacks |
|  | - Sensitive data |

Scene-setting, point out when looking at this agenda, we'll spend the majority of the time on sensors because of the implications at scale, Tanium-specific considerations etc.

Note some slides are quite text-heavy due to the technical nature of the content.

---

# Hands-on practice

## Apply training knowledge

This presentation is supplemented by a lab guide and environment.

- Labs have been updated to access directly from the Tanium Learning Center. Please ignore any messages you may see anywhere related to registering for a Skillable account and a training key to redeem.
- See your class registration, under the schedule / calendar entry for the class in learn.Tanium.com
- Expand the Description & Activities section and you will see you instructor name for the session and a button to launch the lab environment. No separate Skillable account is needed.
- All labs are totally optional, but have been designed to allow you to test many of the concepts taught in this class. We encourage you to complete as many of the labs as possible. Your instructor will also be happy to help.

Show how to launch LOD, log on and spin up lab, allow 10 mins or so getting attendees up and running in labs - any longer ask your shadows to assist them

Lab 1 10-15 mins from attendees being operational

---

# What is "content"?

## Content ...

- ... refers to everything you use in Interact; sensors, packages, saved questions, and dashboards
- ...is at the heart of Tanium's ability to be flexible
- ... provides a highly creative approach to problem-solving
- "Core content" : content provided by Tanium
- "Custom content" : content provided by users, usually sensors and packages

Why are we here? Tanium can be extensively customized through the creation of custom "content." A potentially limitless number of use cases can be unlocked by leveraging this.

What is that content?
Content is:

- Whatever runs on the endpoint that is not the client
- Scripts, packages, etc.
- Whatever operators use inside Tanium Interact
- Dashboards, questions, sensors, actions (packages), etc.
- Tanium's ability to be flexible
- Arbitrary data selection and machine filtering
- Arbitrary file distribution

A creative approach to problem-solving - WHY? (open question)
Anything not provided by Tanium can be used as content - specifically sensors and packages - if it can be scripted

---

# Important - Use 7.6 or later client version

- Tanium supported client versions are 7.6 and later (7.4 & 7.5 end of support June 19, 2025)
- Custom content should be written with current client versions in mind
- Content is not supported on, and should not be expected to run on older, out of support client versions
- Content should not be expected to run on endpoints not included in the current list of Tanium supported operating systems
- Tanium Client and Client Management requirements

Do not write custom content for client versions older than Tanium's currently supported client versions

---

You're just a user as Tanium manages the platform, so Tanium may decide to disable custom content if it has a negative impact on Tanium service

Also, circling back to client versions, Tanium Cloud only supports >7.6.x.

---

# (Re)Introduction to Tanium architecture

## Answers to questions and strings

- What is content in Tanium?
- Tanium Client

---

# Tanium architecture revisited

Within seconds, Tanium's patented linear communication model can query or modify every endpoint in the environment.

As new clients join the network, they register with the Tanium server.

Clients are made aware of 10 peers forward and backward in their linear chain.

Endpoints dropping from the chain do not interrupt communication.

External Use\Confidential - NDA Required

DEMO: ask "installed applications from all machines" or similar; this will be the primary sensor used for demoing sensors later

This course covers sensors, packages, and strings. It is helpful to remember the architecture and what is on the endpoint, what is distributed, and when.

On startup, the Tanium Client registers with the Tanium Server to provide the computer's location in the network based on IP address. In exchange, the Tanium Server provides a "neighborhood list" to the client. The neighborhood list contains the IP addresses for 10 computers to the left and 10 computers to the right based on IP address. Using the neighborhood list as a guide, each client attempts to establish a TCP connection to three computers to its left and three to the right, again based on IP address order. Because each client performs this interaction automatically at startup and again at the configured client registration interval (five mins by default) the clients automatically form a linear communication chain through which Tanium messages can travel using available LAN bandwidth and minimizing communication over WAN links.

If it has no computers to its left, the computer with the lowest IP address automatically takes on the role of a backward leader. It establishes a persistent TCP connection with the Tanium Server to gather new messages, process them, and pass them on to the next machine in the linear chain. Similarly, because the machine with the highest IP address has no computers to its right, the client installed on that machine automatically takes on the role of forward leader. This client is responsible for forwarding messages that have traveled the chain back to the Tanium server to display results in the Tanium Console.

As new clients join the network, they register with the Tanium Server individually and take their place

---

in the chain. Typically, a client is made aware of ten peers forward and backward in its linear chain. This allows endpoints to drop as needed from the chain without interrupting communication. If the communication between two peers ends without warning, the remaining peer simply moves to the next IP address in the neighborhood list.

The linear chain topology dramatically reduces the workload on the primary server compared to traditional hub and spoke topology, and has proven to be a resilient architecture for the world's largest networks.

---

# Tanium architecture revisited

## Strings and Tanium's Architecture

## Comparing

- Answer Reports: hash-based communication
- It is this hash-based communication that gives Tanium its efficiency
- String Reports: mapping between hashes and human-readable strings

External Use\Confidential - NDA Required

NOW WITH REGARD TO SENSORS (QUESTIONS) AND PACKAGES (ACTIONS)
Data is retrieved from the endpoints using two message types.
The primary message is a hashed-based communication known as the Answer report.
Additional to that is a string report message, which provides the mapping between hashes and the human-readable strings

The following slides will explain the differenc... to a file. Read file with Sensor
- Can report on results of any tool execution
- If you can redirect output to a file or parse a log

---

# Beyond scripts

The sensor/package combination

- Deploy a scheduled action using the package to do the heavy lifting
- Runtime is now package timeout limit, not sensor limit 60 seconds
- Can report on results of any tool execution
- Interrogate the results with sensors
- A lot of important specialty tools have no feasible way to scale execution

Tanium can do this for you! MANY very important custom content use cases look like this.

External Use\Confidential - NDA Required

There are some scenarios where you want to get data that doesn't fit into the limitations of a sensor

Packages and sensors can be used in a powerful combination to allow the package to safely perform longer running processing and return the results later using a sensor

---

# Tanium platform 7.6 and later package testing considerations

Prior to Tanium platform 7.6, package deployments stored logs in <client>/Downloads/Action_xxx.log and related files in <client>/Downloads/Action_xxx

Logs were cleaned up after approximately 7 days, Action_xxx directories after approximately 4 hours.
Tanium platform 7.6 introduced an immediate cleanup on the Action_xxx directories that might make testing and troubleshooting packages more difficult. See this Tanium help article for more information

Custom Content and Platform Packages with Tanium Platform 7.6.1

Tanium platform and clients are constantly evolving and improving. Above are a few points to note as of Tanium platform 7.6

---

# Tanium platform 7.6 and later content development considerations

Prior to Tanium platform 7.6, temporary directories were left as defined by environment variables on different operating systems.

Tanium platform 7.6 introduced a change to help secure temporary files, where tmp and temp environment variables are modified for sensor and package execution to be inside the Tanium client directory.

This should not generally cause problems, but if it does cause any difficulty, consider temporarily resetting the temp directory in sensor and package scripts, with security in mind of course.

See this Tanium help article for more information
Temp Directory Changes in Tanium Client 7.6.1 and Later

Tanium platform and clients are constantly evolving and improving. Above are a few points to note as of Tanium platform 7.6

---

Content security

---

# Introduction

- Content runs as the highest privileged user on the endpoint
- Local system for Windows, UID 0 / root for non Windows
- Content could allow users to cross privilege boundaries
- Improperly written content could represent a local privilege escalation on an endpoint
- Parameters passed to subcommands could bypass authorization checks on the Tanium Server

External Use\Confidential - NDA Required

- Content could allow users to cross privilege boundaries
- eg not stipulating full path to local executables, path could be compromised to point to malicious code with same filename
"Parameters passed to subcommands" - eg as previously, cmd /d /c to parameter value

---

# Parameter injection

- Parameters are URL encoded. (Remember: Failure to remember to URL decode parameters in both sensors and packages is a common source of errors)
- Decoding and passing to a subprocess without appropriate parameter validation could allow parameter injection or other errors
- This could bypass authorization on the Tanium Server
- Allows users to issue actions with the same privileges as users who can author content
- Tanium encoding and requiring parameters to be decoded, as well as some language protections help protect against this.
- We do not provide examples of how parameter injection can be used to bypass security

Parameters in sensors and packages must be handled safely
Parameters in packages are URL encoded
Decoding a parameter and passing it to a subprocess allows for parameter injection

- objShell.run "%COMSPEC% /c copy NUL "&Chr(34)&URLDecode(unsafeparameter)
- if the a parameter begins with the character ' & ', the rest of the parameter will be interpreted as part of the command
This bypasses authorization on the TS, allowing users with the capability to issue actions the same privileges as users who can author content

---

# Parameter injection

- Be mindful of the executables you call
- For example, on Windows:
- As far as possible, always enclose parameters and any path names used in scripts in quotes to avoid errors and misinterpretation of directory or path names that might contain spaces or other special characters
- C:\Program Files (x86)\Tanium\TaniumClient\Tools\StdUtils\TaniumFileInfo.exe attempts to execute C:\Program.exe as it is not quoted
- This could result in an error, or potential for a malicious executable named C:\Program.exe to run with privilege escalation
- Instead: "C:\Program Files (x86)\Tanium\TaniumClient\Tools\StdUtils\TaniumFileInfo.exe"

---

# Privilege escalation

- Only run scripts from places on file system restricted to high privileged users
- Recommend only running content created by a package from the Tanium Client directory
- Don't stage it in a directory outside of C:\Program Files or /opt/Tanium/TaniumClient
- Running scripts and executables from world writable directories is a bad idea
- Low privileged users can overwrite scripts and executables that get run by the Tanium client
- We run their scripts, they get our privileges
- Never use temp directories that might be available to other users allowing for possible race conditions or "just in time" tampering with code executed with elevated privileges
- Don't place custom PowerShell modules for example in the standard Windows PowerShell module path
- Writing to low privileged areas of disk is similarly bad
- Files that you are writing to/deleting could be symbolic links pointing to high privileged areas of the file system

External Use\Confidential - NDA Required

- Only run scripts from places on file system restricted to high privileged users
- Recommend only running content created by a package from the Tanium Client directory
- Don't stage it in a directory outside of C:\Program Files or /opt/Tanium/TaniumClient
- Running scripts and executables from globally writeable directories can lead to compromise
- Low privileged users can overwrite scripts and executables that get run by the TC
- We run their scripts, they get our privileges
- Writing to low privileged areas of disk can lead to compromise
- Files that you are writing to/deleting could be symbolic links pointing to high privileged areas of the file system
- Checking to see if the file is a symlink prior to performing a write can just introduce a Time of Check/Time of Use bug

---

# Supply chain attacks

- Supply chain attacks are real!
- Colourama was a pypi package designed to typo-squat the real package Colorama
- Installed a crypto miner on machines using the dependency
- If a malicious dependency is included in content, the attacker could control a large number of endpoints

Tanium's Software Bill of Materials (SBOM) can help report on software dependencies or additional software and libraries distributed within an application for Windows, MacOS, and Linux endpoints.

When you have a complete inventory of the software on endpoints, including dependencies, you can quickly respond to emergent vulnerabilities that are identified in a specific component.

Tanium SBOM with Tanium Comply can be used to scrutinize third-party dependencies added to content and report known vulnerabilities.

External Use\Confidential - NDA Required

Supply chain attacks have affected a number of package managers - see node event-stream, flatmap.

Colourama with U vs without

---

Is it worth the effort of writing it yourself rather than accepting the risk of bringing on a thirdparty dependency?

---

# Sensitive data

- All Tanium client versions now enforce a TLS encrypted linear chain
- https://help.tanium.com/bundle/ug_appliance_onprem/page/appliance/tls.html
- Traffic is encrypted and not visible to non-Tanium users
- Communication is encrypted; local memory isn't
- Sensors should not return PII, credentials, or other sensitive data as other endpoints on the linear chain will be able to store it in memory
- Credentials should never be passed in sensors or packages without proper care. Question and action history, as well as package scripts can expose credentials
- Where possible use SSH key authentication, API tokens (see Tanium Gateway training) and other techniques and avoid embedding credentials

Peers on a linear chain store sensor results in memory

---

# Training complete

Congratulations! You should be able to:

- Explain how content runs in Tanium on endpoints
- Explain Tanium's safeguards for content
- Explain how sensors can impact endpoints
- Use Tanium recommended best practices when creating sensors and packages
- Test content created for Tanium
- Review built-in Tanium content

---

# TANIUM

## Closing Q&A

(1) www.tanium.com
(1)T Tanium
(1) info@tanium.com

---

# What's Next?

**Training Survey**

**Share Your Thoughts**

**Follow-Up Training**

**tanium.com/training**

**Certifications**

**Become Certified**

